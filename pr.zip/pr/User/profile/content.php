<?php


$currentusername = $currentusermobile = $logedInUseremail = "";
$updateSuccess = false;

if (isset($_SESSION['user']) || isset($_SESSION['hotel'])) {
    $logedInUseremail = $_SESSION['user'] ?? $_SESSION['hotel'];
    $statementuser = $pdo->prepare("SELECT * FROM users WHERE Email = ?");
    $statementuser->execute([$logedInUseremail]);
    $userData = $statementuser->fetch();

    if ($userData) {
        $currentusername = $userData['Name'];
        $currentusermobile = $userData['MobileNo'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $mobile = $_POST['mobile'] ?? '';
    if (!empty($name) && !empty($mobile)) {
        $updateStmt = $pdo->prepare("UPDATE users SET Name = ?, MobileNo = ? WHERE Email = ?");
        $updateStmt->execute([$name, $mobile, $logedInUseremail]);
        $updateSuccess = true;

        // Refresh values
        $currentusername = $name;
        $currentusermobile = $mobile;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <style>
        body {
            background-color: #fff;
            font-family: Arial, sans-serif;
        }
        .card-container1 {
            width: 600px;
            background-color:rgb(255, 255, 255);
            margin: 0 auto;
            padding: 30px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        .round {
            display: block;
            margin: 0 auto;
            width: 120px;
            border-radius: 50%;
        }
        h2, h3, h4 {
            text-align: center;
            color: #333;
        }
        .email {
            text-align: center;
            word-wrap: break-word;
            color: #555;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .buttons {
            text-align: center;
            margin-top: 20px;
        }
        .primary {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .primary:hover {
            background-color: #0056b3;
        }
        .transparent-btn {
            background-color: transparent;
            color: #007BFF;
            border: none;
            cursor: pointer;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<div class="heading" style="background:url(../../images/header-bg-1.png) no-repeat">
   <h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="padding-top: 0px; visibility: visible; animation-delay: 0.5s; animation-name: zoomIn; font-weight: bolder;">Priofile</h1>
</div>
<div class="container mt-3 mb-5">
        <div class="card shadow-lg mx-auto" style="max-width: 600px;">
            <div class="card-body">
                <div class="text-center mb-4">
                    <img src="../../images/profile-page.png" class="rounded-circle" width="120" alt="Profile Picture">
                    <h3 class="mt-3">Edit Profile</h3>
                </div>

                <?php if ($updateSuccess): ?>
                    <div class="alert alert-success text-center" role="alert">
                        Profile updated successfully!
                    </div>
                <?php endif; ?>

                <form method="POST" onsubmit="return validateForm();">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?=htmlspecialchars($currentusername)?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="mobile" class="form-label">Mobile Number</label>
                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?=htmlspecialchars($currentusermobile)?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" value="<?=htmlspecialchars($logedInUseremail)?>" disabled>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </div>
                </form>

                <div class="mt-4 d-flex justify-content-between">
                    <a href="../loginlogout/logout.php" class="btn btn-danger">Log Out</a>
                    <a href="../loginlogout/check-password.php" class="btn btn-link">Change Password</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS + validation -->
    <script>
        function validateForm() {
            const name = document.getElementById('name').value.trim();
            const mobile = document.getElementById('mobile').value.trim();
            const mobileRegex = /^[0-9]{10,15}$/;

            if (name === '' || mobile === '') {
                alert("Please fill all fields.");
                return false;
            }
            if (!mobileRegex.test(mobile)) {
                alert("Please enter a valid mobile number.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
