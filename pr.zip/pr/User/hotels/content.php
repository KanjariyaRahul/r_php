<?php
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");

// Get filter values
$selectedCountry = $_GET['country'] ?? '';
$selectedState   = $_GET['state'] ?? '';
$selectedCity    = $_GET['city'] ?? '';

// Fetch all countries
$countryStmt = $pdo->prepare("SELECT * FROM country");
$countryStmt->execute();
$countries = $countryStmt->fetchAll();

// Fetch states based on selected country
$states = [];
if (!empty($selectedCountry)) {
    $stateStmt = $pdo->prepare("SELECT * FROM states WHERE Country_id = ?");
    $stateStmt->execute([$selectedCountry]);
    $states = $stateStmt->fetchAll();
}

// Fetch cities based on selected state
$cities = [];
if (!empty($selectedState)) {
    $cityStmt = $pdo->prepare("SELECT * FROM city WHERE State_id = ?");
    $cityStmt->execute([$selectedState]);
    $cities = $cityStmt->fetchAll();
}

// Main hotel query
$sql = "
    SELECT 
        hotels.*, 
        city.CityName, 
        states.StateName, 
        country.CountryName
    FROM hotels
    LEFT JOIN city ON hotels.City_id = city.Id
    LEFT JOIN states ON city.State_id = states.Id
    LEFT JOIN country ON states.Country_id = country.Id
    WHERE hotels.hotel_delete = 0
";

$params = [];

if (!empty($selectedCountry)) {
    $sql .= " AND country.Id = ?";
    $params[] = $selectedCountry;
}
if (!empty($selectedState)) {
    $sql .= " AND states.Id = ?";
    $params[] = $selectedState;
}
if (!empty($selectedCity)) {
    $sql .= " AND city.Id = ?";
    $params[] = $selectedCity;
}

$hotelStmt = $pdo->prepare($sql);
$hotelStmt->execute($params);
$hotels = $hotelStmt->fetchAll();
?>

<!-- Header -->
<div class="heading" style="background:url(../../images/header-bg-3.png) no-repeat">
   <h1 style="padding-top: 0px; font-weight: bolder;">Hotels</h1>
</div>

<!-- Filter Form -->
<section class="packages">
   <form method="GET" style="text-align: right; margin-bottom: 20px;">
       <!-- Country Filter -->
       <select name="country" id="country" onchange="this.form.submit()">
           <option value="">Select Country</option>
           <?php foreach ($countries as $country): ?>
               <option value="<?= $country['Id'] ?>" <?= ($selectedCountry == $country['Id']) ? 'selected' : '' ?>>
                   <?= $country['CountryName'] ?>
               </option>
           <?php endforeach; ?>
       </select>

       <!-- State Filter -->
       <select name="state" id="state" onchange="this.form.submit()">
           <option value="">Select State</option>
           <?php foreach ($states as $state): ?>
               <option value="<?= $state['Id'] ?>" <?= ($selectedState == $state['Id']) ? 'selected' : '' ?>>
                   <?= $state['StateName'] ?>
               </option>
           <?php endforeach; ?>
       </select>

       <!-- City Filter -->
       <select name="city" id="city" onchange="this.form.submit()">
           <option value="">Select City</option>
           <?php foreach ($cities as $city): ?>
               <option value="<?= $city['Id'] ?>" <?= ($selectedCity == $city['Id']) ? 'selected' : '' ?>>
                   <?= $city['CityName'] ?>
               </option>
           <?php endforeach; ?>
       </select>
   </form>

   <!-- Hotel Cards -->
<div class="box-container">
<?php if (count($hotels) > 0): ?>
    <?php foreach ($hotels as $hotelrow): ?>
        <div class="box">
            <div class="image">
                <img src="../../images/<?= $hotelrow['Imagespath']; ?>" alt="Hotel Image">
            </div>
            <div class="content">
                <h3><?= $hotelrow['HotelName']; ?></h3>
                <h4><?= $hotelrow['CityName']; ?> - <?= $hotelrow['StateName']; ?> (<?= $hotelrow['CountryName']; ?>)</h4>
                <div class="button-row">
                    <!-- View More Button -->
                    <button class="btn" onclick="openModal(<?= $hotelrow['Id'] ?>)">View More</button>
                    <!-- Book Now Button -->
                    <button class="btn" onclick="window.location.href='http://localhost/tour/User/Booking/index.php?hotelId=<?= $hotelrow['Id'] ?>'">Book Now</button>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div style="text-align: center; width: 100%; font-size: 18px; padding: 20px;">
        No hotels found for selected filter.
    </div>
<?php endif; ?>
</div>


<!-- Modal for Hotel Details -->
<div id="hotelModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="hotelDetails"></div>
    </div>
</div>
</section>

<script>
    // Open Modal and fetch hotel details using AJAX
    function openModal(hotelId) {
        var modal = document.getElementById("hotelModal");
        var hotelDetails = document.getElementById("hotelDetails");

        // Send an AJAX request to fetch hotel details
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "hoteldetails.php?id=" + hotelId, true);
        xhr.onload = function () {
            if (xhr.status == 200) {
                hotelDetails.innerHTML = xhr.responseText;
                modal.style.display = "block";
            }
        };
        xhr.send();
    }

    // Close Modal
    function closeModal() {
        var modal = document.getElementById("hotelModal");
        modal.style.display = "none";
    }

    // Close modal when clicked outside of modal content
    window.onclick = function(event) {
        var modal = document.getElementById("hotelModal");
        if (event.target == modal) {
            closeModal();
        }
    }
</script>
