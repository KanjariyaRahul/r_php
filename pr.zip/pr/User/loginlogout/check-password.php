<?php
include("../home/header.php");

if (!isset($_SESSION['user']) && !isset($_SESSION['hotel'])) {
  header("Location: ../login.php");
  exit;
}

$updateSuccess = false;
$errorMsg = '';

$logedInUseremail = $_SESSION['user'] ?? $_SESSION['hotel'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldPassword = $_POST['old_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($newPassword !== $confirmPassword) {
        $errorMsg = "New passwords do not match.";
    } else {
        $stmt = $pdo->prepare("SELECT Password FROM users WHERE Email = ?");
        $stmt->execute([$logedInUseremail]);
        $user = $stmt->fetch();

        if ($user && password_verify($oldPassword, $user['Password'])) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE users SET Password = ? WHERE Email = ?");
            $updateStmt->execute([$hashedPassword, $logedInUseremail]);
            $updateSuccess = true;
        } else {
            $errorMsg = "Old password is incorrect.";
        }
    }
}
?>

<div class="heading" style="background:url(../../images/header-bg-1.png) no-repeat">
    <h1 class="text-center fw-bold py-3">Change Password</h1>
</div>

<div class="container mt-5 mb-5">
    <div class="card mx-auto shadow mb-5" style="max-width: 500px;">
        <div class="card-body">
            <h4 class="card-title text-center mb-4">Change Password</h4>

            <?php if ($updateSuccess): ?>
                <div class="alert alert-success text-center">Password updated successfully!</div>
            <?php elseif (!empty($errorMsg)): ?>
                <div class="alert alert-danger text-center"><?=htmlspecialchars($errorMsg)?></div>
            <?php endif; ?>

            <form method="POST" onsubmit="return validatePasswordForm();">
                <div class="mb-3">
                    <label class="form-label">Old Password</label>
                    <input type="password" name="old_password" id="old_password" class="form-control">
                    <div id="oldPassError" class="text-danger small mt-1"></div>
                </div>
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" id="new_password" class="form-control">
                    <div id="newPassError" class="text-danger small mt-1"></div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                    <div id="confirmPassError" class="text-danger small mt-1"></div>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Update Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function validatePasswordForm() {
        const oldPass = document.getElementById('old_password').value.trim();
        const newPass = document.getElementById('new_password').value.trim();
        const confirmPass = document.getElementById('confirm_password').value.trim();

        let valid = true;

        // Clear all error messages
        document.getElementById('oldPassError').innerText = '';
        document.getElementById('newPassError').innerText = '';
        document.getElementById('confirmPassError').innerText = '';

        if (oldPass === '') {
            document.getElementById('oldPassError').innerText = 'Please enter your old password.';
            valid = false;
        }

        if (newPass === '') {
            document.getElementById('newPassError').innerText = 'Please enter a new password.';
            valid = false;
        }

        if (confirmPass === '') {
            document.getElementById('confirmPassError').innerText = 'Please confirm your new password.';
            valid = false;
        } else if (newPass !== confirmPass) {
            document.getElementById('confirmPassError').innerText = 'Passwords do not match.';
            valid = false;
        }

        return valid;
    }
</script>

<?php include("../home/footer.php"); ?>
