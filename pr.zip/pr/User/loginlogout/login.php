<!DOCTYPE html>
<html lang="en">
<?php
session_start();
?>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>home</title>
  <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/bootstrap.css">
  <link rel="stylesheet" href="../../css/font-awesome.min.css">
  <!-- swiper css link  -->
  <link rel="stylesheet" href="../../css/swiper-bundle.min.css" />

  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="../../css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="../../css/animate.css">
  <link rel="stylesheet" href="../../css/style.css">
  <!-- <link rel="stylesheet" href="../../css/login.css"> -->
  <style>
    @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');

    ::selection {
      background: #1a75ff;
      color: #fff;
    }

    .wrapper {
      overflow: hidden;
      max-width: 390px;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0px 15px 20px rgba(0, 0, 0, 0.1);
      margin: 50px auto;
    }

    .wrapper .title-text {
      display: flex;
      width: 200%;
    }

    .wrapper .title {
      width: 50%;
      font-size: 35px;
      font-weight: 600;
      text-align: center;
      transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }

    .wrapper .slide-controls {
      position: relative;
      display: flex;
      height: 50px;
      width: 100%;
      overflow: hidden;
      margin: 30px 0 10px 0;
      justify-content: space-between;
      border: 1px solid lightgrey;
      border-radius: 15px;
    }

    .slide-controls .slide {
      height: 100%;
      width: 100%;
      color: #fff;
      font-size: 18px;
      font-weight: 500;
      text-align: center;
      line-height: 48px;
      cursor: pointer;
      z-index: 1;
      transition: all 0.6s ease;
    }

    .slide-controls label.signup {
      color: #000;
    }

    .slide-controls .slider-tab {
      position: absolute;
      height: 100%;
      width: 50%;
      left: 0;
      z-index: 0;
      border-radius: 15px;
      background: -webkit-linear-gradient(left, #003366, #004080, #0059b3, #0073e6);
      transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }

    input[type="radio"] {
      display: none;
    }

    #signup:checked~.slider-tab {
      left: 50%;
    }

    #signup:checked~label.signup {
      color: #fff;
      cursor: default;
      user-select: none;
    }

    #signup:checked~label.login {
      color: #000;
    }

    #login:checked~label.signup {
      color: #000;
    }

    #login:checked~label.login {
      cursor: default;
      user-select: none;
    }

    .wrapper .form-container {
      width: 100%;
      overflow: hidden;
    }

    .form-container .form-inner {
      display: flex;
      width: 200%;
    }

    .form-container .form-inner form {
      width: 50%;
      transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }

    .form-inner form .field {
      height: 50px;
      width: 100%;
      margin-top: 20px;
    }

    .form-inner form .field input {
      height: 100%;
      width: 100%;
      outline: none;
      padding-left: 15px;
      border-radius: 15px;
      border: 1px solid lightgrey;
      border-bottom-width: 2px;
      font-size: 17px;
      transition: all 0.3s ease;
    }

    .form-inner form .field input:focus {
      border-color: #1a75ff;
      /* box-shadow: inset 0 0 3px #fb6aae; */
    }

    .form-inner form .field input::placeholder {
      color: #999;
      transition: all 0.3s ease;
    }

    form .field input:focus::placeholder {
      color: #1a75ff;
    }

    .form-inner form .pass-link {
      margin-top: 5px;
    }

    .form-inner form .signup-link {
      text-align: center;
      margin-top: 30px;
    }

    .form-inner form .pass-link a,
    .form-inner form .signup-link a {
      color: #1a75ff;
      text-decoration: none;
    }

    .form-inner form .pass-link a:hover,
    .form-inner form .signup-link a:hover {
      text-decoration: underline;
    }

    form .btn {
      height: 50px;
      width: 100%;
      border-radius: 15px;
      position: relative;
      overflow: hidden;
    }

    form .btn .btn-layer {
      height: 100%;
      width: 300%;
      position: absolute;
      left: -100%;
      background: -webkit-linear-gradient(right, #003366, #004080, #0059b3, #0073e6);
      border-radius: 15px;
      transition: all 0.4s ease;
      ;
    }

    form .btn:hover .btn-layer {
      left: 0;
    }

    form .btn input[type="submit"] {
      height: 100%;
      width: 100%;
      z-index: 1;
      position: relative;
      background: none;
      border: none;
      color: #fff;
      padding-left: 0;
      border-radius: 15px;
      font-size: 20px;
      font-weight: 500;
      cursor: pointer;
    }
  </style>
  <!--bootstrap.css-->
  <script src="../../js/6be23040d4.js"></script>
</head>

<body class="login_form">

  <!-- header section starts  -->
  <nav>
    <div class="menu-icon">
      <span class="fas fa-bars"></span>
      <div class="cancel-icon">
        <span class="fas fa-times"></span>
      </div>
    </div>
    <div class="logo">
      <img src="../../images/1.png" alt="" style="padding-top: -10px;">
    </div>
    <div class="nav-items">
      <li><a href="../home/index.php">Home</a></li>
      <li><a href="../about/index.php">About Us</a></li>
      <li><a href="../places/index.php">Places</a></li>
      <li><a href="../hotels/index.php">Hotels</a></li>
      <?php
      if (isset($_SESSION['hotel'])) {
        ?>
        <li><a href="../hotelsmanagement/bookingmanage.php">BookingManage</a></li>
        <?php
      } else {
        ?>
        <li><a href="../Booking/index.php">Booking</a></li>
        <?php
      }
      // $pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");
      // if (isset($_SESSION['user'])) {
      //   header("Location: ../home/index.php");
      // } elseif (isset($_SESSION['hotel'])) {
      //   header("Location: ../home/index.php");
      // } elseif (isset($_SESSION['Admin'])) {
      //   header("Location: ../../Admin/index.php");
      // }
      ?>
    </div>

  </nav>
  </div>
  <!-- </section> -->

  <body>

    <div class="wrapper">
      <div class="title-text">
        <div class="title login">Login Form</div>
        <div class="title signup">Signup Form</div>
      </div>
      <div class="form-container">
        <div class="slide-controls">
          <input type="radio" name="slide" id="login" checked>
          <input type="radio" name="slide" id="signup">
          <label for="login" class="slide login">Login</label>
          <label for="signup" class="slide signup">Signup</label>
          <div class="slider-tab"></div>
        </div>
        <div class="form-inner">
          <form action="./loginprocess.php" method="POST" onSubmit="return checkPassword(this)" class="login">
            <div class="field">
              <input type="email" name="email" placeholder="Email Address" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Password" name="loginpassword" id="loginpassword" required>
            </div>
            <!-- <div class="pass-link"><a href="#">Forgot password?</a></div> -->
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Login" name="loginbutton">
            </div>
            <div class="signup-link">Not a member? <a href="">Signup now</a></div>
          </form>

          <form action="./loginprocess.php" method="POST" onSubmit="return checkPassword(this)" class="signup">
            <div class="field">
              <input type="text" placeholder="Name" name="NAME" required>
            </div>
            <div class="field">
              <input type="text" placeholder="Mobile Number" name="MOBILENO" required>
            </div>
            <div class="field">
              <input type="text" placeholder="Email Address" name="EMAIL" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Password" name="PASSWORD1" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Confirm password" name="PASSWORD2" required>
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Signup" name="signupbutton">
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- JavaScript -->
    <script>
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = (() => {
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      });
      loginBtn.onclick = (() => {
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      });
      signupLink.onclick = (() => {
        signupBtn.click();
        return false;
      });

    </script>
    <script>
      function checkPassword(form) {
        password1 = form.PASSWORD1.value;
        password2 = form.PASSWORD2.value;

        // If password not entered
        if (password1 == '')
          alert("Please enter Password");

        // If confirm password not entered
        else if (password2 == '')
          alert("Please enter confirm password");

        // If Not same return False.    
        else if (password1 != password2) {
          alert("\nPassword did not match: Please try again...")
          return false;
        }
      }
    </script>
    <?php
    include("../home/footer.php");
    ?>