<?php
include("../home/header.php");

$id = $_GET['id'];
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");

// Fetch place details
$statementplace = $pdo->prepare("SELECT * FROM places WHERE Id = ?");
$statementplace->execute([$id]);
$placerow = $statementplace->fetch();

if ($placerow) {
    $cityid = $placerow['City_id'];
?>
    <div class="heading" style="background:url(../../images/header-bg-2.png) no-repeat">
        <h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="padding-top: 0px; visibility: visible; animation-delay: 0.5s; animation-name: zoomIn; font-weight: bolder;">
            <?= htmlspecialchars($placerow['PlaceName']); ?> Details
        </h1>
    </div>

    <!-- Place Details -->
    <div class="selectroom">
        <div class="container">
            <form name="book" method="post">
                <div class="selectroom_top">
                    <div class="col-md-4 selectroom_left wow fadeInLeft animated" data-wow-delay=".5s">
                        <img src="../../images/<?= htmlspecialchars($placerow['Imagepath']); ?>" class="img-fluid" alt="" style="padding-top: 35px;">
                    </div>
                    <div class="col-md-8 selectroom_right wow fadeInRight animated" data-wow-delay=".5s">
                        <h1 style="padding-left: 10px; font-size: 40px"><?= htmlspecialchars($placerow['PlaceName']); ?></h1>
                        <?php
                        // Fetch city, state, and country information
                        $statementcity = $pdo->prepare("SELECT * FROM city WHERE Id = ?");
                        $statementcity->execute([$cityid]);
                        $placecity = $statementcity->fetch();

                        $stateid = $placecity['State_id'];
                        $statementstate = $pdo->prepare("SELECT * FROM states WHERE Id = ?");
                        $statementstate->execute([$stateid]);
                        $placestate = $statementstate->fetch();

                        $countryid = $placestate['Country_id'];
                        $statementcountry = $pdo->prepare("SELECT * FROM country WHERE Id = ?");
                        $statementcountry->execute([$countryid]);
                        $placecountry = $statementcountry->fetch();
                        ?>
                        <p style="font-size: 30px; font-weight: bolder; padding-left: 10px;">Country: <?= htmlspecialchars($placecountry['CountryName']); ?> </p>
                        <p style="font-size: 30px; font-weight: bolder; padding-left: 10px;">City: <?= htmlspecialchars($placecity['CityName']); ?> </p>
                        <div class="grand">
                            <p>&nbsp;</p>
                        </div>
                    </div>
                    <h1 style="text-justify: inter-word;">Details About <?= htmlspecialchars($placerow['PlaceName']); ?> :</h1>
                    <p style="padding-top: 1%; font-size: large; font-weight: bolder; text-align: justify; text-justify: inter-word; padding-left: 10px;">
                        <?= nl2br(htmlspecialchars($placerow['Discription'])); ?>
                    </p>
                </div>
            </form>
        </div>
    </div>

    <!-- Display Hotels in the Selected City -->
    <div class="heading" >
        <h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="padding-top: 0px; visibility: visible; animation-delay: 0.5s; animation-name: zoomIn; font-weight: bolder;">
            City <?= htmlspecialchars($placecity['CityName']); ?>
        </h1>
    </div>

    <section class="packages">
        <div class="box-container">
            <?php
            // Fetch hotels in the same city as the place
            $statementhotel = $pdo->prepare("SELECT * FROM hotels WHERE City_id = ?");
            $statementhotel->execute([$cityid]);
            $hotels = $statementhotel->fetchAll();

            if (count($hotels) > 0) {
                foreach ($hotels as $hotel) {
            ?>
                    <div class="box">
                        <div class="image">
                            <img src="../../images/<?= htmlspecialchars($hotel['Imagespath']); ?>" alt="" />
                        </div>
                        <div class="content">
                            <h3><?= htmlspecialchars($hotel['HotelName']); ?></h3>
                            <h4><?= htmlspecialchars($placecity['CityName']); ?> - <?= htmlspecialchars($placestate['StateName']); ?> (<?= htmlspecialchars($placecountry['CountryName']); ?>)</h4>
                            <a href="hoteldetails.php?id=<?= $hotel['Id']; ?>" class="btn">View More</a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p style="text-align: center; width: 100%; margin-top: 50px; font-size: 18px; color: #999;">No hotels found in this city.</p>';
            }
            ?>
        </div>
    </section>

<?php
} else {
    echo '<p>Place not found.</p>';
}
?>

<?php
include("../home/footer.php");
?>


hotle not founc this city then in read boostrap msg in thisb ased used are wie eay this based 