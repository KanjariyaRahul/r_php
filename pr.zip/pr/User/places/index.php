<?php 
    include("../home/header.php");
    include("./content.php");
    include("../home/footer.php");
?>