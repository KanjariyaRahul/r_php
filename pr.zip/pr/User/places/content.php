<?php
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");

// Get filter values
$selectedCountry = $_GET['country'] ?? '';
$selectedState   = $_GET['state'] ?? '';
$selectedCity    = $_GET['city'] ?? '';

// Fetch countries
$countries = $pdo->query("SELECT * FROM country")->fetchAll();

// Fetch states based on selected country
$states = [];
if ($selectedCountry) {
   $stmt = $pdo->prepare("SELECT * FROM states WHERE Country_id = ?");
   $stmt->execute([$selectedCountry]);
   $states = $stmt->fetchAll();
}

// Fetch cities based on selected state
$cities = [];
if ($selectedState) {
   $stmt = $pdo->prepare("SELECT * FROM city WHERE State_id = ?");
   $stmt->execute([$selectedState]);
   $cities = $stmt->fetchAll();
}

// Main query for places with LEFT JOINs
$sql = "
   SELECT 
      places.*, 
      city.CityName, 
      states.StateName, 
      country.CountryName
   FROM places
   LEFT JOIN city ON places.City_id = city.Id
   LEFT JOIN states ON city.State_id = states.Id
   LEFT JOIN country ON states.Country_id = country.Id
   WHERE places.place_delete = 0
";

$params = [];

if ($selectedCountry) {
   $sql .= " AND country.Id = ?";
   $params[] = $selectedCountry;
}
if ($selectedState) {
   $sql .= " AND states.Id = ?";
   $params[] = $selectedState;
}
if ($selectedCity) {
   $sql .= " AND city.Id = ?";
   $params[] = $selectedCity;
}

$placeStmt = $pdo->prepare($sql);
$placeStmt->execute($params);
$places = $placeStmt->fetchAll();
?>

<!-- Heading -->
<div class="heading" style="background:url(../../images/header-bg-2.png) no-repeat">
   <h1 class="wow zoomIn animated" style="padding-top: 0px; font-weight: bolder;">Places</h1>
</div>

<section class="packages">
   <!-- Filter Form -->
   <form method="GET" style="margin-bottom: 20px; text-align: right;">
      <!-- Country Dropdown -->
      <select name="country" onchange="this.form.submit()" >
         <option value="">Select Country</option>
         <?php foreach ($countries as $country): ?>
            <option value="<?= $country['Id'] ?>" <?= ($selectedCountry == $country['Id']) ? 'selected' : '' ?>>
               <?= $country['CountryName'] ?>
            </option>
         <?php endforeach; ?>
      </select>

      <!-- State Dropdown -->
      <select name="state" onchange="this.form.submit()" >
         <option value="">Select State</option>
         <?php foreach ($states as $state): ?>
            <option value="<?= $state['Id'] ?>" <?= ($selectedState == $state['Id']) ? 'selected' : '' ?>>
               <?= $state['StateName'] ?>
            </option>
         <?php endforeach; ?>
      </select>

      <!-- City Dropdown -->
      <select name="city" onchange="this.form.submit()" >
         <option value="">Select City</option>
         <?php foreach ($cities as $city): ?>
            <option value="<?= $city['Id'] ?>" <?= ($selectedCity == $city['Id']) ? 'selected' : '' ?>>
               <?= $city['CityName'] ?>
            </option>
         <?php endforeach; ?>
      </select>
   </form>

   <!-- Places Listing -->
   <div class="box-container">
      <?php if (count($places) > 0): ?>
         <?php foreach ($places as $place): ?>
            <div class="box">
               <div class="image">
                  <img src="../../images/<?= htmlspecialchars($place['Imagepath']); ?>" alt="">
               </div>
               <div class="content">
                  <h3><?= htmlspecialchars($place['PlaceName']); ?></h3>
                  <h4><?= htmlspecialchars($place['CityName']) ?> - <?= $place['StateName'] ?> (<?= $place['CountryName'] ?>)</h4>
                  <a href="placedetails.php?id=<?= $place['Id'] ?>">
                     <button class="btn">View More</button>
                  </a>
               </div>
            </div>
         <?php endforeach; ?>
      <?php else: ?>
         <div style="text-align: center; width: 100%; margin-top: 50px;">
            <h3 style="color: #999;">No places found matching your criteria.</h3>
         </div>
      <?php endif; ?>
   </div>
</section>

this code are in pacle selecte then details open then this page this place slected city are in hotal are show in bottom thisb ased give me full code 

//placedetails.php 

<?php
include("../home/header.php");
?>
<?php
$id = $_GET['id'];
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");
$statementplace = $pdo->prepare("SELECT * FROM places WHERE Id=$id");
$statementplace->execute();
while ($placerow = $statementplace->fetch()) {
	$cityid = $placerow['City_id'];
?>
		<div class="heading" style="background:url(../../images/header-bg-2.png) no-repeat">
			<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="padding-top: 0px; visibility: visible; animation-delay: 0.5s; animation-name: zoomIn; font-weight: bolder;"><?= $placerow['PlaceName']; ?> Details</h1>
		</div>
	
	<!--- selectroom ---->
	<div class="selectroom">
		<div class="container">

			<form name="book" method="post">
				<div class="selectroom_top">
					<div class="col-md-4 selectroom_left wow fadeInLeft animated" data-wow-delay=".5s">
						<img src="../../images/<?= $placerow['Imagepath']; ?>" class="img-fluid" alt="" style="padding-top: 35px;">
					</div>
					<div class="col-md-8 selectroom_right wow fadeInRight animated" data-wow-delay=".5s">
						<h2></h2>
						<p class="dow">&nbsp;</p>
						<h1 style="padding-left: 10px; font-size: 40px"><?= $placerow['PlaceName']; ?></h1>
						<?php
						$statementcity = $pdo->prepare("SELECT * FROM city where Id=?");
						$statementcity->execute(array($cityid));
						$placecity = $statementcity->fetch();
						$stateid = $placecity['State_id'];
						$statementstate = $pdo->prepare("SELECT * FROM states where Id=?");
						$statementstate->execute(array($stateid));
						$placestate = $statementstate->fetch();
						$countryid = $placestate['Country_id'];
						
						$statementcountry = $pdo->prepare("SELECT * FROM country where Id=$countryid");
						$statementcountry->execute();
						$placecountry = $statementcountry->fetch();
						?>
						<p style="font-size: 30px; font-weight: bolder; padding-left: 10px;">Country : <?= $placecountry['CountryName']; ?> </p>
						<p style="font-size: 30px; font-weight: bolder; padding-left: 10px;">City : <?= $placecity['CityName']; ?> </p>
						<div class="grand">
							<p>&nbsp;</p>
							<h3>&nbsp; </h3>
						</div>
					</div>
					<h1 style="text-justify: inter-word;">Details About <?= $placerow['PlaceName']; ?> :</h1>
					<p style="padding-top: 1%; font-size: large; font-weight: bolder; text-align: justify; text-justify: inter-word; padding-left: 10px;"><?= $placerow['Discription']; ?></p>
					<div class="clearfix"></div>
				</div>
			<?php
		}
			?>
			</form>


		</div>
	</div>
	<?php
	include("../home/footer.php");
	?>