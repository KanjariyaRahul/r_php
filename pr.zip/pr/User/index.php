<?php
header("Location: ./home/");
?>