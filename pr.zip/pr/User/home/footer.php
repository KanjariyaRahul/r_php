<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="../home/index.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="../about/index.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="../places/index.php"> <i class="fas fa-angle-right"></i> Places</a>
         <a href="../hotels/index.php"> <i class="fas fa-angle-right"></i>Hotels</a>
      </div>
<!-- 
      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div> -->

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
         <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
         <a href="#"> <i class="fas fa-envelope"></i> ShivTourism@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Gujrat, india - 400104 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Vala Divyrajsinh And Vora Chirag</span> | all rights reserved! </div>

</section>

<!-- swiper js link  -->
<script src="../../js/bootstrap.js"></script>
<script src="../../js/swiper-bundle.min.js"></script>
<script src="../../js/jquery-3.3.1.slim.min.js"></script>
<!-- <script src='../../js/popper.min.js'></script> -->
<script src='../../js/bootstrap.min.js'></script>
<script src="../../js/jquery-3.6.0.min.js"></script>
<!-- custom js file link  -->
<script src="../../js/script.js"></script>
</body>

</html>