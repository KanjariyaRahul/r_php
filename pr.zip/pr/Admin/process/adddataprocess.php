<?php
include '../config/config.php';

session_start();
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");


if (isset($_POST['addplace']) || isset($_POST['updateplace'])) {
    $file_name = $_FILES['placeimage']['name'];
    $file_tmp_name = $_FILES['placeimage']['tmp_name'];
    $upload_dir = "../../images/";
    $image_path = $upload_dir . $file_name;

    $placename = $_POST['placename'];
    $city_id = $_POST['citys'];
    $detail = $_POST['detail'];

    if (isset($_POST['addplace'])) {
        // INSERT Operation
        $statementplace = $pdo->prepare("INSERT INTO places (PlaceName, City_id, Discription, Imagepath) VALUES (?, ?, ?, ?)");
        $result = $statementplace->execute([$placename, $city_id, $detail, $file_name]);

        if ($result) {
            move_uploaded_file($file_tmp_name, $image_path);
            echo "<SCRIPT>alert('Place Added Successfully!');window.location.replace('../add_place.php');</SCRIPT>";
        }
    }

    elseif (isset($_POST['updateplace']) && isset($_GET['id'])) {
        $id = $_GET['id'];

        // If a new image is uploaded
        if (!empty($file_name)) {
            $statementplace = $pdo->prepare("UPDATE places SET PlaceName = ?, City_id = ?, Discription = ?, Imagepath = ? WHERE Id = ?");
            $result = $statementplace->execute([$placename, $city_id, $detail, $file_name, $id]);

            if ($result) {
                move_uploaded_file($file_tmp_name, $image_path);
            }
        } else {
            // No image selected, keep old image
            $statementplace = $pdo->prepare("UPDATE places SET PlaceName = ?, City_id = ?, Discription = ? WHERE Id = ?");
            $result = $statementplace->execute([$placename, $city_id, $detail, $id]);
        }

        if ($result) {
            echo "<SCRIPT>alert('Place Updated Successfully!');window.location.replace('../manage_places.php');</SCRIPT>";
        }
    }
}


// Add/Edit Hotels
if (isset($_POST['addhotel']) || isset($_POST['updatehotel'])) {
    $hfile_name = $_FILES['hotelimage']['name'];
    $hfile_tmp_name = $_FILES['hotelimage']['tmp_name'];
    $hpath = "../../images/" . $hfile_name;

    $placename = $_POST['hotelname'];
    $pdprice = $_POST['pdprice'];
    $city_id = $_POST['citys'];
    $userid = $_POST['User'];
    $detail = $_POST['detail'];

    if (isset($_POST['addhotel'])) {
        // INSERT logic
        $statementhotel = $pdo->prepare("INSERT INTO hotels (HotelName, PerDayPrice, City_id, Hoteldetail, Imagespath, User_id) VALUES (?, ?, ?, ?, ?, ?)");
        $statementhotel->execute([$placename, $pdprice, $city_id, $detail, $hfile_name, $userid]);

        if ($statementhotel) {
            move_uploaded_file($hfile_tmp_name, $hpath);
            echo "<script>alert('Hotel Added Successfully!'); window.location.replace('../add_hotel.php');</script>";
        }

    } elseif (isset($_POST['updatehotel']) && isset($_GET['id'])) {
        $id = $_GET['id'];

        // If a new image is uploaded
        if (!empty($hfile_name)) {
            $sql = "UPDATE hotels SET HotelName=?, PerDayPrice=?, City_id=?, Hoteldetail=?, Imagespath=?, User_id=? WHERE Id=?";
            $statementhotel = $pdo->prepare($sql);
            $statementhotel->execute([$placename, $pdprice, $city_id, $detail, $hfile_name, $userid, $id]);

            if ($statementhotel) {
                move_uploaded_file($hfile_tmp_name, $hpath);
                echo "<script>alert('Hotel Updated with new image successfully!'); window.location.replace('../add_hotel.php');</script>";
            }

        } else {
            // No new image, keep the old one
            $sql = "UPDATE hotels SET HotelName=?, PerDayPrice=?, City_id=?, Hoteldetail=?, User_id=? WHERE Id=?";
            $statementhotel = $pdo->prepare($sql);
            $statementhotel->execute([$placename, $pdprice, $city_id, $detail, $userid, $id]);

            echo "<script>alert('Hotel Updated successfully!'); window.location.replace('../manage_hotels.php');</script>";
        }
    }
}


?>