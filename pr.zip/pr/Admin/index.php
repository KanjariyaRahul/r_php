<?php 
function getRowCount(PDO $pdo, string $tableName): int {
    $stmt = $pdo->prepare("SELECT Id FROM $tableName");
    $stmt->execute();
    return $stmt->rowCount();
}

$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");

// get counts
$usercount = getRowCount($pdo, "users");
$placecount = getRowCount($pdo, "places");
$hotelcount = getRowCount($pdo, "hotels");
$bookingcount = getRowCount($pdo, "booking");

include_once 'includes/header.php'
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper">

                            <div class="page-body">
                                <div class="row">

                                    <!-- Cards-card start -->
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card bg-c-blue order-card">
                                            <div class="card-block">
                                                <h6 class="m-b-20">Total Users</h6>
                                                <h2 class="text-right"><i class="ti-shopping-cart f-left"></i><span><?php echo $usercount; ?></span>
                                                </h2>
                                                <!-- <p class="m-b-0">Today Registered Users<span class="f-right">NA</span> </p> -->
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-xl-3">
                                        <div class="card bg-c-green order-card">
                                            <div class="card-block">
                                                <h6 class="m-b-20">Total Torist Place</h6>
                                                <h2 class="text-right"><i class="ti-tag f-left"></i><span><?php echo $placecount; ?></span>
                                                </h2>
                                                <!-- <p class="m-b-0">New Places<span class="f-right">NA</span></p> -->
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-xl-3">
                                        <div class="card bg-c-yellow order-card">
                                            <div class="card-block">
                                                <h6 class="m-b-20">Total Hotels</h6>
                                                <h2 class="text-right"><i
                                                        class="ti-reload f-left"></i><span><?php echo $hotelcount; ?></span></h2>
                                                <!-- <p class="m-b-0">New Hotels<span class="f-right">NA</span></p> -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card bg-c-pink order-card">
                                            <div class="card-block">
                                                <h6 class="m-b-20">Total Bookings</h6>
                                                <h2 class="text-right"><i class="ti-wallet f-left"></i><span><?php echo $bookingcount; ?></span>
                                                </h2>
                                                <!-- <p class="m-b-0">Canceled Booking<span class="f-right">NA</span></p> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Cards-card end -->

                                </div>
                            </div>

                            <div id="styleSelector">

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>