<?php 
include_once 'includes/header.php';

$sql = "
    SELECT 
        p.Id,
        p.PlaceName,
        p.Imagepath,
        p.Discription,
        p.place_delete,
        c.CityName,
        s.StateName,
        co.CountryName
    FROM places p
    JOIN city c ON p.City_id = c.Id
    JOIN states s ON c.State_id = s.Id
    JOIN country co ON s.Country_id = co.Id
    WHERE p.place_delete = 0
";
$statement = $pdo->prepare($sql);
$statement->execute();
$places = $statement->fetchAll(PDO::FETCH_ASSOC);
?>
    <style>
        .btn-delete {
            background-color: orangered;
            color: white;
            border: none;
            padding: 4px 10px;
            border-radius: 4px;
        }
        .btn-update {
            background-color: dodgerblue;
            color: white;
            border: none;
            padding: 4px 10px;
            border-radius: 4px;
        }
        img.place-img {
            height: 100px;
            object-fit: cover;
            border-radius: 6px;
        }
        .card-option li {
            display: inline-block;
            margin-left: 10px;
            cursor: pointer;
        }
    </style>
<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper">

                                                    <!-- Page-header start -->
                                                    <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">Manage Places</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="manage_places.php">Manage Places</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                            <div class="page-body">
    <!-- Hover table card start -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <h5>Places Table</h5>
            </div>
            <div class="card-header-right">
                <ul class="list-unstyled card-option">
                    <li><i class="fa fa-chevron-left"></i></li>
                    <li><i class="fa fa-window-maximize full-card"></i></li>
                    <li><i class="fa fa-minus minimize-card"></i></li>
                    <li><i class="fa fa-refresh reload-card"></i></li>
                    <li><i class="fa fa-times close-card"></i></li>
                </ul>
            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table id="placesTable" class="table table-hover display">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Place Name</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Country</th>
                            <!-- <th>Details</th> -->
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($places as $place): ?>
                            <tr>
                                <td><img src="../images/<?= htmlspecialchars($place['Imagepath']) ?>" alt="Image" class="place-img"></td>
                                <td><?= htmlspecialchars($place['PlaceName']) ?></td>
                                <td><?= htmlspecialchars($place['CityName']) ?></td>
                                <td><?= htmlspecialchars($place['StateName']) ?></td>
                                <td><?= htmlspecialchars($place['CountryName']) ?></td>
                                <!-- <td><?= htmlspecialchars($place['Discription']) ?></td> -->
                                <td>
                                    <a href="./add_place.php?id=<?= $place['Id'] ?>">
                                        <button class="btn-update">Update</button>
                                    </a>
                                    <a href="./process/deleteplace.php?id=<?= $place['Id'] ?>" onclick="return confirm('You want to delete this place?')">
                                        <button class="btn-delete">Delete</button>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Image</th>
                            <th>Place Name</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Country</th>
                            <!-- <th>Details</th> -->
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <!-- Hover table card end -->
                            </div>

                            <div id="styleSelector">

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>