<?php
include_once 'includes/header.php';
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <?php include_once 'includes/navbar.php' ?>

                <div class="pcoded-main-container">
                    <div class="pcoded-wrapper">

                        <?php include_once 'includes/sidebar.php' ?>

                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">Add New Place</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="manage_places.php">Manage Places</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="add_user.php   ">Add New Place</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                                <!-- Page body start -->
                                <div class="page-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <!-- Basic Form Inputs card start -->
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Add New Place</h5>
                                                    <div class="card-header-right"><i class="icofont icofont-spinner-alt-5"></i></div>

                                                    <div class="card-header-right">
                                                        <i class="icofont icofont-spinner-alt-5"></i>
                                                    </div>

                                                </div>
                                                <div class="card-block">
                                                <?php
require_once './config/config.php';

$isUpdate = false;
$placeData = [
    'PlaceName' => '',
    'City_id' => '',
    'State_id' => '',
    'Country_id' => '',
    'Discription' => '',
    'Imagepath' => ''
];

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare("
        SELECT 
            p.PlaceName, p.City_id, p.Discription, p.Imagepath, 
            c.State_id, 
            s.Country_id 
        FROM places p
        JOIN city c ON p.City_id = c.Id
        JOIN states s ON c.State_id = s.Id
        WHERE p.Id = ?
    ");
    
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        $placeData = $stmt->fetch(PDO::FETCH_ASSOC);
        $isUpdate = true;
    }
}

?>

<form action="./process/adddataprocess.php<?= $isUpdate ? '?id=' . $id : '' ?>" method="POST" enctype="multipart/form-data">


    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="placeimage">Upload Image</label>
        <div class="col-sm-10">
            <?php if ($isUpdate && !empty($placeData['Imagepath'])): ?>
                <img src="../images/<?= $placeData['Imagepath'] ?>" width="150" class="mb-2"><br>
            <?php endif; ?>
            <input type="file" class="form-control" id="placeimage" name="placeimage">
            <div class="col-form-label" id="error-placeimage"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="placename">Place Name</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="placename" name="placename" placeholder="Place name.."
                   value="<?= htmlspecialchars($placeData['PlaceName']) ?>">
            <div class="col-form-label" id="error-placename"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="country">Select Country</label>
        <div class="col-sm-10">
            <select class="form-control" name="country" id="country">
                <option value="">Select Country</option>
                <?php
                $statement = $pdo->prepare("SELECT * FROM country");
                $statement->execute();
                while ($row = $statement->fetch()) {
                ?>
                    <option value="<?= $row['Id']; ?>" <?= ($isUpdate && $row['Id'] == $placeData['Country_id']) ? 'selected' : '' ?>><?= $row['CountryName']; ?></option>
                <?php } ?>
            </select>
            <div class="col-form-label" id="error-country"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="state">Select State</label>
        <div class="col-sm-10">
            <select class="form-control" name="state" id="state">
                <option value="">Select State</option>
                <?php
                $bookstate = $pdo->prepare("SELECT * FROM States");
                $bookstate->execute();
                while ($selctstate = $bookstate->fetch()) {
                ?>
                    <option value="<?= $selctstate['Id']; ?>" <?= ($isUpdate && $selctstate['Id'] == $placeData['State_id']) ? 'selected' : '' ?>><?= $selctstate['StateName']; ?></option>
                <?php } ?>
            </select>
            <div class="col-form-label" id="error-state"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="citys">Select City</label>
        <div class="col-sm-10">
            <select class="form-control" name="citys" id="citys">
                <option value="">Select City</option>
                <?php
                $bookcity = $pdo->prepare("SELECT * FROM city");
                $bookcity->execute();
                while ($selectcity = $bookcity->fetch()) {
                ?>
                    <option value="<?= $selectcity['Id']; ?>" <?= ($isUpdate && $selectcity['Id'] == $placeData['City_id']) ? 'selected' : '' ?>><?= $selectcity['CityName'] ?></option>
                <?php } ?>
            </select>
            <div class="col-form-label" id="error-citys"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="placedetail">Place Details</label>
        <div class="col-sm-10">
            <textarea class="form-control" id="placedetail" name="detail" placeholder="Write something.." style="height:200px"><?= htmlspecialchars($placeData['Discription']) ?></textarea>
            <div class="col-form-label" id="error-placedetail"></div>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-10 offset-sm-2">
            <button type="submit" class="btn btn-success btn-square" name="<?= $isUpdate ? 'updateplace' : 'addplace' ?>">
                <?= $isUpdate ? 'Update' : 'ADD' ?>
            </button>
        </div>
    </div>

</form>

                                                </div>
                                            </div>
                            
                                        </div>
                                    </div>
                                </div>
                                <!-- Page body end -->
                            </div>
                        </div>

                    </div>
                </div>

                <?php include_once 'includes/footer.php' ?>

                <div id="styleSelector"></div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>