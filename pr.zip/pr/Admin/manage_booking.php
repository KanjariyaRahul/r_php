<?php 
include_once 'includes/header.php';

$sql = "
    SELECT 
        b.BookingDate,
        b.ArrivalDate,
        b.LeavingDate,
        b.Totaldays,
        b.TotalRooms,
        b.TotalPrice,
        b.cancle_booking,
        b.status AS hotel_response,
        u.Name AS UserName,
        h.HotelName
    FROM booking b
    JOIN users u ON b.User_id = u.Id
    JOIN hotels h ON b.Hotel_id = h.Id
    ORDER BY b.BookingDate DESC
";

$statement = $pdo->prepare($sql);
$statement->execute();
$bookings = $statement->fetchAll(PDO::FETCH_ASSOC);
?>
    <style>
        td, th {
            text-align: center;
            vertical-align: middle;
        }
        .card-option li {
            display: inline-block;
            margin-left: 10px;
            cursor: pointer;
        }
    </style>
<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper">
                                    <!-- Page-header start -->
                                    <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">Manage Bookings</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="manage_booking.php">Manage Bookings</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->
                            <div class="page-body">
    <!-- Hotel Table Starts -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <h5>Manage Bookings</h5>
            </div>
            <div class="card-header-right">
                <ul class="list-unstyled card-option">
                    <li><i class="fa fa-chevron-left"></i></li>
                    <li><i class="fa fa-window-maximize full-card"></i></li>
                    <li><i class="fa fa-minus minimize-card"></i></li>
                    <li><i class="fa fa-refresh reload-card"></i></li>
                    <li><i class="fa fa-times close-card"></i></li>
                </ul>
            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table id="bookingsTable" class="table table-hover table-bordered display">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Hotel Name</th>
                            <th>Booking Date</th>
                            <th>Arrival Date</th>
                            <th>Leaving Date</th>
                            <th>Total Days</th>
                            <th>Total Rooms</th>
                            <th>Total Price</th>
                            <th>Booking Status</th>
                            <th>Hotel Response</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <?php
                                $today = date("Y-m-d");
                                $bookingStatus = '';
                                $responseStatus = '';

                                // Hotel response logic
                                if (is_null($booking['hotel_response'])) {
                                    $responseStatus = $booking['cancle_booking'] != 1 ? 'Waiting For Response' : '';
                                } elseif ($booking['hotel_response'] == 0) {
                                    $responseStatus = 'Disapproved';
                                } elseif ($booking['hotel_response'] == 1) {
                                    $responseStatus = 'Approved';
                                }

                                // Booking status logic
                                if ($booking['cancle_booking'] == 1) {
                                    $bookingStatus = 'Booking Cancelled';
                                } elseif (strtotime($today) > strtotime($booking['LeavingDate'])) {
                                    $bookingStatus = 'Completed';
                                } else {
                                    $bookingStatus = 'Continue...';
                                }
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($booking['UserName']) ?></td>
                                <td><?= htmlspecialchars($booking['HotelName']) ?></td>
                                <td><?= htmlspecialchars($booking['BookingDate']) ?></td>
                                <td><?= htmlspecialchars($booking['ArrivalDate']) ?></td>
                                <td><?= htmlspecialchars($booking['LeavingDate']) ?></td>
                                <td><?= htmlspecialchars($booking['Totaldays']) ?></td>
                                <td><?= htmlspecialchars($booking['TotalRooms']) ?></td>
                                <td><?= htmlspecialchars($booking['TotalPrice']) ?></td>
                                <td><?= $responseStatus ?></td>
                                <td><?= $bookingStatus ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>User Name</th>
                            <th>Hotel Name</th>
                            <th>Booking Date</th>
                            <th>Arrival Date</th>
                            <th>Leaving Date</th>
                            <th>Total Days</th>
                            <th>Total Rooms</th>
                            <th>Total Price</th>
                            <th>Booking Status</th>
                            <th>Hotel Response</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
     <!-- Hotel Table Ends -->

                            </div>

                            <div id="styleSelector">

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>



<?php include_once 'includes/footer.php' ?>