<!-- Sidebar Section -->
<nav class="pcoded-navbar">
    <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
    <div class="pcoded-inner-navbar main-menu">

        <div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation">Main</div>
        <ul class="pcoded-item pcoded-left-item">
            <li class="active">
                <a href="index.php">
                    <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                    <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li>
        </ul>
        <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms">Manage system</div>
        <ul class="pcoded-item pcoded-left-item">
            <!-- Manage Users     -->
            <li class="pcoded-hasmenu">
                <a href="javascript:void(0)">
                    <span class="pcoded-micon"><i class="ti-user"></i></span>
                    <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Manage Users</span>
                    <span class="pcoded-mcaret"></span>
                </a>
                <ul class="pcoded-submenu">
                    <li class=" ">
                        <a href="manage_users.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Manage Users</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                    <li class=" ">
                        <a href="add_user.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Add New User</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Manage Places     -->
            <li class="pcoded-hasmenu">
                <a href="javascript:void(0)">
                    <span class="pcoded-micon"><i class="ti-location-pin"></i></span>
                    <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Manage Places</span>
                    <span class="pcoded-mcaret"></span>
                </a>
                <ul class="pcoded-submenu">
                    <li class=" ">
                        <a href="manage_places.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Manage Places</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                    <li class=" ">
                        <a href="add_place.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Add New
                                Places</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Manage Hotels     -->
            <li class="pcoded-hasmenu">
                <a href="javascript:void(0)">
                    <span class="pcoded-micon"><i class="ti-map"></i></span>
                    <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Manage Hotels</span>
                    <span class="pcoded-mcaret"></span>
                </a>
                <ul class="pcoded-submenu">
                    <li class="">
                        <a href="manage_hotels.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Manage Hotels</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                    <li class=" ">
                        <a href="add_hotel.php">
                            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                            <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Add New
                                Hotel</span>
                            <span class="pcoded-mcaret"></span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>

        <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms">Booking Managment</div>
        <ul class="pcoded-item pcoded-left-item">
            <li>
                <a href="manage_booking.php">
                    <span class="pcoded-micon"><i class="ti-notepad"></i><b>FC</b></span>
                    <span class="pcoded-mtext" data-i18n="nav.form-components.main">View Bookings</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li>
            <!-- <li>
                <a href="#">
                    <span class="pcoded-micon"><i class="ti-plus"></i><b>FC</b></span>
                    <span class="pcoded-mtext" data-i18n="nav.form-components.main">New Booking</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li> -->
        </ul>

        <div class="pcoded-navigatio-lavel" data-i18n="nav.category.other">Other</div>
        <ul class="pcoded-item pcoded-left-item">
        <!-- <li>
        <a href="#">
            <span class="pcoded-micon"><i class="ti-settings"></i><b>ST</b></span>
            <span class="pcoded-mtext" data-i18n="nav.form-components.main">Settings</span>
            <span class="pcoded-mcaret"></span>
        </a>

            </li> -->
        <li>
        <a href="./auth/logout.php" onclick="return confirm('Are you sure you want to logout?')">
            <span class="pcoded-micon"><i class="ti-power-off"></i><b>LG</b></span>
            <span class="pcoded-mtext" data-i18n="nav.form-components.main">Logout</span>
            <span class="pcoded-mcaret"></span>
        </a>

            </li>
        </ul>
    </div>
</nav>