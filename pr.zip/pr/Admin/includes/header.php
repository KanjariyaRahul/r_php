<?php
session_start();
require_once './config/config.php';

// Function to check if a user is logged in and has the correct session
function checkUserLogin($userType) {
    // Check if the session for the specific user type is set
    if (!isset($_SESSION[$userType])) {
        // If the session for the user type is not set, redirect to the login page
        header("Location: ./auth/login.php"); // Change 'login.php' to your actual login page URL
        exit(); // Stop further execution to prevent unauthorized access
    }
}

// Example usage: Check if Admin is logged in
checkUserLogin('Admin');

// Example usage: Check if Hotel is logged in
// checkUserLogin('Hotel');

// Example usage: Check if User is logged in
// checkUserLogin('User');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin Panel</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="description"
    content="Gradient Able Bootstrap admin template made using Bootstrap 4. The starter version of Gradient Able is completely free for personal project." />
  <meta name="keywords"
    content="free dashboard template, free admin, free bootstrap template, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
  <meta name="author" content="codedthemes">
  <!-- Favicon icon -->
  <link rel="icon" href="assets/images/avatar.png" type="image/x-icon">
  <!-- Google font-->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
  <!-- Required Fremwork -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap/css/bootstrap.min.css">
  <!-- themify-icons line icon -->
  <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
  <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
  <!-- ico font -->
  <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
  <!-- Style.css -->
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="assets/css/jquery.mCustomScrollbar.css">
  <style>
    /* Message Box */
#toast_container {
  position: fixed;
  top: 40px;
  right: 30px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.cpms-toast {
  display: flex;
  align-items: center;
  justify-content: space-between;
  /* min-width: 250px; */
  max-width: 350px;
  padding: 12px 16px;
  border-radius: 6px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  color: #fff;
  font-size: 15px;
  animation: slideIn 0.3s ease-out;
  display: none;
}

.cpms-toast-success {
  background-color: #2e7d32;
}

.cpms-toast-error {
  background-color: #c62828;
}

.cpms-toast-info {
  background-color: #0277bd;
}

.cpms-toast-close {
  margin-left: 12px;
  cursor: pointer;
  font-weight: bold;
  font-size: 16px;
  color: #fff;
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

  </style>

</head>

<body>
<div id="toast_container"></div>

  <!-- Pre-loader start -->
  <div class="theme-loader">
    <div class="loader-track">
      <div class="loader-bar"></div>
    </div>
  </div>
  <!-- Pre-loader end -->
  <div id="pcoded" class="pcoded">
    <div class="pcoded-overlay-box"></div>