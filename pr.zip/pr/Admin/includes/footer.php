<!-- Footer section -->
<script type="text/javascript" src="assets/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap/js/bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="assets/js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="assets/js/modernizr/modernizr.js"></script>
<!-- am chart -->
<script src="assets/pages/widget/amchart/amcharts.min.js"></script>
<script src="assets/pages/widget/amchart/serial.min.js"></script>
<!-- Chart js -->
<script type="text/javascript" src="assets/js/chart.js/Chart.js"></script>
<!-- Todo js -->
<script type="text/javascript " src="assets/pages/todo/todo.js "></script>
<!-- Custom js -->
<script type="text/javascript" src="assets/pages/dashboard/custom-dashboard.min.js"></script>
<script type="text/javascript" src="assets/js/script.js"></script>
<script type="text/javascript " src="assets/js/SmoothScroll.js"></script>
<script src="assets/js/pcoded.min.js"></script>
<script src="assets/js/vartical-demo.js"></script>
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>

<script>
      function show_message(type, message) {
    const toastClass = type === "success" ? "cpms-toast-success"
                    : type === "error" ? "cpms-toast-error"
                    : "cpms-toast-info";
  
    const $toast = $(`
      <div class="cpms-toast ${toastClass}">
        <span class="cpms-toast-message">${message}</span>
        <span class="cpms-toast-close">&times;</span>
      </div>
    `);
  
    $("#toast_container").append($toast);
  
    // Fade in
    $toast.fadeIn(300);
  
    // Auto dismiss
    setTimeout(() => {
      $toast.fadeOut(500, function () {
        $(this).remove();
      });
    }, 3000);
  }
  
  // Manual close
  $(document).on("click", ".cpms-toast-close", function () {
    $(this).closest(".cpms-toast").fadeOut(300, function () {
      $(this).remove();
    });
  });

  </script>
</body>

</html>