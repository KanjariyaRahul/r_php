<?php
include_once 'includes/header.php';
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <?php include_once 'includes/navbar.php' ?>

                <div class="pcoded-main-container">
                    <div class="pcoded-wrapper">

                        <?php include_once 'includes/sidebar.php' ?>

                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">Add New Hotel</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="manage_hotels.php">Manage Hotels</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="add_hotel.php   ">Add New Hotel</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                                <!-- Page body start -->
                                <div class="page-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <!-- Basic Form Inputs card start -->
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Add New Hotel</h5>
                                                    <div class="card-header-right"><i
                                                            class="icofont icofont-spinner-alt-5"></i></div>

                                                    <div class="card-header-right">
                                                        <i class="icofont icofont-spinner-alt-5"></i>
                                                    </div>

                                                </div>
                                                <div class="card-block">
                                                <?php
require_once './config/config.php';

$isUpdate = false;
$hotelData = [
    'HotelName' => '',
    'PerDayPrice' => '',
    'CityId' => '',
    'UserId' => '',
    'Details' => '',
    'Imagespath' => ''
];

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM hotels WHERE Id = ?");
    $stmt->execute([$id]);
    if ($stmt->rowCount() > 0) {
        $hotelData = $stmt->fetch(PDO::FETCH_ASSOC);
        $isUpdate = true;
    }
}
?>

<form action="./process/adddataprocess.php<?= $isUpdate ? '?id=' . $id : '' ?>" method="POST" enctype="multipart/form-data">

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="hotelimage">Upload Image</label>
        <div class="col-sm-10">
            <?php if ($isUpdate && !empty($hotelData['Imagespath'])): ?>
                <img src="../images/<?= $hotelData['Imagespath'] ?>" alt="Hotel Image" width="150" class="mb-2"><br>
            <?php endif; ?>
            <input type="file" class="form-control" id="hotelimage" name="hotelimage">
            <div class="col-form-label" id="error-hotelimage"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="hotelname">Hotel Name</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="hotelname" name="hotelname" placeholder="Hotel name.."
                   value="<?= htmlspecialchars($hotelData['HotelName']) ?>">
            <div class="col-form-label" id="error-hotelname"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="pdprice">Per Day Price</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="pdprice" name="pdprice" placeholder="Hotel Per Day Price.."
                   value="<?= htmlspecialchars($hotelData['PerDayPrice']) ?>">
            <div class="col-form-label" id="error-pdprice"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="citys">Select City</label>
        <div class="col-sm-10">
            <select class="form-control" name="citys" id="citys">
                <option value="">Select City</option>
                <?php
                $bookcity = $pdo->prepare("SELECT * FROM city");
                $bookcity->execute();
                while ($selectcity = $bookcity->fetch()) {
                ?>
                    <option value="<?= $selectcity['Id']; ?>"
                        <?= ($isUpdate && $selectcity['Id'] == $hotelData['City_id']) ? 'selected' : '' ?>>
                        <?= $selectcity['CityName'] ?>
                    </option>
                <?php } ?>
            </select>
            <div class="col-form-label" id="error-citys"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="User">Select User</label>
        <div class="col-sm-10">
            <select class="form-control" name="User" id="User">
                <option value="">Select User</option>
                <?php
                $hotelUser = $pdo->prepare("SELECT * FROM users WHERE UserType = 'H'");
                $hotelUser->execute();
                while ($hotelUsers = $hotelUser->fetch()) {
                ?>
                    <option value="<?= $hotelUsers['Id']; ?>"
                        <?= ($isUpdate && $hotelUsers['Id'] == $hotelData['User_id']) ? 'selected' : '' ?>>
                        <?= $hotelUsers['Name'] ?>
                    </option>
                <?php } ?>
            </select>
            <div class="col-form-label" id="error-User"></div>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label" for="placedetail">Hotel Details</label>
        <div class="col-sm-10">
            <textarea class="form-control" id="placedetail" name="detail" placeholder="Write something.." style="height:200px"><?= htmlspecialchars($hotelData['Hoteldetail']) ?></textarea>
            <div class="col-form-label" id="error-placedetail"></div>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-10 offset-sm-2">
            <button type="submit" class="btn btn-success btn-square" name="<?= $isUpdate ? 'updatehotel' : 'addhotel' ?>">
                <?= $isUpdate ? 'Update' : 'ADD' ?>
            </button>
        </div>
    </div>

</form>



                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- Page body end -->
                            </div>
                        </div>

                    </div>
                </div>

                <?php include_once 'includes/footer.php' ?>

                <div id="styleSelector"></div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>