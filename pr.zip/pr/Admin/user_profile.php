<?php
include_once 'includes/header.php';
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <?php include_once 'includes/navbar.php' ?>

                <div class="pcoded-main-container">
                    <div class="pcoded-wrapper">

                        <?php include_once 'includes/sidebar.php' ?>

                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">My Profile</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="user_profile.php">My Profile</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                                <!-- Page body start -->
                                <div class="page-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="card user-card">
                                                <div class="card-header">
                                                    <h5>Profile</h5>
                                                </div>
                                                <div class="card-block">
                                                    <div class="usre-image">
                                                        <img src="assets/images/avatar.png" class="img-radius" width="100px" height="100px"
                                                            alt="User-Profile-Image">
                                                    </div>
                                                    <h6 class="f-w-600 m-t-25 m-b-10">Admin user</h6>
                                                    <p class="text-muted">Role: Administrator</p>
                                                    <hr>
                                                    <div class="col-sm-12">


                                                        <!-- Tab variant tab card start -->

                                                        <div class="card-header">
                                                            <h5>Edit My Profile</h5>

                                                        </div>

                                                        <div class="card-block tab-icon">
                                                            <!-- Row start -->
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <!-- Nav tabs -->
                                                                    <ul class="nav nav-tabs md-tabs " role="tablist">
                                                                        <li class="nav-item">
                                                                            <a class="nav-link active" data-toggle="tab"
                                                                                href="#home7" role="tab"
                                                                                aria-expanded="true"><i
                                                                                    class="icofont icofont-ui-user"></i>Basic
                                                                                Details</a>
                                                                            <div class="slide"></div>
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a class="nav-link" data-toggle="tab"
                                                                                href="#profile7" role="tab"
                                                                                aria-expanded="false"><i
                                                                                    class="icofont icofont-ui-settings"></i>Change
                                                                                Password</a>
                                                                            <div class="slide"></div>
                                                                        </li>
                                                                    </ul>
                                                                    <!-- Tab panes -->
                                                                    <?php
require_once './config/config.php'; // Include your database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Please log in first.";
    exit;
}

// Get current user ID from session
$user_id = $_SESSION['user_id'];

// Fetch user data from the database
$stmt = $pdo->prepare("SELECT * FROM users WHERE Id = ?");
$stmt->execute([$user_id]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if (isset($_POST['update_profile'])) {
    $name = $_POST['Name'];
    $mobile = $_POST['MobileNo'];
    $email = $_POST['Email'];

    // Update profile data in the database
    $stmt = $pdo->prepare("UPDATE users SET Name = ?, MobileNo = ?, Email = ? WHERE Id = ?");
    $stmt->execute([$name, $mobile, $email, $user_id]);

    // echo "<script>alert('');</script>";
    echo "<script>
    document.addEventListener('DOMContentLoaded', function() {
        show_message('success', 'Profile updated successfully!');
    });
</script>";

}

// Handle password change
if (isset($_POST['update_password'])) {
    $password = $_POST['Password'];
    $confirmPassword = $_POST['ConfirmPassword'];

    if ($password === $confirmPassword) {
        // Hash the password before storing it
        // $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Update password in the database
        $stmt = $pdo->prepare("UPDATE users SET Password = ? WHERE Id = ?");
        $stmt->execute([$confirmPassword, $user_id]);

        // echo "<script>show_message('success', '');</script>";
        echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            show_message('success', 'Password updated successfully!');
        });
    </script>";
    } else {
        // echo "<script>show_message('error', 'Passwords do not match!');</script>";
        echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            show_message('error', 'Passwords do not match!');
        });
    </script>";
        
    }
}
?>

<!-- HTML Form for User Profile Update -->
<div class="tab-content card-block">
    <!-- Edit Profile Tab -->
    <div class="tab-pane active" id="home7" role="tabpanel" aria-expanded="true">
        <form action="" method="POST">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="Name">Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="Name" name="Name" value="<?= htmlspecialchars($userData['Name']) ?>" required>
                    <div class="col-form-label" id="error-Name"></div>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="MobileNo">Mobile No</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="MobileNo" name="MobileNo" value="<?= htmlspecialchars($userData['MobileNo']) ?>" required>
                    <div class="col-form-label" id="error-MobileNo"></div>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="Email">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="Email" name="Email" value="<?= htmlspecialchars($userData['Email']) ?>" required>
                    <div class="col-form-label" id="error-Email"></div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10 offset-sm-2">
                    <button type="submit" class="btn btn-success btn-square" name="update_profile">Save Changes</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Change Password Tab -->
    <div class="tab-pane" id="profile7" role="tabpanel" aria-expanded="false">
        <form action="" method="POST">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="Password">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="Password" name="Password" required>
                    <div class="col-form-label" id="error-Password"></div>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="ConfirmPassword">Confirm Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="ConfirmPassword" name="ConfirmPassword" required>
                    <div class="col-form-label" id="error-ConfirmPassword"></div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10 offset-sm-2">
                    <button type="submit" class="btn btn-success btn-square" name="update_password">Update Password</button>
                </div>
            </div>
        </form>
    </div>
</div>


                                                                </div>
                                                            </div>
                                                            <!-- Row end -->
                                                        </div>

                                                        <!-- Tab variant tab card start -->


                                                    </div>
                                                    <hr>
                                                    <div class="row justify-content-center user-social-link">
                                                        <div class="col-auto"><a href="#!"><i
                                                                    class="fa fa-facebook text-facebook"></i></a></div>
                                                        <div class="col-auto"><a href="#!"><i
                                                                    class="fa fa-twitter text-twitter"></i></a></div>
                                                        <div class="col-auto"><a href="#!"><i
                                                                    class="fa fa-dribbble text-dribbble"></i></a></div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- Page body end -->
                            </div>
                        </div>

                    </div>
                </div>

                <?php include_once 'includes/footer.php' ?>

                <div id="styleSelector"></div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>