<?php
session_start();

// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=tourism", "root", "");

// Redirect based on session
function handleRedirects() {
    if (isset($_SESSION['Admin'])) {
        header("Location: ../index.php");
        exit();
    } elseif (isset($_SESSION['user']) || isset($_SESSION['hotel'])) {
        header("Location: ../index.php");
        exit();
    }
}

handleRedirects();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!empty($email) && !empty($password)) {
        // Function to authenticate and check for UserType 'A' (Admin), 'H' (Hotel), and 'U' (User)
        function authenticateUser($pdo, $table, $sessionKey, $redirectPath, $email, $password) {
            // Prepare the SQL query to get user information
            $stmt = $pdo->prepare("SELECT `Id`, `Name`, `MobileNo`, `UserType`, `Email`, `Password`, `status`, `user_delete` FROM $table WHERE Email=?");
            $stmt->execute([$email]);

            if ($user = $stmt->fetch()) {
                // Assuming the password is stored in plain text (for demonstration purposes)
                if ($user['Password'] == $password) {
                    // Check the user status and delete flag
                    if ($user['status'] == 1 && $user['user_delete'] == 0) {
                        // Set session variable with user data based on UserType
                        $_SESSION['user_id'] = $user['Id'];
                        $_SESSION['user_name'] = $user['Name'];
                        $_SESSION['user_email'] = $user['Email'];
                        $_SESSION['user_mobile'] = $user['MobileNo'];

                        // Set the session key based on the user type
                        if ($user['UserType'] == 'A') {
                            $_SESSION['Admin'] = $user; // Admin session
                            header("Location: $redirectPath"); // Redirect to Admin dashboard
                        } elseif ($user['UserType'] == 'H') {
                            $_SESSION['Hotel'] = $user; // Hotel session
                            header("Location: ../hotel_dashboard.php"); // Redirect to Hotel dashboard
                        } elseif ($user['UserType'] == 'U') {
                            $_SESSION['User'] = $user; // User session
                            header("Location: ../user_dashboard.php"); // Redirect to User dashboard
                        } else {
                            echo "<script>alert('User type not recognized.');</script>";
                        }
                        exit();
                    } else {
                        echo "<script>alert('Your account is inactive or deleted.');</script>";
                    }
                } else {
                    echo "<script>alert('Invalid credentials');</script>";
                }
            } else {
                echo "<script>alert('No user found with that email.');</script>";
            }
        }

        // Authenticate the user (check 'users' table for Admin)
        authenticateUser($pdo, 'users', 'Admin', '../index.php', $email, $password);
        // You can add additional authentication checks for hotel and user tables as needed

    } else {
        echo "<script>alert('Please enter email and password');</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin-Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description"
        content="Gradient Able Bootstrap admin template made using Bootstrap 4. The starter version of Gradient Able is completely free for personal project." />
    <meta name="keywords"
        content="free dashboard template, free admin, free bootstrap template, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
    <meta name="author" content="codedthemes">
    <!-- Favicon icon -->
    <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="../assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="../assets/icon/icofont/css/icofont.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <style>
        .error-message {
            color: red;
            margin-left: 5px;
            margin-top: -15px;
        }
    </style>
</head>

<body class="fix-menu">
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>

    <section class="login p-fixed d-flex  bg-primary common-img-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-8">
                    <div class="signup-card card-block auth-body mr-auto ml-auto">
                        <form class="md-float-material" method="post" id="loginForm" novalidate>
        
                            <div class="auth-box">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-center txt-primary">Sign in. It is fast and easy.</h3>
                                    </div>
                                </div>
                                <hr />
                                
                                <div class="form-group">
                                    <label class="form-label">Email Address</label>
                                    <input type="text" id="email" name="email" class="form-control" placeholder="Your Email Address">
                                    <span class="md-line"></span>
                                </div>
                                <div class="input-group">
                                    <div class="error-message text-danger" id="admin_email"></div>
                                </div>
                                <div class="form-group">
                                <label class="form-label">Password</label>
                                    <input type="password" id="password" name="password" class="form-control"
                                        placeholder="Choose Password">
                                    <span class="md-line"></span>
                                </div>
                                <div class="input-group">
                                    <div class="error-message text-danger" id="admin_password"></div>
                                </div>
                                <div class="row m-t-25 text-left">
                                    <div class="col-md-12">
                                        <div class="checkbox-fade fade-in-primary">
                                            <label>
                                                <input type="checkbox">
                                                <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                <span class="text-inverse">Remember Me</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                        <button type="submit"
                                            class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">Sign
                                            in now</button>
                                    </div>
                                </div>
                                <hr />
                                <div class="row">
                                    <div class="col-md-10">
                                        <p class="text-inverse text-left m-b-0">Thank you and enjoy our website.</p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const form = document.getElementById("loginForm");
            const emailInput = document.getElementById("email");
            const passwordInput = document.getElementById("password");
            const emailError = document.getElementById("admin_email");
            const passwordError = document.getElementById("admin_password");

            if (!form || !emailInput || !passwordInput || !emailError || !passwordError) {
                console.warn("Login form or one of the fields is missing in the DOM.");
                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            emailInput.addEventListener("input", () => validateEmail());
            passwordInput.addEventListener("input", () => validatePassword());

            function validateEmail() {
                const email = emailInput.value.trim();
                if (!email) {
                    emailError.textContent = "Email is required.";
                    return false;
                } else if (!emailRegex.test(email)) {
                    emailError.textContent = "Invalid email format.";
                    return false;
                } else {
                    emailError.textContent = "";
                    return true;
                }
            }

            function validatePassword() {
                const password = passwordInput.value.trim();
                if (!password) {
                    passwordError.textContent = "Password is required.";
                    return false;
                } else if (password.length < 4) {
                    passwordError.textContent = "Password must be at least 4 characters.";
                    return false;
                } else {
                    passwordError.textContent = "";
                    return true;
                }
            }

            form.addEventListener("submit", function (e) {
                e.preventDefault();
                const isEmailValid = validateEmail();
                const isPasswordValid = validatePassword();

                if (isEmailValid && isPasswordValid) {
                    form.submit();
                } else {
                    if (!isEmailValid) {
                        emailInput.focus();
                    } else if (!isPasswordValid) {
                        passwordInput.focus();
                    }
                }
            });
        });
    </script>

    <script type="text/javascript" src="../assets/js/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="../assets/js/jquery-ui/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../assets/js/popper.js/popper.min.js"></script>
    <script type="text/javascript" src="../assets/js/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../assets/js/jquery-slimscroll/jquery.slimscroll.js"></script>
    <script type="text/javascript" src="../assets/js/modernizr/modernizr.js"></script>
    <script type="text/javascript" src="../assets/js/modernizr/css-scrollbars.js"></script>
    <script type="text/javascript" src="../assets/js/common-pages.js"></script>
</body>

</html>
