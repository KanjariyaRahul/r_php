<?php
include_once 'includes/header.php';

$statementusers = $pdo->prepare("SELECT * FROM users WHERE (UserType = ? OR UserType = ?) AND user_delete = 0");
$statementusers->execute(['U', 'H']);
$users = $statementusers->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper">

                            <!-- Page-header start -->
                            <div class="page-header card">
                                <div class="card-block">
                                    <h5 class="m-b-10">Manage Users</h5>
                                    <ul class="breadcrumb-title b-t-default p-t-10">
                                        <li class="breadcrumb-item">
                                            <a href="index.php"> <i class="fa fa-home"></i>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item"><a href="manage_users.php">Manage Users</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Page-header end -->

                            <div class="page-body">
                                <!-- Hover table card start -->
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <div>
                                            <h5>Users Details</h5>
                                        </div>
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                <li><i class="fa fa-chevron-left"></i></li>
                                                <li><i class="fa fa-window-maximize full-card"></i></li>
                                                <li><i class="fa fa-minus minimize-card"></i></li>
                                                <li><i class="fa fa-refresh reload-card"></i></li>
                                                <li><i class="fa fa-times close-card"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-body table-border-style">
                                        <div class="table-responsive">
                                            <table id="userTable" class="table table-hover display">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Mobile No</th>
                                                        <th>Email</th>
                                                        <th>Password</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($users as $index => $user): ?>
                                                        <tr>
                                                            <td><?= $index + 1 ?></td>
                                                            <td><?= htmlspecialchars($user['Name']) ?></td>
                                                            <td><?= htmlspecialchars($user['MobileNo']) ?></td>
                                                            <td><?= htmlspecialchars($user['Email']) ?></td>
                                                            <td><?= htmlspecialchars($user['Password']) ?></td>
                                                            <td>
                                                                <a href="./process/activedeactive.php?id=<?= $user['Id'] ?>"
                                                                    onclick="return confirm('Are you sure to <?= $user['status'] == 1 ? 'Deactivate' : 'Activate' ?> User?')">
                                                                    <?php if ($user['status'] != 1): ?>
                                                                        <button class="btn btn-warning btn-round"
                                                                            title="Unlock User"><i
                                                                                class="ti-lock"><?= $user['status'] == 1 ? 'Active' : 'Deactive' ?></i></button>
                                                                    <?php else: ?>
                                                                        <button class="btn btn-warning btn-round"
                                                                            title="Lock User"><i
                                                                                class="ti-unlock"><?= $user['status'] == 1 ? 'Active' : 'Deactive' ?></i></button>
                                                                    <?php endif; ?>
                                                                </a>
                                                            </td>
                                                            <td>
                                                                <a href="./add_user.php?id=<?= $user['Id'] ?>">
                                                                    <button class="btn btn-info btn-round" title="Edit"><i
                                                                            class="ti-pencil"></i></button>
                                                                </a>
                                                                <a href="./process/deleteusers.php?id=<?= $user['Id'] ?>"
                                                                    onclick="return confirm('Are you sure to delete this User?')">
                                                                    <button class="btn btn-danger btn-round"
                                                                        title="Delete"><i class="ti-trash"></i></button>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- Hover table card end -->
                            </div>

                            <div id="styleSelector">

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>