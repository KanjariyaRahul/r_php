<?php
include_once 'includes/header.php';

// Add/Edit User
if (isset($_POST['adduser']) || isset($_POST['updateuser'])) {
    $name = $_POST['NAME'];
    $mobile = $_POST['MOBILENO'];
    $email = $_POST['EMAIL'];
    $password1 = $_POST['PASSWORD1'];
    $password2 = $_POST['PASSWORD2'];
    $status = 1; // Default status value
    $usertype = $_POST['usertype'];

    // Add User
    if (isset($_POST['adduser'])) {
        if ($password1 == $password2) {
            // $passwordHash = password_hash($password1, PASSWORD_DEFAULT); // Store hashed password
            $statement = $pdo->prepare("INSERT INTO users (Name, MobileNo, UserType, Email, Password, status) VALUES (?, ?, ?, ?, ?, ?)");
            $statement->execute([$name, $mobile, $usertype, $email, $password2, $status]);

            // $message = 'User Added Successfully!';
            // echo "<SCRIPT>alert('$message');window.location.replace('../add_user.php');</SCRIPT>";
            echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            show_message('success', 'User Added Successfully!');
        });
    </script>";
        } else {
            // echo "<SCRIPT>alert('Passwords do not match.');</SCRIPT>";
            echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            show_message('error', 'Passwords do not match.');
        });
    </script>";
        }
    }

    // Update User
    if (isset($_POST['updateuser']) && isset($_POST['id'])) {
        $id = $_POST['id'];

        // If passwords are updated, hash the new password
        if (!empty($password1) && $password1 == $password2) {
            $passwordHash = password_hash($password1, PASSWORD_DEFAULT);
            $statement = $pdo->prepare("UPDATE users SET Name = ?, MobileNo = ?, UserType = ?, Email = ?, Password = ? WHERE Id = ?");
            $statement->execute([$name, $mobile, $usertype, $email, $passwordHash, $id]);
        } else {
            // If passwords are not updated, do not modify the password
            $statement = $pdo->prepare("UPDATE users SET Name = ?, MobileNo = ?, UserType = ?, Email = ? WHERE Id = ?");
            $statement->execute([$name, $mobile, $usertype, $email, $id]);
        }

        // echo "<SCRIPT>alert('$message');window.location.replace('./manage_users.php');</SCRIPT>";
        echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            show_message('success', 'User Updated Successfully!');
        });
    </script>";
    }
}
?>

<div class="pcoded-container navbar-wrapper">

    <?php include_once 'includes/navbar.php' ?>

    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">

            <?php include_once 'includes/sidebar.php' ?>

            <div class="pcoded-content">
                <?php include_once 'includes/navbar.php' ?>

                <div class="pcoded-main-container">
                    <div class="pcoded-wrapper">

                        <?php include_once 'includes/sidebar.php' ?>

                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header card">
                                    <div class="card-block">
                                        <h5 class="m-b-10">Add New User</h5>
                                        <ul class="breadcrumb-title b-t-default p-t-10">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"> <i class="fa fa-home"></i>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="manage_users.php">Manage Users</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="add_user.php   ">Add New User</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                                <!-- Page body start -->
                                <div class="page-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <!-- Basic Form Inputs card start -->
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Add New User</h5>
                                                    <div class="card-header-right"><i class="icofont icofont-spinner-alt-5"></i></div>

                                                    <div class="card-header-right">
                                                        <i class="icofont icofont-spinner-alt-5"></i>
                                                    </div>

                                                </div>
                                                <div class="card-block">
                                                <?php
// Initialize an empty array for user data
$userData = [];

if (isset($_GET['id'])) {
    // Fetch user data from the database based on the user ID passed in the URL
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE Id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        // Store fetched user data in the $userData array
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        // If no user is found, you can redirect or show an error
        echo "<script>alert('User not found.'); window.location.replace('manage_users.php');</script>";
        exit;
    }
}
?>

                                                <form action="" method="POST">

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="NAME">Name</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="NAME" id="NAME" placeholder="Name.." value="<?= isset($userData['Name']) ? htmlspecialchars($userData['Name']) : '' ?>" required>
        <div class="col-form-label" id="error-NAME"></div>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="MOBILENO">Mobile No</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="MOBILENO" id="MOBILENO" placeholder="Mobile No.." value="<?= isset($userData['MobileNo']) ? htmlspecialchars($userData['MobileNo']) : '' ?>" required>
        <div class="col-form-label" id="error-MOBILENO"></div>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="usertype">User Type</label>
    <div class="col-sm-10">
        <select class="form-control" name="usertype" id="usertype" required>
            <option value="">Select User Type</option>
            <option value="A" <?= isset($userData['UserType']) && $userData['UserType'] == 'A' ? 'selected' : '' ?>>Admin</option>
            <option value="U" <?= isset($userData['UserType']) && $userData['UserType'] == 'U' ? 'selected' : '' ?>>User</option>
            <option value="H" <?= isset($userData['UserType']) && $userData['UserType'] == 'H' ? 'selected' : '' ?>>Hotel</option>
        </select>
        <div class="col-form-label" id="error-usertype"></div>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="EMAIL">Email</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="EMAIL" id="EMAIL" placeholder="Email.." value="<?= isset($userData['Email']) ? htmlspecialchars($userData['Email']) : '' ?>" required>
        <div class="col-form-label" id="error-EMAIL"></div>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="PASSWORD1">Set Password</label>
    <div class="col-sm-10">
        <input type="password" class="form-control" name="PASSWORD1" id="PASSWORD1" placeholder="Set Password..">
        <div class="col-form-label" id="error-PASSWORD1"></div>
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-2 col-form-label" for="PASSWORD2">Confirm Password</label>
    <div class="col-sm-10">
        <input type="password" class="form-control" name="PASSWORD2" id="PASSWORD2" placeholder="Confirm Password..">
        <div class="col-form-label" id="error-PASSWORD2"></div>
    </div>
</div>

<div class="form-group row">
    <div class="col-sm-10 offset-sm-2">
        <button type="submit" class="btn btn-success btn-square" name="<?= isset($userData['Id']) ? 'updateuser' : 'adduser' ?>">
            <?= isset($userData['Id']) ? 'Update' : 'Register' ?>
        </button>
    </div>
</div>

<?php if (isset($userData['Id'])): ?>
    <input type="hidden" name="id" value="<?= $userData['Id'] ?>">
<?php endif; ?>

</form>


                                    
                                                </div>
                                            </div>
                            
                                        </div>
                                    </div>
                                </div>
                                <!-- Page body end -->
                            </div>
                        </div>

                    </div>
                </div>

                <?php include_once 'includes/footer.php' ?>

                <div id="styleSelector"></div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php' ?>