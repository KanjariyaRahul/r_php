<?php
// Attempt to connect to the MySQL database using PDO
try {
    // Create a new PDO instance and set necessary attributes
    $connect = new PDO("mysql:host=localhost;dbname=coldstorage", "root", ""); // Update with your actual credentials
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception
    $connect->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Set default fetch mode
} catch (PDOException $e) {
    // Handle any connection errors
    die("Connection failed: " . $e->getMessage());
}
?>
