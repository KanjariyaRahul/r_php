<?php
include_once(__DIR__ . "/../config/connection.php");

class mdl_districtmaster {
    public $_district_id;
    public $_district_name;
    public $_state_id;
    public $_city_id;
    public $_country_id;
    public $_created_date;
    public $_created_by;
    public $_modified_date;
    public $_modified_by;
    public $_transactionmode;
}

class bll_districtmaster {
    public $_mdl;
    public $_dal;

    public function __construct() {
        $this->_mdl = new mdl_districtmaster();
        $this->_dal = new dal_districtmaster();
    }

    public function dbTransaction() {
        // Validate required fields
        if (empty($this->_mdl->_district_name) || empty($this->_mdl->_city_id) || empty($this->_mdl->_state_id) || empty($this->_mdl->_country_id)) {
            echo "Error: All fields are required.";
            return;
        }

        $currentDate = time();
        $userId = 1; // Placeholder for user ID, replace as necessary

        if ($this->_mdl->_transactionmode == 'I') {
            $this->_mdl->_created_date = $currentDate;
            $this->_mdl->_created_by = $userId;
        }

        if (in_array($this->_mdl->_transactionmode, ['I', 'U'])) {
            $this->_mdl->_modified_date = $currentDate;
            $this->_mdl->_modified_by = $userId;
        }

        // Perform the transaction
        $this->_dal->dbTransaction($this->_mdl);

        // Redirect based on the transaction mode
        switch ($this->_mdl->_transactionmode) {
            case "D":
                header("Location: delete_district.php");
                break;
            case "U":
                header("Location: srh_district_master.php");
                break;
            case "I":
                header("Location: frm_district_master.php");
                break;
            default:
                header("Location: dashboard.php");
                break;
        }
    }

    public function fillModel() {
        $this->_dal->fillModel($this->_mdl);
    }

    public function pageSearch() {
        global $connect;

        $sql = "SELECT district_id, district_name, city_id, state_id, country_id FROM tbl_district_master";
        echo "
        <table id=\"searchMaster\" class=\"table table-bordered table-striped\">
        <thead>
            <tr><th>District Name</th><th>City</th><th>State</th><th>Country</th><th>Action</th></tr>
        </thead>
        <tbody>";

        foreach ($connect->query($sql) as $row) {
            $city_name = $this->getCityName($row['city_id']);
            $state_name = $this->getStateName($row['state_id']);
            $country_name = $this->getCountryName($row['country_id']);

            echo "<tr>
                <td>{$row['district_name']}</td>
                <td>{$city_name}</td>
                <td>{$state_name}</td>
                <td>{$country_name}</td>
                <td>
                    <form method=\"post\" action=\"frm_district_master.php\" style=\"display:inline; margin-right:5px;\">
                        <input class=\"btn btn-default update\" type=\"submit\" name=\"btn_update\" value=\"Edit\" />
                        <input type=\"hidden\" name=\"district_id\" value=\"{$row['district_id']}\" />
                        <input type=\"hidden\" name=\"transactionmode\" value=\"U\" />
                    </form>
                    <form method=\"post\" action=\"delete_district.php\" style=\"display:inline;\">
                        <input class=\"btn btn-default delete\" type=\"submit\" name=\"btn_delete\" value=\"Delete\" />
                        <input type=\"hidden\" name=\"district_id\" value=\"{$row['district_id']}\" />
                        <input type=\"hidden\" name=\"transactionmode\" value=\"D\" />
                    </form>
                </td>
            </tr>";
        }

        echo "</tbody></table>";
    }

    private function getCityName($city_id) {
        global $connect;
        $sql = "SELECT city_name FROM tbl_city_master WHERE city_id = :city_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':city_id', $city_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['city_name'] ?? 'N/A';
    }

    private function getStateName($state_id) {
        global $connect;
        $sql = "SELECT state_name FROM tbl_state_master WHERE state_id = :state_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':state_id', $state_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['state_name'] ?? 'N/A';
    }

    private function getCountryName($country_id) {
        global $connect;
        $sql = "SELECT country_name FROM tbl_country_master WHERE country_id = :country_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':country_id', $country_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['country_name'] ?? 'N/A';
    }
}

class dal_districtmaster {
    public function dbTransaction($mdl) {
        global $connect;
        $sql = "CALL transaction_district_master(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $connect->prepare($sql);

        $stmt->bindParam(1, $mdl->_district_id, PDO::PARAM_INT);
        $stmt->bindParam(2, $mdl->_district_name, PDO::PARAM_STR);
        $stmt->bindParam(3, $mdl->_state_id, PDO::PARAM_INT);
        $stmt->bindParam(4, $mdl->_city_id, PDO::PARAM_INT);
        $stmt->bindParam(5, $mdl->_country_id, PDO::PARAM_INT);
        $stmt->bindParam(6, $mdl->_created_date, PDO::PARAM_INT);
        $stmt->bindParam(7, $mdl->_created_by, PDO::PARAM_INT);
        $stmt->bindParam(8, $mdl->_modified_date, PDO::PARAM_INT);
        $stmt->bindParam(9, $mdl->_modified_by, PDO::PARAM_INT);
        $stmt->bindParam(10, $mdl->_transactionmode, PDO::PARAM_STR);

        $stmt->execute();
    }

    public function fillModel($mdl) {
        global $connect;
        $sql = "SELECT * FROM tbl_district_master WHERE district_id = :district_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':district_id', $_REQUEST['district_id'], PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $mdl->_district_id = $row['district_id'];
            $mdl->_district_name = $row['district_name'];
            $mdl->_city_id = $row['city_id'];
            $mdl->_state_id = $row['state_id'];
            $mdl->_country_id = $row['country_id'];
        }
    }
}

$_bll = new bll_districtmaster();

if (isset($_POST['inputSave'])) {
    $_bll->_mdl->_district_id = $_POST['district_id'] ?? null;
    $_bll->_mdl->_district_name = trim($_POST['district_name']);
    $_bll->_mdl->_city_id = $_POST['city_id'];
    $_bll->_mdl->_state_id = $_POST['state_id'];
    $_bll->_mdl->_country_id = $_POST['country_id'];
    $_bll->_mdl->_transactionmode = $_bll->_mdl->_district_id ? 'U' : 'I';
    $_bll->dbTransaction();
}

if (isset($_POST['transactionmode']) && $_POST['transactionmode'] == 'D') {
    $_bll->_mdl->_district_id = $_POST['district_id'];
    $_bll->_mdl->_transactionmode = 'D';
    $_bll->dbTransaction();
}
?>
