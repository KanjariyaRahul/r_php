<?php
session_start();
include('config/connection.php');
$pages='chamber';
// Ensure user is logged in
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Initialize form variables
$chamber_id = $chamber = $created_date = $created_by = $modified_date = $modified_by = '';

if (isset($_POST['chamber_id'])) {
    // Edit mode: Fetch existing chamber data
    $chamber_id = $_POST['chamber_id'];
    $createdBy = $_SESSION['display_name'];
     $modifiedBy = $_SESSION['display_name'];
    $sql = "SELECT chamber, created_date, created_by, modified_date, modified_by FROM tbl_chamber_master WHERE chamber_id = :chamber_id";
    $stmt = $connect->prepare($sql);
    $stmt->bindParam(':chamber_id', $chamber_id, PDO::PARAM_INT);
    $stmt->execute();
    $chamberData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($chamberData) {
        $chamber = htmlspecialchars($chamberData['chamber']);
        $created_date = htmlspecialchars($chamberData['created_date']);
        $createdBy = htmlspecialchars($chamberData['created_by']);
        $modified_date = htmlspecialchars($chamberData['modified_date']);
        $modifiedBy = htmlspecialchars($chamberData['modified_by']);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_chamber'])) {
    // Save Chamber (Create or Update)
    $chamber = $_POST['chamber'];
    $user_id = $_SESSION['ad_session'];  // Get the user ID of the current logged-in admin
    $modified_date = date('Y-m-d H:i:s');

    if ($chamber_id) {
        // Update Chamber
        $sql = "UPDATE tbl_chamber_master SET chamber = :chamber, modified_by = :modified_by, modified_date = :modified_date WHERE chamber_id = :chamber_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':chamber', $chamber, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':modified_date', $modified_date, PDO::PARAM_STR);
        $stmt->bindParam(':chamber_id', $chamber_id, PDO::PARAM_INT);
    } else {
        // Create New Chamber
        $created_date = date('Y-m-d H:i:s');
        $sql = "INSERT INTO tbl_chamber_master (chamber, created_by, created_date) VALUES (:chamber, :created_by, :created_date)";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':chamber', $chamber, PDO::PARAM_STR);
        $stmt->bindParam(':created_by', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':created_date', $created_date, PDO::PARAM_STR);
    }
    $stmt->execute();
    header('Location: srh_chamber_master.php');  // Redirect to the search page after saving
    exit();
}
?>

<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">

        <section class="content">
              <div style="margin-bottom:50px;">
                <button class="btn btn-info" onclick="location.href='frm_<?=$pages?>_master.php'">+ Create Unit</button>
            </div>  
             <div class="col-md-6" style="padding:0;">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?= $chamber_id ? 'Edit Chamber' : 'Create Chamber' ?></h3>
                </div>

                <!-- Chamber Form -->
                <form method="POST" action="frm_chamber_master.php">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="chamber">Chamber Name</label>
                            <input type="text" name="chamber" id="chamber" class="form-control" value="<?= htmlspecialchars($chamber) ?>" required>
                        </div>

                        <!-- Hidden input for editing -->
                        <input type="hidden" name="chamber_id" value="<?= htmlspecialchars($chamber_id) ?>">

                        
                    </div>

                    <div class="box-footer">
                        <button type="submit" name="save_chamber" class="btn btn-primary"><?= $chamber_id ? 'Update Chamber' : 'Create Chamber' ?></button>
                    </div>
                </form>
            </div>
            </div>
        </section>
    </div>
</div
<?php include("include/footer.php"); ?>
