<?php
session_start();

// Include the database connection
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Check if the district_id is provided for deletion
if (isset($_POST['customer_id']) && !empty($_POST['customer_id']) && is_numeric($_POST['customer_id'])) {
    $customerId = (int) $_POST['customer_id']; // Sanitize the input as an integer

    // Prepare the delete query
    try {
        // Begin transaction to ensure safety
        $connect->beginTransaction();

        // Delete district record
        $sql = "DELETE FROM tbl_customer_master WHERE customer_id = :customer_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':customer_id', $customerId, PDO::PARAM_INT);

        // Execute the delete query
        if ($stmt->execute()) {
            // Commit the transaction
            $connect->commit();
            // Success message
            $_SESSION['message'] = 'customer deleted successfully.';
        } else {
            // Rollback if the delete fails
            $connect->rollBack();
            $_SESSION['message'] = 'Failed to delete the customer.';
        }
    } catch (PDOException $e) {
        // Rollback in case of an error
        $connect->rollBack();
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
    }

    // Redirect back to the district search page
    header('Location: srh_customer_master.php');
    exit();
} else {
    // If no district_id is provided or it's not a valid number, redirect back with an error message
    $_SESSION['message'] = 'No valid district ID provided for deletion.';
    header('Location: srh_customer_master.php');
    exit();
}
?>
