<?php
session_start();
$page = "state";

// Include the database connection
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Get the ID for editing, if available
$stateId = $_POST['state_id'] ?? null;

// Default values for a new record
$user = [
    'state_id' => '',
    'state_name' => '',
    'country_id' => '',  // Use country_id instead of country_name for consistency
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => ''
];

// Fetch the record if editing
if ($stateId) {
    $stmt = $connect->prepare("SELECT * FROM tbl_{$page}_master WHERE state_id = :id");
    $stmt->bindParam(':id', $stateId, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['message'] = ucfirst($page) . ' not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $stateName = trim($_POST['inputStateName'] ?? '');
    $countryId = trim($_POST['inputCountryName'] ?? '');  // Fetch country_id instead of country_name
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($stateName) || empty($countryId)) {
        $_SESSION['message'] = 'State name and country are required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($stateId) {
            // Update query
            $sql = "UPDATE tbl_{$page}_master 
                    SET state_name = :state_name, 
                        country_id = :country_id,
                        created_by = :created_by,
                        modified_date = NOW(), 
                        modified_by = :modified_by 
                    WHERE state_id = :id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':id', $stateId, PDO::PARAM_INT);
        } else {
            // Insert query
            $sql = "INSERT INTO tbl_{$page}_master 
                    (state_name, country_id, created_date, created_by, modified_date, modified_by) 
                    VALUES (:state_name, :country_id, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
        }

        // Bind parameters
        $stmt->bindParam(':state_name', $stateName, PDO::PARAM_STR);
        $stmt->bindParam(':country_id', $countryId, PDO::PARAM_INT);
        $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute query
        if ($stmt->execute()) {
            $_SESSION['message'] = ucfirst($page) . ($stateId ? ' updated successfully' : ' created successfully');
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>

<?php include("include/header.php"); ?>

<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include('include/navigation.php'); ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $stateId ? 'Edit State' : 'Add State'; ?></h1>
            <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="srh_<?= $page ?>_master.php"><?= ucfirst($page) ?> Master</a></li>
                <li class="active"><?php echo $stateId ? 'Edit State' : 'Add State'; ?></li>
            </ol>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <input type="hidden" name="state_id" value="<?php echo htmlspecialchars($stateId); ?>">

                            <div class="form-group">
                                <label for="inputStateName" class="col-sm-4 control-label">State Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputStateName" name="inputStateName"
                                           value="<?php echo htmlspecialchars($user['state_name'] ?? ''); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                            <label for="inputCountryName" class="col-sm-4 control-label">Country*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputCountryName" name="inputCountryName" required>
                                    <option value="">Select Country</option>
                                    <?php
                                    try {
               
                                        $stmt = $connect->prepare("SELECT country_id, country_name FROM tbl_country_master ORDER BY country_name ASC");
                                        $stmt->execute();
                                        $countries = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                        $isFirstCountrySelected = false;
                                        foreach ($countries as $country) {
                    
                                        $selected = '';
                                        if (!empty($user['country_id']) && $user['country_id'] == $country['country_id']) {
                                            $selected = 'selected'; 
                                        } elseif (empty($user['country_id']) && !$isFirstCountrySelected) {
                                        $selected = 'selected';  
                                        $isFirstCountrySelected = true;  
                                    }

                                    echo "<option value='" . htmlspecialchars($country['country_id']) . "' $selected>" . htmlspecialchars($country['country_name']) . "</option>";
                                    }
                                    } catch (PDOException $e) {
                                        echo "<option value=''>Error loading countries</option>";
                                    }
                                    ?>
                                </select>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php include('include/footer.php'); ?>
