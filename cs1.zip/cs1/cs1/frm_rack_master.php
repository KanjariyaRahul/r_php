<?php
session_start();
$page = "rack"; // Changed to "rack" page

// Include the database connection
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Default values for a new record
$rackId = isset($_POST['rack_id']) ? $_POST['rack_id'] : ''; // Check for rackId in the URL

$rack = [
    'rack_id' => '',
    'rack' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => '',
];

// Fetch rack record if editing
if ($rackId) {
    $stmtRack = $connect->prepare("SELECT * FROM tbl_rack_master WHERE rack_id = :rack_id");
    $stmtRack->bindParam(':rack_id', $rackId, PDO::PARAM_INT);
    $stmtRack->execute();
    $rack = $stmtRack->fetch(PDO::FETCH_ASSOC);

    if (!$rack) {
        $_SESSION['message'] = 'Rack not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $rack = trim($_POST['inputRack'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($rack)) {
        $_SESSION['message'] = 'Rack name is required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($rackId) {
            // Update existing rack
            $sql = "UPDATE tbl_rack_master SET rack = :rack, modified_date = NOW(), modified_by = :modified_by WHERE rack_id = :rack_id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':rack_id', $rackId, PDO::PARAM_INT);
        } else {
            // Insert new rack
            $sql = "INSERT INTO tbl_rack_master (rack, created_date, created_by, modified_date, modified_by) 
                    VALUES (:rack, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
            $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);
        }

        // Bind parameters
        $stmt->bindParam(':rack', $rack, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Rack saved successfully';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>
<?php include("include/header.php"); ?>


<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $rackId ? 'Edit Rack' : 'Add Rack'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="inputRack" class="col-sm-4 control-label">Rack*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputRack" name="inputRack" 
                                           placeholder="Enter Rack" value="<?php echo htmlspecialchars($rack['rack']); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="hidden" value="<?php echo $rackId; ?>" name="rack_id" />
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php include('include/footer.php'); ?>
