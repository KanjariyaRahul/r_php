<?php
include_once(__DIR__ . "/../config/connection.php");

class mdl_usermaster {
    public $_id;
    public $_username;
    public $_name;
    public $_password;
    public $_status;
    public $_transactionmode;
}

class bll_usermaster {
    public $_mdl;
    public $_dal;

    public function __construct() {
        $this->_mdl = new mdl_usermaster();
        $this->_dal = new dal_usermaster();
    }

    public function dbTransaction() {
        $this->_dal->dbTransaction($this->_mdl);

        switch ($this->_mdl->_transactionmode) {
            case "D":
                header("Location: delete_user.php");
                break;
            case "U":
                header("Location: srh_user_master.php");
                break;
            case "I":
                header("Location: frm_user_master.php");
                break;
            default:
                header("Location: dashboard.php");
                break;
        }   
    }

    public function fillModel() {
        global $connect;
        $this->_dal->fillModel($this->_mdl);
    }

    public function pageSearch() {
        global $connect;

        $sql = "CALL search_user_master()"; // Stored procedure to search users

        echo "
        <table id=\"searchMaster\" class=\"table table-bordered table-striped\">
        <thead>
            <tr><th>Username</th><th>Name</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>";

        $_grid = "";
        foreach ($connect->query($sql) as $_rs) {
            $_grid .= "<tr>
                        <td>{$_rs['username']}</td>
                        <td>{$_rs['name']}</td>
                        <td>{$_rs['status']}</td>
                        <td>
                            <form method=\"post\" action=\"frm_user_master.php\" style=\"display:inline; margin-right:5px;\">
                                <input class=\"btn btn-default update\" type=\"submit\" id=\"btn_update\" name=\"btn_update\" value=\"Edit\" />
                                <input type=\"hidden\" name=\"id\" value=\"{$_rs['id']}\" />
                                <input type=\"hidden\" name=\"transactionmode\" value=\"U\" />
                            </form>
                            <form method=\"post\" action=\"delete_user.php\" style=\"display:inline;\">
                                <input class=\"btn btn-default delete\" type=\"submit\" id=\"btn_delete\" name=\"btn_delete\" value=\"Delete\" />
                                <input type=\"hidden\" name=\"id\" value=\"{$_rs['id']}\" />
                                <input type=\"hidden\" name=\"transactionmode\" value=\"D\" />
                            </form>
                        </td>
                    </tr>";
        }
        $_grid .= "</tbody></table>";
        echo $_grid;
    }
}

class dal_usermaster {
    public function dbTransaction($_mdl) {
        global $connect;
        $sql = "CALL transaction_user_master(?, ?, ?, ?, ?, ?)";
        $_pre = $connect->prepare($sql);
        $_pre->bindParam(1, $_mdl->_id, PDO::PARAM_INT);
        $_pre->bindParam(2, $_mdl->_username, PDO::PARAM_STR);
        $_pre->bindParam(3, $_mdl->_name, PDO::PARAM_STR);
        $_pre->bindParam(4, $_mdl->_password, PDO::PARAM_STR);
        $_pre->bindParam(5, $_mdl->_status);
        $_pre->bindParam(6, $_mdl->_transactionmode);
        $_pre->execute();
    }

    public function fillModel($_mdl) {
        global $connect;
        
        $sql = "SELECT * FROM tbl_user_master WHERE id = :id";
        $_pre = $connect->prepare($sql);
        $_pre->bindParam(':id', $_REQUEST["id"], PDO::PARAM_INT);
        $_pre->execute();
        
        $_rs = $_pre->fetch(PDO::FETCH_ASSOC);

        $_mdl->_id = $_rs["id"];
        $_mdl->_username = $_rs["username"];
        $_mdl->_name = $_rs["name"];
        $_mdl->_password = $_rs["password"];
        $_mdl->_status = $_rs["status"];
        $_mdl->_transactionmode = $_REQUEST["transactionmode"] ?? null;
    }
}

$_bll = new bll_usermaster();

// Action handling
if (isset($_REQUEST["action"])) {
    $action = $_REQUEST["action"];
    $_bll->$action();
}   
if (isset($_POST["inputSave"])) {
    $_bll->_mdl->_id = $_POST["id"] ?? null;
    $_bll->_mdl->_username = trim($_POST["inputUsername"]);
    $_bll->_mdl->_name = trim($_POST["inputPersonName"]);
    $_bll->_mdl->_password = trim($_POST["inputPassword"]);
    $_bll->_mdl->_status = isset($_POST["inputEnable"]) ? 1 : 0;
    $_bll->_mdl->_transactionmode = $_bll->_mdl->_id ? "U" : "I"; 
    $_bll->dbTransaction();
}

// Handle Delete functionality
if (isset($_POST["transactionmode"]) && $_POST["transactionmode"] == "D") {
    $_bll->fillModel();
    $_bll->dbTransaction();
}
?>
