<?php
session_start();
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Check if district_id is passed
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['district_id'])) {
    $districtId = $_POST['district_id'];
    $transactionMode = 'DELETE';  // Assuming DELETE as the transaction mode, adjust as needed.

    try {
        // Prepare the delete statement
        $stmt = $connect->prepare("CALL transaction_district_master(:district_id, :district_name, :city_id, :state_id, :country_id, NOW(), :created_by, NOW(), :modified_by, :transactionMode)");

        // Bind parameters
        $stmt->bindParam(':district_id', $districtId, PDO::PARAM_INT);
        // Add other necessary parameters for district_name, city_id, state_id, country_id, created_by, and modified_by if needed
        $stmt->bindParam(':district_name', $districtName, PDO::PARAM_STR);  // Example, make sure to set $districtName
        $stmt->bindParam(':city_id', $cityId, PDO::PARAM_INT);  // Example, set $cityId
        $stmt->bindParam(':state_id', $stateId, PDO::PARAM_INT);  // Example, set $stateId
        $stmt->bindParam(':country_id', $countryId, PDO::PARAM_INT);  // Example, set $countryId
        $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_INT);  // Example, set $createdBy
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_INT);  // Example, set $modifiedBy
        $stmt->bindParam(':transactionMode', $transactionMode, PDO::PARAM_STR);  // 'DELETE' operation

        // Execute the statement
        if ($stmt->execute()) {
            $_SESSION['message'] = "District deleted successfully.";
        } else {
            $_SESSION['message'] = "Failed to delete district.";
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "Error: " . $e->getMessage();
    }
} else {
    $_SESSION['message'] = "Invalid request.";
}

// Redirect back to the district list page
header('Location: srh_district_master.php');
exit();
?>
