<?php
session_start();
// Include the database connection
include('config/connection.php');
$page = "customer";
$customer = $customer ?? []; // Initializes it as an empty array if it's null

$customerId = $_POST['customer_id'] ?? null; // Get customer_id from the URL if available, else set to null

try {
// Fetch districts
  $stmtDistricts = $connect->prepare("SELECT district_id, district_name,city_id,state_id,country_id FROM tbl_district_master ORDER BY district_name ASC");
   $stmtDistricts->execute();
  $districts = $stmtDistricts->fetchAll(PDO::FETCH_ASSOC);
    // Fetch states
    $stmtStates = $connect->prepare("SELECT state_id, state_name, country_id FROM tbl_state_master ORDER BY state_name ASC");
    $stmtStates->execute();
    $states = $stmtStates->fetchAll(PDO::FETCH_ASSOC);

    // Fetch countries
    $stmtCountries = $connect->prepare("SELECT country_id, country_name FROM tbl_country_master ORDER BY country_name ASC");
    $stmtCountries->execute();
    $countries = $stmtCountries->fetchAll(PDO::FETCH_ASSOC);

    // Fetch cities
    $stmtCities = $connect->prepare("SELECT city_id, city_name, state_id, country_id FROM tbl_city_master ORDER BY city_name ASC");
    $stmtCities->execute();
    $cities = $stmtCities->fetchAll(PDO::FETCH_ASSOC);

    // Fetch customers (districts)
    $stmtCustomers = $connect->prepare("SELECT * FROM tbl_customer_master ORDER BY customer_name ASC");
    $stmtCustomers->execute();
    $customers = $stmtCustomers->fetchAll(PDO::FETCH_ASSOC);

    // Create mappings for state and country relationships
    $stateMapping = [];
    foreach ($states as $state) {
        $stateMapping[$state['state_id']] = $state['state_name'];
    }
    $countryMapping = [];
    foreach ($countries as $country) {
        $countryMapping[$country['country_id']] = $country['country_name'];
    }
} catch (PDOException $e) {
    echo "Error loading data: " . $e->getMessage();
}

if ($customerId) {
    $stmtCustomer = $connect->prepare("SELECT * FROM tbl_customer_master WHERE customer_id = :customer_id");
    $stmtCustomer->bindParam(':customer_id', $customerId, PDO::PARAM_INT);
    $stmtCustomer->execute();
    $customer = $stmtCustomer->fetch(PDO::FETCH_ASSOC);

    // Ensure $customer matches the new structure
    if (!$customer) {
            // If no customer is found, redirect or handle the case
            $_SESSION['message'] = 'Customer not found';
            header("Location: srh_{$page}_master.php");
            exit();
        }

    // Adjust the customer array structure to include the new fields
    $customer = [
        'customer_id' => $customer['customer_id'] ?? '',
        'customer_name' => $customer['customer_name'] ?? '',
        'customer_type' => $customer['customer_type'] ?? '',
        'address' => $customer['address'] ?? '',
        'district_id' => $customer['district_id'] ?? '',
        'state_id' => $customer['state_id'] ?? '',
        'pincode' => $customer['pincode'] ?? '',
        'contact_no' => $customer['contact_no'] ?? '',
        'weburl' => $customer['weburl'] ?? '',
        'email_id' => $customer['email_id'] ?? '',
        'status' => $customer['status'] ?? '',
        'district_name' => $customer['district_name'] ?? '',
        'city_id' => $customer['city_id'] ?? '',
        'created_date' => $customer['created_date'] ?? '',
        'created_by' => $customer['created_by'] ?? '',
        'modified_date' => $customer['modified_date'] ?? '',
        'modified_by' => $customer['modified_by'] ?? '',
        'country_id' => $customer['country_id'] ?? ''
    ];
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $customerName = trim($_POST['inputCustomerName'] ?? '');
    $customerType = trim($_POST['inputCustomerType'] ?? '');
    $districtId = trim($_POST['inputDistrictName'] ?? '');
    $stateId = trim($_POST['inputStateId'] ?? '');
    $cityId = trim($_POST['inputCityId'] ?? '');
    $countryId = trim($_POST['inputCountryId'] ?? '');
    $address = trim($_POST['inputAddress'] ?? '');
    $pincode = trim($_POST['inputPincode'] ?? '');
    $contactNo = trim($_POST['inputContactNo'] ?? '');
    $weburl = trim($_POST['inputWebUrl'] ?? '');
    $emailId = trim($_POST['inputEmailId'] ?? '');
    $status = $_POST['inputStatus'] == 'activated' ? 1 : 0;
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    if (empty($customerName) || empty($customerType) || empty($districtId) || empty($stateId) || empty($cityId) || empty($address) || empty($contactNo)) {
        $_SESSION['message'] = 'Please fill out all required fields.';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($customerId) {
            $sql ="UPDATE tbl_customer_master SET 
                        customer_name = :customer_name,
                        customer_type = :customer_type,
                        address = :address,
                        district_id = :district_id,
                        city_id = :city_id,
                        state_id = :state_id,
                        country_id = :country_id,
                        pincode = :pincode,
                        contact_no = :contact_no,
                        weburl = :weburl,
                        email_id = :email_id,
                        status = :status,
                        modified_date = NOW(),
                        modified_by = :modified_by
                    WHERE customer_id = :customer_id";
        } else {
            $sql = "INSERT INTO tbl_customer_master 
                        (customer_name, customer_type, address, district_id, city_id,  state_id, country_id,  pincode, contact_no, weburl, email_id, status, created_date, created_by, modified_date, modified_by)
                    VALUES 
                        (:customer_name, :customer_type, :address, :district_id, :city_id, :state_id, :country_id, :pincode, :contact_no, :weburl, :email_id, :status, NOW(), :created_by, NOW(), :modified_by)";
        }

        $stmt = $connect->prepare($sql);

        $stmt->bindParam(':customer_name', $customerName);
        $stmt->bindParam(':customer_type', $customerType);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':district_id', $districtId);
        $stmt->bindParam(':city_id', $cityId);
        $stmt->bindParam(':state_id', $stateId);
        $stmt->bindParam(':country_id', $countryId);
        $stmt->bindParam(':pincode', $pincode);
        $stmt->bindParam(':contact_no', $contactNo);
        $stmt->bindParam(':weburl', $weburl);
        $stmt->bindParam(':email_id', $emailId);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':modified_by', $modifiedBy);

        if (!$customerId) {
            $stmt->bindParam(':created_by', $createdBy);
        } else {
            $stmt->bindParam(':customer_id', $customerId, PDO::PARAM_INT);
        }

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Customer saved successfully.';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            throw new Exception('Failed to save customer.');
        }
    } catch (Exception $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}

?>
<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $customerId ? 'Edit Customer' : 'Add Customer'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                         <input type="hidden" name="customer_id" value="<?php echo htmlspecialchars($customerId); ?>">
                             <div class="form-group">
                                <label for="inputCustomerName" class="col-sm-4 control-label">Customer</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCustomerName" name="inputCustomerName" 
                                           placeholder="Enter Customer Name" value="<?= htmlspecialchars(isset($customer['customer_name']) ? $customer['customer_name'] : ''); ?>"
                                        required>
                                </div>
                            </div>
                               <div class="form-group">
        <label for="inputCustomerType" class="col-sm-4 control-label">Customer Type*</label>
        <div class="col-sm-8">
            <label class="radio-inline">
                <input type="radio" name="inputCustomerType" value="local" <?= isset($customer['customer_type']) && $customer['customer_type'] === 'local' ? 'checked' : ''; ?>>
                Local
            </label>
            <label class="radio-inline">
                <input type="radio" name="inputCustomerType" value="global" <?= isset($customer['customer_type']) && $customer['customer_type'] === 'global' ? 'checked' : ''; ?>>
                Global
            </label>
        </div>
        </div>
                           <div class="form-group">
    <label for="inputAddress" class="col-sm-4 control-label">Address*</label>
    <div class="col-sm-8">
        <textarea class="form-control" id="inputAddress" name="inputAddress" 
                  placeholder="Enter Address" required><?= htmlspecialchars(isset($customer['address']) ? $customer['address'] : ''); ?></textarea>
    </div>
</div>

        
                         <div class="form-group">
    <label for="inputDistrictName" class="col-sm-4 control-label">District*</label>
    <div class="col-sm-8">
       
        <select class="form-control" id="inputDistrictName" name="inputDistrictName" required>
            <option value="">Select District</option>
            <?php 
            $stateId = isset($Districtoption['city_id']) ? $Districtoption['city_id'] : '';
         $countryId = isset($Districtoption['country_id']) ? $Districtoption['country_id'] : '';

            foreach ($districts as $Districtoption): ?>
            <?php
                    // Check if 'city_id' and 'country_id' exist before using them
                    $cityId = isset($Districtoption['city_id']) ? $Districtoption['city_id'] : '';
                    $stateId = isset($Districtoption['state_id']) ? $Districtoption['state_id'] : '';
                    $countryId = isset($Districtoption['country_id']) ? $Districtoption['country_id'] : '';
                    ?>
                <option 
                    value="<?= htmlspecialchars($Districtoption['district_id']); ?>" 
                    
                    data-city-id="<?= htmlspecialchars($cityId); ?>"  
                    data-state-id="<?= htmlspecialchars($stateId); ?>"
                    data-country-id="<?= htmlspecialchars($countryId); ?>"
                    <?= isset($customer['district_id']) && $customer['district_id'] == $Districtoption['district_id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($Districtoption['district_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

                             <div class="form-group">
                                <label for="inputCityName" class="col-sm-4 control-label">City Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCityName" name="inputCityName" 
                                           value="<?= isset($district['city_id']) && isset($stateMapping[$district['city_id']]) ? htmlspecialchars($stateMapping[$district['city_id']]) : ''; ?>" readonly>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputStateName" class="col-sm-4 control-label">State Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputStateName" name="inputStateName" 
                                           value="<?= isset($district['state_id']) && isset($stateMapping[$district['state_id']]) ? htmlspecialchars($stateMapping[$district['state_id']]) : ''; ?>" readonly>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputCountryName" class="col-sm-4 control-label">Country Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCountryName" name="inputCountryName" 
                                           value="<?= isset($district['country_name']) ? htmlspecialchars($district['country_name']) : ''; ?>" readonly>
                                </div>
                            </div>
                              <input type="hidden" id="inputCityId" name="inputCityId" value="">
                             <input type="hidden" id="inputStateId" name="inputStateId" value="">
                            <input type="hidden" id="inputCountryId" name="inputCountryId" value="">
                            
                              <div class="form-group">
                                <label for="inputPincode" class="col-sm-4 control-label">Pincode</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputPincode" name="inputPincode" 
                                           placeholder="Enter Pincode" value="<?= htmlspecialchars(isset($customer['pincode']) ? $customer['pincode'] : ''); ?>" required>
                                </div>
                            </div>
                             <div class="form-group">
                            <label for="inputContactNo" class="col-sm-4 control-label">Contact No*</label>
                        <div class="col-sm-8">
                        <input type="text" class="form-control" id="inputContactNo" name="inputContactNo" 
                               placeholder="Enter Contact No" value="<?= htmlspecialchars(isset($customer['contact_no']) ? $customer['contact_no'] : ''); ?>" required>
                            <label class="checkbox-inline">
                                <input type="checkbox" name="contactOptions[]" value="whatsapp" 
                                       <?= isset($customer['contact_options']) && is_array($customer['contact_options']) && in_array('whatsapp', $customer['contact_options']) ? 'checked' : ''; ?>> 
                                Send WhatsApp
                            </label>
                    <label class="checkbox-inline">
                        <input type="checkbox" name="contactOptions[]" value="sms" 
                        <?= isset($customer['contact_options']) && is_array($customer['contact_options']) && in_array('sms', $customer['contact_options']) ? 'checked' : ''; ?>> 
                        Send SMS
                    </label>
                    </div>
                    </div>
                             <div class="form-group">
                                <label for="inputWebUrl" class="col-sm-4 control-label">WebURl</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputWebUrl" name="inputWebUrl" 
                                           placeholder="Enter WebURL" value="<?= htmlspecialchars(isset($customer['weburl']) ? $customer['weburl'] : ''); ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                            <label for="inputEmailId" class="col-sm-4 control-label">Email ID*</label>
                                <div class="col-sm-8">
                                    <input type="email" class="form-control" id="inputEmailId" name="inputEmailId" 
                                           placeholder="Enter Email ID" value="<?= htmlspecialchars(isset($customer['email_id']) ? $customer['email_id'] : ''); ?>" required>
                                    <div class="checkbox">
                         <label>
                            <input type="checkbox" name="emailOptions[]" value="send_email" <?= isset($customer['email_options']) && in_array('send_email', $customer['email_options']) ? 'checked' : ''; ?>> Send Email
                        </label>
                    </div>
                </div>
                </div>
                              <!-- Status Dropdown -->
                            <div class="form-group">
    <label for="inputStatus" class="col-sm-4 control-label">Status*</label>
    <div class="col-sm-8">
        <select class="form-control" id="inputStatus" name="inputStatus" required>
            <option value="">Select Status</option>
            <option value="activated" <?= isset($customer['status']) && $customer['status'] == '1' ? 'selected' : ''; ?>>Activated</option>
            <option value="deactivated" <?= isset($customer['status']) && $customer['status'] == '0' ? 'selected' : ''; ?>>Deactivated</option>
        </select>
    </div>
</div>


                        </div>

                        <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
    const cityMapping = <?= json_encode(array_column($cities, 'city_name', 'city_id')) ?>;
    const stateMapping = <?= json_encode(array_column($states, 'state_name', 'state_id')) ?>;
    const countryMapping = <?= json_encode(array_column($countries, 'country_name', 'country_id')) ?>;

document.getElementById('inputDistrictName').addEventListener('change', function () {
    const selectedDistrict = this.options[this.selectedIndex];
    const cityId = selectedDistrict.getAttribute('data-city-id');
    const stateId = selectedDistrict.getAttribute('data-state-id');
    const countryId = selectedDistrict.getAttribute('data-country-id');

    document.getElementById('inputCityName').value = cityMapping[cityId] || '';
    document.getElementById('inputStateName').value = stateMapping[stateId] || '';
    document.getElementById('inputCountryName').value = countryMapping[countryId] || '';

    document.getElementById('inputCityId').value = cityId || '';
    document.getElementById('inputStateId').value = stateId || '';
    document.getElementById('inputCountryId').value = countryId || '';
});

    document.getElementById('inputDistrictName').dispatchEvent(new Event('change'));
</script>

<?php include("include/footer.php"); ?>
