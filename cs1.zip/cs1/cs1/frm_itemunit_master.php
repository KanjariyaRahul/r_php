<?php
session_start();
include('config/connection.php');

$page = "itemunit_mapping";

// Redirect to login if not authenticated
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Fetch Units for AJAX Requests
if (isset($_POST['action']) && $_POST['action'] === 'fetch_units' && isset($_POST['item_id'])) {
    $itemId = intval($_POST['item_id']);
    if ($itemId) {
        try {
            $stmt = $connect->prepare("SELECT unit_id, unit FROM tbl_unit_master WHERE unit_id IN (SELECT unit_id FROM tbl_item_unit_master WHERE item_id=:item_id)");
            $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
            $stmt->execute();
            $units = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode($units); // Return JSON response
        } catch (PDOException $e) {
            error_log('Error fetching units: ' . $e->getMessage());
            echo json_encode(['error' => 'Error fetching units']);
        }
    }
    exit();
}

// Main Logic for Form Handling
$itemunitId = $_POST['itemunit_id'] ?? '';

$itemunit = [
    'item_id' => '',
    'unit_id' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => '',
];

$units = []; // To store units for selected item

try {
    // Fetch all items for the dropdown
    $stmtItems = $connect->prepare("SELECT item_id, item_name FROM tbl_item_master ORDER BY item_name ASC");
    $stmtItems->execute();
    $items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

    if ($itemunitId) {
        $stmtitemunit = $connect->prepare("SELECT * FROM tbl_{$page}_master WHERE itemunit_id = :itemunit_id");
        $stmtitemunit->bindParam(':itemunit_id', $itemunitId, PDO::PARAM_INT);
        $stmtitemunit->execute();
        $itemunit = $stmtitemunit->fetch(PDO::FETCH_ASSOC);

        if (!$itemunit) {
            $_SESSION['message'] = 'Record not found';
            header("Location: srh_itemunit_master.php");
            exit();
        }

        // Fetch units for the selected item
        $stmtUnits = $connect->prepare("SELECT unit_id, unit FROM tbl_unit_master WHERE unit_id IN (SELECT unit_id FROM tbl_item_unit_master WHERE item_id=:item_id)");
        $stmtUnits->bindParam(':item_id', $itemunit['item_id'], PDO::PARAM_INT);
        $stmtUnits->execute();
        $units = $stmtUnits->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log('Error fetching data: ' . $e->getMessage());
}

// Save Form Data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $itemId = trim($_POST['inputItemId'] ?? '');
    $unitId = trim($_POST['inputUnitId'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    if (empty($itemId) || empty($unitId)) {
        $_SESSION['message'] = 'Item and Unit are required';
        header("Location: frm_itemunit_master.php");
        exit();
    }

    try {
        if ($itemunitId) {
            $sql = "UPDATE tbl_{$page}_master 
                    SET item_id = :item_id,
                        unit_id = :unit_id, 
                        modified_date = NOW(),
                        modified_by = :modified_by 
                    WHERE itemunit_id = :itemunit_id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':itemunit_id', $itemunitId, PDO::PARAM_INT);
        } else {
            $sql = "INSERT INTO tbl_{$page}_master (item_id, unit_id, created_date, created_by, modified_date, modified_by) 
                    VALUES (:item_id, :unit_id, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
        }

        $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
        $stmt->bindParam(':unit_id', $unitId, PDO::PARAM_INT);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Record saved successfully';
            header("Location: srh_itemunit_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_itemunit_master.php");
            exit();
        }
    } catch (PDOException $e) {
        error_log('Error saving data: ' . $e->getMessage());
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_itemunit_master.php");
        exit();
    }
}
?>

<?php include("Include/header.php"); ?>
<?php include("Include/body_open.php"); ?>

<div class="wrapper">
    <?php include("Include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $itemunitId ? 'Edit Item-Unit Mapping' : 'Add Item-Unit Mapping'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="inputItemId" class="col-sm-4 control-label">Item*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputItemId" name="inputItemId" required>
                                        <option value="">Select Item</option>
                                        <?php foreach ($items as $item): ?>
                                            <option value="<?= htmlspecialchars($item['item_id']); ?>" 
                                                    <?= $item['item_id'] == $itemunit['item_id'] ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($item['item_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputUnitId" class="col-sm-4 control-label">Unit*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputUnitId" name="inputUnitId" required>
                                        <option value="">Select Unit</option>
                                        <?php foreach ($units as $unit): ?>
                                            <option value="<?= htmlspecialchars($unit['unit_id']); ?>" 
                                                    <?= $unit['unit_id'] == $itemunit['unit_id'] ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($unit['unit']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="hidden" name="itemunit_id" value="<?php echo $itemunitId; ?>" />
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_itemunit_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
document.getElementById('inputItemId').addEventListener('change', function() {
    const itemId = this.value;
    const unitSelect = document.getElementById('inputUnitId');

    unitSelect.innerHTML = '<option value="">Select Unit</option>';

    if (itemId) {
        const formData = new FormData();
        formData.append('action', 'fetch_units');
        formData.append('item_id', itemId);

        fetch('frm_itemunit_master.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (Array.isArray(data) && data.length > 0) {
                data.forEach(unit => {
                    const option = document.createElement('option');
                    option.value = unit.unit_id;
                    option.textContent = unit.unit;
                    unitSelect.appendChild(option);
                });
            } else {
                const option = document.createElement('option');
                option.textContent = 'No units available';
                unitSelect.appendChild(option);
            }
        })
        .catch(error => {
            console.error('Error fetching units:', error);
            const option = document.createElement('option');
            option.textContent = 'Failed to load units';
            unitSelect.appendChild(option);
        });
    }
});
</script>

<?php include('include/footer.php'); ?>
