<?php
session_start();
// Include the database connection
include('config/connection.php');

// Check if the `item_unit_id` is provided via GET or POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_unit_id'])) {
    $itemUnitId = $_POST['item_unit_id'];

    // Ensure the item_unit_id is valid
    if (empty($itemUnitId)) {
        $_SESSION['message'] = 'Invalid Item-Unit ID.';
        header("Location: srh_item_unit_master.php");
        exit();
    }

    try {
        // Prepare the delete query
        $stmt = $connect->prepare("DELETE FROM tbl_item_unit_master WHERE item_unit_id = :item_unit_id");
        $stmt->bindParam(':item_unit_id', $itemUnitId, PDO::PARAM_INT);

        // Execute the query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Item-Unit deleted successfully.';
        } else {
            $_SESSION['message'] = 'Failed to delete Item-Unit.';
        }
    } catch (Exception $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
    }

    // Redirect to the listing page
    header("Location: srh_item_unit_master.php");
    exit();
} else {
    $_SESSION['message'] = 'No Item-Unit ID provided.';
    header("Location: srh_item_unit_master.php");
    exit();
}
?>

