<?php
session_start();
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Check if the city_id is provided via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['city_id'])) {
    $cityId = $_POST['city_id'];

    try {
        // Prepare the DELETE query
        $stmt = $connect->prepare("DELETE FROM tbl_city_master WHERE city_id = :city_id");
        $stmt->bindParam(':city_id', $cityId, PDO::PARAM_INT);

        // Execute the query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'City deleted successfully.';
        } else {
            $_SESSION['message'] = 'Failed to delete city. Please try again.';
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
    }
} else {
    $_SESSION['message'] = 'Invalid request.';
}

// Redirect back to the city list page
header('Location: srh_city_master.php');
exit();
?>
