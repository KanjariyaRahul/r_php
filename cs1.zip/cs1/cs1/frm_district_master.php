<?php
session_start();
$page = "district";

// Include necessary files
include('config/connection.php');
include_once('classes/cls_district_master.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

$_bll = new bll_districtmaster(); // Initialize Business Logic Layer
$DistrictId = isset($_POST['district_id']) ? $_POST['district_id'] : '';
$district = $_bll->_mdl; // Reference the model object

// Populate the model if editing
if ($DistrictId) {
    $_REQUEST['district_id'] = $DistrictId; // Simulate a request for fetching data
    $_bll->fillModel();
}

// Determine transaction mode: "U" for update, "I" for insert
$transactionmode = $DistrictId ? "U" : "I";

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $_bll->_mdl->_district_id = $DistrictId ?: null;
    $_bll->_mdl->_district_name = trim($_POST['inputDistrictName']);
    $_bll->_mdl->_state_id = $_POST['inputStateId'];
    $_bll->_mdl->_city_id = $_POST['inputCityId'];
    $_bll->_mdl->_country_id = $_POST['inputCountryId'];
    $_bll->_mdl->_transactionmode = $transactionmode;
    $_bll->dbTransaction();
}

// Fetch mappings for dropdowns
try {
    $stmtStates = $connect->prepare("SELECT state_id, state_name FROM tbl_state_master ORDER BY state_name ASC");
    $stmtStates->execute();
    $states = $stmtStates->fetchAll(PDO::FETCH_ASSOC);

    $stmtCities = $connect->prepare("SELECT city_id, city_name, state_id, country_id FROM tbl_city_master ORDER BY city_name ASC");
    $stmtCities->execute();
    $cities = $stmtCities->fetchAll(PDO::FETCH_ASSOC);

    $stmtCountries = $connect->prepare("SELECT country_id, country_name FROM tbl_country_master ORDER BY country_name ASC");
    $stmtCountries->execute();
    $countries = $stmtCountries->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error loading data: " . $e->getMessage();
}
?>

<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("Include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $DistrictId ? 'Edit District' : 'Add District'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <input type="hidden" name="district_id" value="<?= htmlspecialchars($district->_district_id); ?>">
                            
                            <div class="form-group">
                                <label for="inputDistrictName" class="col-sm-4 control-label">District Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputDistrictName" name="inputDistrictName" 
                                           placeholder="Enter District" value="<?= htmlspecialchars($district->_district_name); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputCityName" class="col-sm-4 control-label">City Name*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputCityName" name="inputCityId" required>
                                        <option value="">Select City</option>
                                        <?php foreach ($cities as $cityOption): ?>
                                            <option 
                                                value="<?= htmlspecialchars($cityOption['city_id']); ?>" 
                                                data-state-id="<?= htmlspecialchars($cityOption['state_id']); ?>"
                                                data-country-id="<?= htmlspecialchars($cityOption['country_id']); ?>"
                                                <?= isset($district->_city_id) && $district->_city_id == $cityOption['city_id'] ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($cityOption['city_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputStateName" class="col-sm-4 control-label">State Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputStateName" name="inputStateName" 
                                           value="<?= isset($district->_state_id) && isset($stateMapping[$district->_state_id]) ? htmlspecialchars($stateMapping[$district->_state_id]) : ''; ?>" readonly>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputCountryName" class="col-sm-4 control-label">Country Name*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCountryName" name="inputCountryName" 
                                           value="<?= isset($district->_country_id) && isset($countryMapping[$district->_country_id]) ? htmlspecialchars($countryMapping[$district->_country_id]) : ''; ?>" readonly>
                                </div>
                            </div>

                            <input type="hidden" id="inputStateId" name="inputStateId" value="<?= htmlspecialchars($district->_state_id ?? ''); ?>">
                            <input type="hidden" id="inputCountryId" name="inputCountryId" value="<?= htmlspecialchars($district->_country_id ?? ''); ?>">
                        </div>
                        <div class="box-footer">
                            <input type="hidden" id="transactionmode" name="transactionmode" value="<?= $transactionmode ?>" />
                            <input class="btn btn-primary" type="submit" id="inputSave" name="inputSave" 
                                   value="<?= $transactionmode == 'U' ? 'Update' : 'Add'; ?>" />
                            <input class="btn btn-secondary" type="button" id="btn_reset" name="btn_reset" value="Reset" onclick="reset_data();" />
                            <input class="btn btn-secondary" type="button" id="btn_cancel" name="btn_cancel" value="Cancel" onclick="window.history.back();" />
                            <input class="btn btn-secondary" type="button" id="btn_search" name="btn_search" value="Search" onclick="window.location='srh_user_master.php'" />
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
    // Mapping of state and country names
    const stateMapping = <?= json_encode(array_column($states, 'state_name', 'state_id')) ?>;
    const countryMapping = <?= json_encode(array_column($countries, 'country_name', 'country_id')) ?>;

    // Event listener for when the city changes
    document.getElementById('inputCityName').addEventListener('change', function () {
        const selectedCity = this.options[this.selectedIndex];
        const stateId = selectedCity.getAttribute('data-state-id');
        const countryId = selectedCity.getAttribute('data-country-id');

        // Set the values for state and country fields
        document.getElementById('inputStateName').value = stateMapping[stateId] || '';
        document.getElementById('inputCountryName').value = countryMapping[countryId] || '';
        document.getElementById('inputStateId').value = stateId || '';
        document.getElementById('inputCountryId').value = countryId || '';
    });

    // Trigger change event to prefill state and country when editing
    document.getElementById('inputCityName').dispatchEvent(new Event('change'));
</script>

<?php include("include/footer.php"); ?>
<?php include("include/body_close.php"); ?>
