<?php
include('config/connection.php');
include('classes/cls_user_master.php');

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Initialize the user class
    $user = new cls_user_master();
    
    // Call the delete method from the cls_user_master class
    $user->delete($id);  // This will delete the user with the provided ID
    
    // Redirect to the user list page after deletion
    header("Location: srh_user_master.php"); // You can change this to your user listing page
    exit();
} else {
    // If no ID is provided, redirect to the user list page with an error or a message
    header("Location: srh_user_master.php?error=NoID");
    exit();
}
?>
