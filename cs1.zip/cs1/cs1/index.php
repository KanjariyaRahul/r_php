<?php
session_start();
include('config/connection.php'); // Make sure this file connects using PDO

if (isset($_POST["ad_login"])) {
    $stmt = $connect->prepare("SELECT * FROM tbl_user_master WHERE username = :username AND password = :password");
    $stmt->bindParam(':username', $_POST['username'], PDO::PARAM_STR);
    $stmt->bindParam(':password', $_POST['password'], PDO::PARAM_STR);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION["ad_session"] = $res["id"];
        $_SESSION["display_name"] = $res["name"];
        header("Location:dashboard.php");
        exit();
    } else {
        header("Location: index.php?err=1");
        exit();
    }
}
?>
<?php include('include/header.php');?>

<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="index1.php"><b>Admin</b></a>
  </div>
  <div class="login-box-body">
    <p class="login-box-msg">Login session</p>
    <form action="index.php" method="post">
      <div class="form-group has-feedback">
        <input type="text" name="username" class="form-control" placeholder="Username" required>
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-4">
          <button type="submit" name="ad_login" class="btn btn-primary btn-block btn-flat">Login</button>
        </div>
      </div>
    </form>
  </div>
    <?php if(isset($_REQUEST["err"]) && $_REQUEST["err"]==1) {
    ?>
      <div class="error">Invalid username or password.</div>
      <?php
}?>
</div>
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' 
    });
  });
</script>
