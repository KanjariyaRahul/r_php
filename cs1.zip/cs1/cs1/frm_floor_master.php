<?php
session_start();
$page = "floor"; // Changed to "floor" page

// Include the database connection
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Default values for a new record
$floorId = isset($_POST['floor_id']) ? $_POST['floor_id'] : ''; // Check for floorId in the URL

$floor = [
    'floor_id' => '',
    'floor' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => '',
];

// Fetch floor record if editing
if ($floorId) {
    $stmtFloor = $connect->prepare("SELECT * FROM tbl_floor_master WHERE floor_id = :floor_id");
    $stmtFloor->bindParam(':floor_id', $floorId, PDO::PARAM_INT);
    $stmtFloor->execute();
    $floor = $stmtFloor->fetch(PDO::FETCH_ASSOC);

    if (!$floor) {
        $_SESSION['message'] = 'Floor not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $floor = trim($_POST['inputFloor'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($floor)) {
        $_SESSION['message'] = 'Floor is required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($floorId) {
            // Update existing floor
            $sql = "UPDATE tbl_floor_master SET floor = :floor, modified_date = NOW(), modified_by = :modified_by WHERE floor_id = :floor_id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':floor_id', $floorId, PDO::PARAM_INT);
        } else {
            // Insert new floor
            $sql = "INSERT INTO tbl_floor_master (floor, created_date, created_by, modified_date, modified_by) 
                    VALUES (:floor, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
            $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);
        }

        // Bind parameters
        $stmt->bindParam(':floor', $floor, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Floor saved successfully';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>
<?php include("include/header.php"); ?>


<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $floorId ? 'Edit Floor' : 'Add Floor'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="inputFloor" class="col-sm-4 control-label">Floor*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputFloor" name="inputFloor" 
                                           placeholder="Enter Floor" value="<?php echo htmlspecialchars($floor['floor']); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="hidden" value="<?php echo $floorId; ?>" name="floor_id" />
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php include('include/footer.php'); ?>
