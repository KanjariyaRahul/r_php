<header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container-fluid">
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Master <span class="caret"></span></a>
                
                
                  <ul class="dropdown-menu" role="menu">
                <li><a href="srh_country_master.php">Country</a></li>
                <li><a href="srh_state_master.php">State</a></li>
                <li><a href="srh_city_master.php">City</a></li> 
                 <li><a href="srh_district_master.php">District</a></li>
                  <li><a href="srh_customer_master.php">Customer</a></li>
                <li class="divider"></li>
                <li><a href="#">Account Group</a></li>
                <li><a href="#">Account</a></li>
                <li class="divider"></li>
                <li><a href="srh_unit_master.php">Unit</a></li>
                <li><a href="srh_item_master.php">Item</a></li>
                <li><a href="srh_chamber_master.php">Chamber</a></li>
                <li><a href="srh_floor_master.php">Floor</a></li>
                <li><a href="srh_rack_master.php">Rack</a></li>
                 <li><a href="srh_location_master.php">Location</a></li>
                <li><a href="#">Item Rent Price List</a></li>
                <li class="divider"></li>
                <li><a href="#">Operator</a></li>
                <li><a href="#">GST Commodity</a></li>
                <li><a href="#">Flag List</a></li>
                <li><a href="#">Help</a></li>
                <li><a href="#">Switch Year</a></li>
              </ul>
                
                
              
            </li>
              <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transaction <span class="caret"></span></a>
                  
                <ul class="dropdown-menu" role="menu">
                <li><a href="#">Inward</a></li>
                <li><a href="#">Outward</a></li>
                 <li><a href="#">Invoice</a></li>     
                <li><a href="#">Item Stock</a></li>
                <li><a href="#">Receipt</a></li>
                <li><a href="#">Payment</a></li>
                <li><a href="#">Contra</a></li>
                <li><a href="#">Journal</a></li>
                <li><a href="#">Change Location</a></li>
              </ul>
              
            </li>
              <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Report <span class="caret"></span></a>
                  
                  
                   <ul class="dropdown-menu" role="menu">
                <li><a href="#">Inward Summary</a></li>
                <li><a href="#">Outward Summary</a></li>
                <li><a href="#">Inward Outward Summary</a></li>    
                    <li class="divider"></li>   
                <li><a href="#">Invoice Summary</a></li>
                <li><a href="#">Invoice GST Summary</a></li>
                <li><a href="#">Lot No. wise Inovice Summary</a></li>
                       <li class="divider"></li>
                <li><a href="#">Party Label</a></li>       
                <li><a href="#">Party wise Inward Balance</a></li>
                     <li class="divider"></li>  
                <li><a href="#">Location Detail View</a></li>
                     <li class="divider"></li>  
                <li><a href="#">Lot Statement</a></li>
                <li><a href="#">Item Statement</a></li>
                <li><a href="#">Item Stock Statement</a></li> 
                <li><a href="#">Item Rent Price List Report</a></li>
                     <li class="divider"></li>  
                <li><a href="#">Rent Valuation</a></li>
                <li><a href="#">Cover Print</a></li>
                <li><a href="#">Custom List</a></li>          
              </ul>
              
            </li>
              <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Account <span class="caret"></span></a>
                  
                <ul class="dropdown-menu" role="menu">
                <li><a href="#">Day Book</a></li>
                <li><a href="#">Cash & Bank</a></li>
                 <li><a href="#">Account Ledger</a></li>     
                <li><a href="#">Trial Balance</a></li>
                <li><a href="#">Profit & Loss</a></li>
                <li><a href="#">Balance Sheet</a></li>
                <li><a href="#">List of Account</a></li>
              </ul>
                  
              
            </li>
              <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="company_master.php">Company</a></li>
                <li><a href="#">Company Year</a></li>
                <li class="divider"></li>
                <li><a href="#">Menu</a></li>
                <li><a href="#">Module</a></li>
                <li class="divider"></li>
                <li><a href="srh_user_master.php">User Master</a></li>
                <li><a href="#">User Right</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-collapse -->
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- User Account Menu -->
            <li class="dropdown user user-menu">
              <!-- Menu Toggle Button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <!-- The user image in the navbar-->
                <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                <!-- hidden-xs hides the username on small devices so only the image appears. -->
                <span class="hidden-xs">Alexander Pierce</span>
              </a>
              <ul class="dropdown-menu">
                <!-- Menu Footer-->
                <li>
                    <a href="#">Profile</a>
                  </li>
                  <li>
                    <a href="sign_out.php">Sign out</a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-custom-menu -->
      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>