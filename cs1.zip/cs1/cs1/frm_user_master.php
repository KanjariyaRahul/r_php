<?php
include("classes/cls_user_master.php");
include("include/header.php");
?>

<script type="text/javascript"> 
    function reset_data() {
        document.getElementById("user_master_form").reset();
    }
</script>

<?php

$transactionmode = "";
if (isset($_REQUEST["transactionmode"])) {    
    $transactionmode = $_REQUEST["transactionmode"];
}

if ($transactionmode == "U") {    
    $_bll->fillModel();
    $label = "Update";
} else {
    $label = "Add";
}
?>

<body class="hold-transition skin-blue layout-top-nav">
<?php
include("include/body_open.php");
?>
<div class="wrapper">
<?php
include("include/navigation.php");
?>
<div class="content-wrapper">
    <div class="container-fluid">
        <section class="content-header">
            <h1>
                <?php echo $label; ?> User
            </h1>
            <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="srh_user_master.php"><i class="fa fa-users"></i> User Master</a></li>
                <li class="active"><?php echo $label; ?></li>
            </ol>
        </section>

        <section class="content">
            <div class="col-md-12" style="padding:0;">
                <div class="box box-info">
                    <form id="user_master_form" action="frm_user_master.php" method="post" class="form-horizontal">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="username" class="col-sm-2 control-label">Username*</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="username" name="inputUsername" placeholder="Username" 
                                           value="<?php if ($transactionmode == "U") echo $_bll->_mdl->_username; ?>" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Name*</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="name" name="inputPersonName" placeholder="Name" 
                                           value="<?php if ($transactionmode == "U") echo $_bll->_mdl->_name; ?>" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password" class="col-sm-2 control-label">Password*</label>
                                <div class="col-sm-4">
                                    <input type="password" class="form-control" id="password" name="inputPassword" placeholder="Password" 
                                           value="<?php if ($transactionmode == "U") echo $_bll->_mdl->_password; ?>" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="status" class="col-sm-2 control-label">Status</label>
                                <div class="col-sm-4">
                                    <input type="checkbox" id="status" name="inputEnable" value="1" 
                                           <?php if ($transactionmode == "U" && $_bll->_mdl->_status == 1) echo 'checked="checked"'; ?> />
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="hidden" id="id" name="id" 
                                   value="<?php if ($transactionmode == "U") echo $_bll->_mdl->_id; ?>" />
                            <input type="hidden" id="transactionmode" name="transactionmode" 
                                   value="<?php echo $transactionmode == "U" ? "U" : "I"; ?>" />
                            <input class="btn btn-primary" type="submit" id="inputSave" name="inputSave" 
                                   value="<?php echo $transactionmode == "U" ? "Update" : "Add"; ?>" />
                            <input class="btn btn-secondary" type="button" id="btn_reset" name="btn_reset" value="Reset" onclick="reset_data();" />
                            <input class="btn btn-secondary" type="button" id="btn_cancel" name="btn_cancel" value="Cancel" onclick="window.history.back();" />
                            <input class="btn btn-secondary" type="button" id="btn_search" name="btn_search" value="Search" onclick="window.location='srh_user_master.php'" />
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php
include("include/footer.php");
?>
</div>
