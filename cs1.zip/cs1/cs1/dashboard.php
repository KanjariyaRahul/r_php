<?php
session_start();

// Check if session exists
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

include('config/connection.php');

// Handle form submission
if (isset($_POST['inputSave'])) {
    // Get form inputs
    $username = $_POST['inputUsername'] ?? '';
    $password = $_POST['inputPassword'] ?? ''; // Store password as plain text
    $personName = $_POST['inputPersonName'] ?? '';
    $enable = isset($_POST['inputEnable']) ? 1 : 0;

    // Prepare SQL query to insert data into the database
    $sql = "INSERT INTO tbl_user_master (username, password, name, status) VALUES (:email, :password, :name, :status)";

    try {
        // Prepare statementx
        $stmt = $connect->prepare($sql);
        
        // Bind parameters
        $stmt->bindParam(':email', $username, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->bindParam(':name', $personName, PDO::PARAM_STR);
        $stmt->bindParam(':status', $enable, PDO::PARAM_INT);

        // Execute the statement
        if ($stmt->execute()) {
            $_SESSION['message'] = 'User saved successfully';
            header('Location: user_master.php'); // Redirect with success message
            exit();
        } else {
            $_SESSION['message'] = 'Error executing query';
            header('Location: user_master_edit.php'); // Redirect with error message
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header('Location: user_master_edit.php'); // Redirect with error message
        exit();
    }
}

// Close the connection (PDO will automatically close the connection at the end of the script)
?>


<?php include('include/header.php');?>
<?php include('include/body_open.php');?>
<div class="wrapper">

<?php include('include/navigation.php');?>

    <div class="content-wrapper">
        <div class="container">    
            <div class="container-fluid">
                <section class="content-header">
                    <h1>
                        Dashboard
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li><a href="srh_user_master.php"><i class="fa fa-dashboard"></i> User Master</a></li>
                        <li class="active">Add Admin User</li>
                    </ol>
                </section>

               
            </div>  
        </div>
    </div>

  <?php include('include/footer.php');  ?> 