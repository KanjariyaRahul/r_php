<?php
// Ensure the correct database connection is included
include('config/connection.php');

// Get the state_id from the AJAX request
$stateId = $_POST['state_id'] ?? null;

// Validate the state_id
if ($stateId) {
    try {
        // Prepare and execute the query to fetch countries for the state
        $stmt = $connect->prepare("SELECT country_id, country_name FROM tbl_country_master WHERE state_id = :state_id ORDER BY country_name ASC");
        $stmt->bindParam(':state_id', $stateId, PDO::PARAM_INT);
        $stmt->execute();
        $countries = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if countries were found
        if ($countries) {
            foreach ($countries as $country) {
                // Return countries as options for the country dropdown
                echo "<option value='" . htmlspecialchars($country['country_id']) . "'>" . htmlspecialchars($country['country_name']) . "</option>";
            }
        } else {
            echo "<option value=''>No countries found for this state</option>";  // Message when no countries are found
        }
    } catch (PDOException $e) {
        // Output the error message for debugging (useful in development)
        echo "<option value=''>Error loading countries: " . htmlspecialchars($e->getMessage()) . "</option>";
    }
} else {
    // Return a message if state_id is not passed or invalid
    echo "<option value=''>Invalid state selection</option>";
}
?>
