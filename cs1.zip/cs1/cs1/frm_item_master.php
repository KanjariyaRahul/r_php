<?php
session_start();
// Include the database connection
include('config/connection.php');
$page = "item";
$item = $item ?? [];
$itemId = $_POST['item_id'] ?? null;

try {
    // Fetch all items from tbl_item_master
    $stmtItems = $connect->prepare("SELECT * FROM tbl_item_master ORDER BY item_name ASC");
    $stmtItems->execute();
    $items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error loading data: " . $e->getMessage();
}

if ($itemId) {
    // Fetch single item for editing
    $stmtItems = $connect->prepare("SELECT * FROM tbl_item_master WHERE item_id = :item_id");
    $stmtItems->bindParam(':item_id', $itemId, PDO::PARAM_INT);
    $stmtItems->execute();
   $item = $stmtItems->fetch(PDO::FETCH_ASSOC);

    // If item not found, redirect with a message
    if (!$item) {
        $_SESSION['message'] = 'Item not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    // Get form data
    $itemName = trim($_POST['inputItemName'] ?? '');
    $gst = trim($_POST['inputGst'] ?? '');
    $marketRate = trim($_POST['inputMarketRate'] ?? '');
    $lifeItem = trim($_POST['inputLifeItem'] ?? '');
$status = $_POST['inputStatus'] ?? '';
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Validate required fields
    if (empty($itemName) || empty($gst) || empty($marketRate) || empty($lifeItem) || empty($status)) {
        $_SESSION['message'] = 'Please fill out all required fields.';
        header("Location: frm_{$page}_master.php");
        exit();
    }
    
        // Validate required fields
$validStatuses = ['activated', 'deactivated'];
    if (!in_array($status, $validStatuses)) {
        $_SESSION['message'] = 'Invalid status value provided.';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    // Map status to numeric value for database storage
    $statusValue = $status === 'activated' ? 1 : 0;
    try {
        if ($itemId) {
            // Update existing item
            $sql = "UPDATE tbl_item_master SET 
                        item_name = :item_name,
                        gst = :gst,
                        market_rate = :market_rate,
                        life_item = :life_item,
                        status = :status,
                        modified_date = NOW(),
                        modified_by = :modified_by
                    WHERE item_id = :item_id";
        } else {
            // Insert new item
            $sql = "INSERT INTO tbl_item_master 
                        (item_name, gst, market_rate, life_item, status, created_date, created_by, modified_date, modified_by)
                    VALUES 
                        (:item_name, :gst, :market_rate, :life_item, :status, NOW(), :created_by, NOW(), :modified_by)";
        }

        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':item_name', $itemName);
        $stmt->bindParam(':gst', $gst);
        $stmt->bindParam(':market_rate', $marketRate);
        $stmt->bindParam(':life_item', $lifeItem);
         $stmt->bindParam(':status', $statusValue);
        $stmt->bindParam(':modified_by', $modifiedBy);

        if (!$itemId) {
            $stmt->bindParam(':created_by', $createdBy);
        } else {
            $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
        }

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Item saved successfully.';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            throw new Exception('Failed to save item.');
        }
    } catch (Exception $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>


<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>
<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $itemId ? 'Edit Item' : 'Add Item'; ?></h1>
        </section>
         <section class="content">
              <div class="col-md-6" style="padding:0;">
                   <div class="box box-info">
                          <form class="form-horizontal" method="post">
                                 <div class="box-body">
                                      <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($itemId); ?>">
                                     <div class="form-group">
                                <label for="inputItemName" class="col-sm-4 control-label">Item Name</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputItemName" name="inputItemName" 
                                           placeholder="Enter Item Name" value="<?= htmlspecialchars(isset($item['item_name']) ? $item['item_name'] : ''); ?>"
                                        required>
                                </div>
                            </div>
                                      <div class="form-group">
        <label for="inputGst" class="col-sm-4 control-label">GST</label>
        <div class="col-sm-8">
            <label class="radio-inline">
                <input type="radio" name="inputGst" value="gst_applicable" <?= isset($item['gst']) && $item['gst'] === 'gst_applicable' ? 'checked' : ''; ?>>
                GST Applicable
            </label>
             <label class="radio-inline">
                <input type="radio" name="inputGst" value="gst_exempted" <?= isset($item['gst']) && $item['gst'] === 'gst_exempted' ? 'checked' : ''; ?>>
                GST Exempted
            </label>
                <label class="radio-inline">
                <input type="radio" name="inputGst" value="none" <?= isset($item['gst']) && $item['gst'] === 'none' ? 'checked' : ''; ?>>
                None
            </label>
        </div>
        </div>
                                       <div class="form-group">
                                <label for="inputMarketRate" class="col-sm-4 control-label">Market Rate</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputMarketRate" name="inputMarketRate" 
                                           placeholder="Enter Market Rate" value="<?= htmlspecialchars(isset($item['market_rate']) ? $item['market_rate'] : ''); ?>"
                                        required>
                                </div>
                            </div>
                                      <div class="form-group">
                                <label for="inputLifeItem" class="col-sm-4 control-label">Life Item</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputLifeItem" name="inputLifeItem" 
                                           placeholder="Enter Life Item" value="<?= htmlspecialchars(isset($item['life_item']) ? $item['life_item'] : ''); ?>"
                                        required>
                                </div>
                            </div>
                                       <!-- Status Dropdown -->
<div class="form-group">
    <label for="inputStatus" class="col-sm-4 control-label">Status*</label>
    <div class="col-sm-8">
        <select class="form-control" id="inputStatus" name="inputStatus" required>
            <option value="" <?= !isset($item['status']) ? 'selected' : ''; ?>>Select Status</option>
            <option value="activated" <?= isset($item['status']) && (string)$item['status'] === "1" ? 'selected' : ''; ?>>Activated</option>
            <option value="deactivated" <?= isset($item['status']) && (string)$item['status'] === "0" ? 'selected' : ''; ?>>Deactivated</option>
        </select>
    </div>
</div>

</div>
                              <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Submit</button>
                        </div>
                       </form>
                  </div>
             </div>
        </section>
        
    </div>
</div>
<?php include("include/footer.php"); ?>
