<?php
session_start();
include('config/connection.php');

$page = "location";

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}
$locationId = $_POST['location_id'] ?? null;

$user = [
    'location_id' => '',
    'customer_id' => '',
    'chamber_id' => '',
    'floor_id' => '', 
    'rack_id' => '', 
    'location' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => ''
];

if ($locationId) {
    $stmt = $connect->prepare("SELECT * FROM tbl_{$page}_master WHERE location_id = :id");
    $stmt->bindParam(':id', $locationId, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['message'] = ucfirst($page) . ' not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $customerId = trim($_POST['inputCustomerName'] ?? '');
    $chamberId = trim($_POST['inputChamber'] ?? '');
    $floorId = trim($_POST['inputFloor'] ?? '');
    $rackId = trim($_POST['inputRack'] ?? '');
    $location = trim($_POST['inputLocation'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($location) || empty($customerId)) {
        $_SESSION['message'] = 'Location and Customer are required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($locationId) {
            // Update query
           $sql = "UPDATE tbl_{$page}_master 
                    SET customer_id = :customer_id,
                        chamber_id = :chamber_id, 
                        floor_id = :floor_id,
                        rack_id = :rack_id,
                        location = :location,
                        created_by =:created_by,
                        modified_date = NOW(), 
                        modified_by = :modified_by 
                    WHERE location_id = :location_id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':location_id', $locationId, PDO::PARAM_INT);
        } else {
            // Insert query
            $sql = "INSERT INTO tbl_{$page}_master 
                    (customer_id, chamber_id, floor_id, rack_id, location, created_date, created_by, modified_date, modified_by) 
                    VALUES (:customer_id, :chamber_id, :floor_id, :rack_id, :location, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
        }

        // Bind parameters
        $stmt->bindParam(':customer_id', $customerId, PDO::PARAM_INT);
        $stmt->bindParam(':chamber_id', $chamberId, PDO::PARAM_INT);
        $stmt->bindParam(':floor_id', $floorId, PDO::PARAM_INT);
        $stmt->bindParam(':rack_id', $rackId, PDO::PARAM_INT);
        $stmt->bindParam(':location', $location, PDO::PARAM_STR);
        $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute query
        if ($stmt->execute()) {
            $_SESSION['message'] = ucfirst($page) . ($locationId ? ' updated successfully' : ' created successfully');
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>

<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include('include/navigation.php'); ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $locationId ? 'Edit Location' : 'Add Location'; ?></h1>
            <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="srh_<?= $page ?>_master.php"><?= ucfirst($page) ?> Master</a></li>
                <li class="active"><?php echo $locationId ? 'Edit Location' : 'Add Location'; ?></li>
            </ol>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <input type="hidden" name="location_id" value="<?php echo htmlspecialchars($locationId); ?>">

                            <!-- Customer Name -->
                            <div class="form-group">
                                <label for="inputCustomerName" class="col-sm-4 control-label">Customer Name*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputCustomerName" name="inputCustomerName" required>
                                        <option value="">Select Customer</option>
                                        <?php
                                        try {
                                            // Updated query to only select active customers
                                            $stmt = $connect->prepare("SELECT customer_id, customer_name FROM tbl_customer_master WHERE status = 1 ORDER BY customer_name ASC");
                                            $stmt->execute();
                                            $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($customers as $customer) {
                                                $selected = (!empty($user['customer_id']) && $user['customer_id'] == $customer['customer_id']) ? 'selected' : '';
                                                echo "<option value='" . htmlspecialchars($customer['customer_id']) . "' $selected>" . htmlspecialchars($customer['customer_name']) . "</option>";
                                            }
                                        } catch (PDOException $e) {
                                            echo "<option value=''>Error loading customers</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Chamber -->
                            <div class="form-group">
                                <label for="inputChamber" class="col-sm-4 control-label">Chamber*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputChamber" name="inputChamber" required>
                                        <option value="">Select Chamber</option>
                                        <?php
                                        try {
                                            $stmt = $connect->prepare("SELECT chamber_id, chamber FROM tbl_chamber_master ORDER BY chamber ASC");
                                            $stmt->execute();
                                            $chambers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($chambers as $chamber) {
                                                $selected = (!empty($user['chamber_id']) && $user['chamber_id'] == $chamber['chamber_id']) ? 'selected' : '';
                                                echo "<option value='" . htmlspecialchars($chamber['chamber_id']) . "' $selected>" . htmlspecialchars($chamber['chamber']) . "</option>";
                                            }
                                        } catch (PDOException $e) {
                                            echo "<option value=''>Error loading chambers</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Floor -->
                            <div class="form-group">
                                <label for="inputFloor" class="col-sm-4 control-label">Floor*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputFloor" name="inputFloor" required>
                                        <option value="">Select Floor</option>
                                        <?php
                                        try {
                                            $stmt = $connect->prepare("SELECT floor_id, floor FROM tbl_floor_master ORDER BY floor ASC");
                                            $stmt->execute();
                                            $floors = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($floors as $floor) {
                                                $selected = (!empty($user['floor_id']) && $user['floor_id'] == $floor['floor_id']) ? 'selected' : '';
                                                echo "<option value='" . htmlspecialchars($floor['floor_id']) . "' $selected>" . htmlspecialchars($floor['floor']) . "</option>";
                                            }
                                        } catch (PDOException $e) {
                                            echo "<option value=''>Error loading floors</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Rack -->
                            <div class="form-group">
                                <label for="inputRack" class="col-sm-4 control-label">Rack*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputRack" name="inputRack" required>
                                        <option value="">Select Rack</option>
                                        <?php
                                        try {
                                            $stmt = $connect->prepare("SELECT rack_id, rack FROM tbl_rack_master ORDER BY rack ASC");
                                            $stmt->execute();
                                            $racks = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($racks as $rack) {
                                                $selected = (!empty($user['rack_id']) && $user['rack_id'] == $rack['rack_id']) ? 'selected' : '';
                                                echo "<option value='" . htmlspecialchars($rack['rack_id']) . "' $selected>" . htmlspecialchars($rack['rack']) . "</option>";
                                            }
                                        } catch (PDOException $e) {
                                            echo "<option value=''>Error loading racks</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputLocation" class="col-sm-4 control-label">Location*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputLocation" name="inputLocation" value="<?php echo htmlspecialchars($user['location']); ?>" required>
                                </div>
                            </div>

                        </div>

                        <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const customerSelect = document.getElementById("inputCustomerName");
        const chamberSelect = document.getElementById("inputChamber");
        const floorSelect = document.getElementById("inputFloor");
        const rackSelect = document.getElementById("inputRack");
        const locationInput = document.getElementById("inputLocation");

        function generateLocation() {
            const customer = customerSelect.options[customerSelect.selectedIndex].text;
            const chamber = chamberSelect.options[chamberSelect.selectedIndex].text;
            const floor = floorSelect.options[floorSelect.selectedIndex].text;
            const rack = rackSelect.options[rackSelect.selectedIndex].text;

            locationInput.value = `${customer} - ${chamber} - ${floor} - ${rack}`;
        }

        customerSelect.addEventListener('change', generateLocation);
        chamberSelect.addEventListener('change', generateLocation);
        floorSelect.addEventListener('change', generateLocation);
        rackSelect.addEventListener('change', generateLocation);
    });
</script>

<?php include('include/footer.php'); ?>
