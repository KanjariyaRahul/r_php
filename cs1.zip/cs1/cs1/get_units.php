<?php
include('config/connection.php');

$itemId = $_GET['item_id'] ?? null;

if ($itemId) {
    try {
        // Fetch units associated with the selected item
        $stmt = $connect->prepare("SELECT u.unit_id, u.unit FROM tbl_unit_master u
                                   JOIN tbl_item_unit_master ium ON u.unit_id = ium.unit_id
                                   WHERE ium.item_id = :item_id ORDER BY u.unit ASC");
        $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
        $stmt->execute();
        $units = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($units); // Return units as JSON
    } catch (PDOException $e) {
        echo json_encode([]); // Return empty array if error occurs
    }
} else {
    echo json_encode([]);
}
?>
