<?php
session_start();
include('config/connection.php');

$page = "item_unit";

// Redirect if session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

$itemunitId = $_POST['item_unit_id'] ?? $_GET['item_unit_id'] ?? null; // Get item_unit_id from GET or POST

// Default user data
$user = [
    'item_unit_id' => '',
    'item_id' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => ''
];

if ($itemunitId) {
    // Fetch data for editing
    $stmt = $connect->prepare("SELECT * FROM tbl_{$page}_master WHERE item_unit_id = :id");
    $stmt->bindParam(':id', $itemunitId, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['message'] = ucfirst($page) . ' not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Get existing unit associations for editing
$selectedUnits = [];
if ($itemunitId) {
    $stmt = $connect->prepare("SELECT unit_id FROM tbl_item_unit_master WHERE item_id = :item_id");
    $stmt->bindParam(':item_id', $user['item_id'], PDO::PARAM_INT);
    $stmt->execute();
    $selectedUnits = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $itemId = trim($_POST['inputItemName'] ?? '');
    $units = $_POST['inputUnit'] ?? []; // Array of selected units
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($itemId) || empty($units)) {
        $_SESSION['message'] = 'Item and at least one Unit are required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        // Handle both Insert and Update based on whether itemunitId is present
        if ($itemunitId) {
            // Update query (We don't update the unit_id, we delete and add new)
            $sql = "UPDATE tbl_{$page}_master 
                    SET item_id = :item_id,
                        created_by = :created_by,
                        modified_date = NOW(), 
                        modified_by = :modified_by
                    WHERE item_unit_id = :item_unit_id"; // Fix the query syntax here
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':item_unit_id', $itemunitId, PDO::PARAM_INT);
            $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
            $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);
            $stmt->execute();
        }

        // Delete old associations and Insert new ones
        $stmt = $connect->prepare("DELETE FROM tbl_item_unit_master WHERE item_id = :item_id");
        $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
        $stmt->execute();

        // Insert each selected unit
        foreach ($units as $unitId) {
            $unitId = trim($unitId); // Ensure each unitId is clean

            // Insert query for new unit associations
            $sql = "INSERT INTO tbl_item_unit_master 
                    (item_id, unit_id, created_date, created_by, modified_date, modified_by) 
                    VALUES (:item_id, :unit_id, NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);

            // Bind parameters for insert
            $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
            $stmt->bindParam(':unit_id', $unitId, PDO::PARAM_INT);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
            $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

            // Execute query for each unit
            if (!$stmt->execute()) {
                throw new Exception('Failed to save data for unit: ' . $unitId);
            }
        }

        $_SESSION['message'] = ucfirst($page) . ' saved successfully';
        header("Location: srh_{$page}_master.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['message'] = $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}

?>

<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include('include/navigation.php'); ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $itemunitId ? 'Edit Item Unit' : 'Add Item Unit'; ?></h1>
            <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="srh_<?= $page ?>_master.php"><?= ucfirst($page) ?> Master</a></li>
                <li class="active"><?php echo $itemunitId ? 'Edit Item Unit' : 'Add Item Unit'; ?></li>
            </ol>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <input type="hidden" name="item_unit_id" value="<?php echo htmlspecialchars($itemunitId); ?>">

                            <!-- Item -->
                            <div class="form-group">
                                <label for="inputItemName" class="col-sm-4 control-label">Item*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputItemName" name="inputItemName" required>
                                        <option value="">Select Item</option>
                                        <?php
                                        try {
                                            $stmt = $connect->prepare("SELECT item_id, item_name FROM tbl_item_master WHERE status = 1 ORDER BY item_name ASC");
                                            $stmt->execute();
                                            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                            foreach ($items as $item) {
                                                $selected = (!empty($user['item_id']) && $user['item_id'] == $item['item_id']) ? 'selected' : '';
                                                echo "<option value='" . htmlspecialchars($item['item_id']) . "' $selected>" . htmlspecialchars($item['item_name']) . "</option>";
                                            }
                                        } catch (PDOException $e) {
                                            echo "<option value=''>Error loading items</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Units -->
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Units*</label>
                                <div class="col-sm-8">
                                    <?php
                                    try {
                                        $stmt = $connect->prepare("SELECT unit_id, unit FROM tbl_unit_master ORDER BY unit ASC");
                                        $stmt->execute();
                                        $units = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($units as $unit) {
                                            $checked = in_array($unit['unit_id'], $selectedUnits) ? 'checked' : '';
                                            echo "<div class='checkbox'><label>";
                                            echo "<input type='checkbox' name='inputUnit[]' value='" . htmlspecialchars($unit['unit_id']) . "' $checked> ";
                                            echo htmlspecialchars($unit['unit']);
                                            echo "</label></div>";
                                        }
                                    } catch (PDOException $e) {
                                        echo "Error loading units";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php include('include/footer.php'); ?> 