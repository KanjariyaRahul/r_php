<?php
session_start();
// Include the database connection
include('config/connection.php');

$page = "unit";
$unit = [];
$unitId = $_POST['unit_id'] ?? null; // Retrieve `unit_id` from POST if available

// Fetch unit details if editing
if ($unitId) {
    $stmtUnit = $connect->prepare("call search_unit_master()");
    $stmtUnit->bindParam(':unit_id', $unitId, PDO::PARAM_INT);
    $stmtUnit->execute();
    $unit = $stmtUnit->fetch(PDO::FETCH_ASSOC);

    if (!$unit) {
        $_SESSION['message'] = 'Unit not found.';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $unitName = trim($_POST['inputUnit'] ?? '');
    $conversionFactor = trim($_POST['inputConvertionFct'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Validate required fields
    if (empty($unitName) || empty($conversionFactor)) {
        $_SESSION['message'] = 'Please fill out all required fields.';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($unitId) {
            // Update query
            $sql = "UPDATE tbl_unit_master SET 
                        unit = :unit,
                        conversion_factor = :conversion_factor,
                        modified_date = NOW(),
                        modified_by = :modified_by
                    WHERE unit_id = :unit_id";
        } else {
            // Insert query
            $sql = "INSERT INTO tbl_unit_master 
                        (unit, conversion_factor, created_date, created_by, modified_date, modified_by)
                    VALUES 
                        (:unit, :conversion_factor, NOW(), :created_by, NOW(), :modified_by)";
        }

        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':unit', $unitName);
        $stmt->bindParam(':conversion_factor', $conversionFactor);
        $stmt->bindParam(':modified_by', $modifiedBy);

        if (!$unitId) {
            $stmt->bindParam(':created_by', $createdBy);
        } else {
            $stmt->bindParam(':unit_id', $unitId, PDO::PARAM_INT);
        }

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Unit saved successfully.';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            throw new Exception('Failed to save the unit.');
        }
    } catch (Exception $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>
<?php include("include/header.php"); ?>
<?php include("include/body_open.php"); ?>

<div class="wrapper">
   

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <input type="hidden" name="unit_id" value="<?= htmlspecialchars($unitId); ?>">

                            <div class="form-group">
                                <label for="inputUnit" class="col-sm-4 control-label">Unit*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputUnit" name="inputUnit" 
                                           placeholder="Enter Unit" value="<?= htmlspecialchars($unit['unit'] ?? ''); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputConvertionFct" class="col-sm-4 control-label">Conversion Factor*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputConvertionFct" name="inputConvertionFct" 
                                           placeholder="Enter Conversion Factor" value="<?= htmlspecialchars($unit['conversion_factor'] ?? ''); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>

<script>
// JavaScript to auto-calculate the Conversion Factor based on Unit (e.g., 40kg, 150g, 500m)
document.addEventListener("DOMContentLoaded", function() {
    // Grab the unit and conversion factor fields
    var unitField = document.getElementById("inputUnit");
    var conversionFactorField = document.getElementById("inputConvertionFct");

    unitField.addEventListener("input", function() {
        // Call the function to calculate the conversion factor based on the input
        calculateConversionFactor(unitField.value);
    });

    // Function to calculate conversion factor
    function calculateConversionFactor(unitValue) {
        // Extract the number and unit from the unit input (e.g., "40kg", "150g", "500m")
        var unitMatch = unitValue.match(/^(\d+)([a-zA-Z]+)$/);  // Allow any number and any letters as unit

        if (unitMatch) {
            var number = parseInt(unitMatch[1]);  // The numeric part (e.g., 40)
            var unitType = unitMatch[2].toLowerCase();  // The unit part (e.g., "kg", "g", "m")

            // Default conversion factor
            var conversionFactor = 1;

            // Example: Conversion logic based on different unit types
            if (unitType === "kg") {
                conversionFactor = 2.20462 * (number);  // Example for kg to pounds
            } else if (unitType === "g") {
                conversionFactor = 0.035274 * (number);  // Example for grams to ounces
            } else if (unitType === "m") {
                conversionFactor = 3.28084 * (number);  // Example for meters to feet
            } else if (unitType === "cm") {
                conversionFactor = 0.393701 * (number);  // Example for centimeters to inches
            } else if (unitType === "l") {
                conversionFactor = 0.264172 * (number);  // Example for liters to gallons
            } else if (unitType === "ml") {
                conversionFactor = 0.033814 * (number);  // Example for milliliters to fluid ounces
            } else {
                conversionFactor = 1;  // No conversion if the unit is unknown
            }

            // Set the calculated conversion factor
            conversionFactorField.value = conversionFactor.toFixed(2); // Fixed to 2 decimal places
        } else {
            conversionFactorField.value = "";  // Reset if input is invalid
        }
    }
});
</script>

<?php include("include/footer.php"); ?>
