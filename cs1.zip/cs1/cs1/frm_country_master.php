<?php
$page = "country";  // Change this to country instead of user
session_start();
include('config/connection.php');

// Redirect if session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

$countryId = $_POST['country_id'] ?? null; // Get the ID from POST or null if not editing

// Default country data
$countryData = [
    'country_name' => '',
    'created_by' => '',
    'modified_by' => ''
];

// Fetch the country record if editing
if ($countryId && $countryId != 0) {
    try {
        $stmt = $connect->prepare("SELECT * FROM tbl_{$page}_master WHERE country_id = :id");
        $stmt->bindParam(':id', $countryId, PDO::PARAM_INT);
        $stmt->execute();
        $countryData = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$countryData) {
            $_SESSION['message'] = 'Country not found';
            header("Location: srh_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic
if (isset($_POST['inputSave'])) {
    $countryName = trim($_POST['inputCountryName'] ?? '');
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Validation
    if (empty($countryName)) {
        $_SESSION['message'] = 'Country name is required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        // Prepare SQL to call the transaction_country_master stored procedure
        $sql = "CALL transaction_country_master(:country_id, :country_name, :created_by, :modified_by, @message)";
        $stmt = $connect->prepare($sql);

        // Bind parameters for the stored procedure
        $stmt->bindParam(':country_id', $countryId, PDO::PARAM_INT); // Pass the country_id for update or delete
        $stmt->bindParam(':country_name', $countryName, PDO::PARAM_STR);
        $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute the stored procedure
        $stmt->execute();

        // Fetch the message output from the stored procedure
        $messageStmt = $connect->query("SELECT @message AS message");
        $message = $messageStmt->fetch(PDO::FETCH_ASSOC)['message'];

        // Set session message and redirect
        $_SESSION['message'] = $message;
        header("Location: srh_{$page}_master.php");
        exit();

    } catch (PDOException $e) {
        // Log any errors that occur during query execution
        $errorInfo = $stmt->errorInfo();
        $_SESSION['message'] = 'Error: ' . implode(", ", $errorInfo);
        file_put_contents('error_log.txt', 'Error executing query: ' . implode(", ", $errorInfo) . "\n", FILE_APPEND);
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>

<?php include('include/header.php'); ?>
<?php include('include/body_open.php'); ?>

<div class="wrapper">
    <?php include('include/navigation.php'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <section class="content-header">
            <h1><?php echo $countryId ? 'Edit Country' : 'Add Country'; ?></h1>
            <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="srh_<?php echo $page ?>_master.php"><i class="fa fa-dashboard"></i> Country Master</a></li>
                <li class="active"><?php echo $countryId ? 'Edit Country' : 'Add Country'; ?></li>
            </ol>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" name="formCountry" id="formCountry" method="post">
                        <div class="box-body">
                            <input type="hidden" name="country_id" value="<?php echo htmlspecialchars($countryId); ?>">
                            
                            <div class="form-group">
                                <label for="inputCountryName" class="col-sm-2 control-label">Country Name*</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="inputCountryName" id="inputCountryName" value="<?php echo htmlspecialchars($countryData['country_name'] ?? '') ?>" placeholder="Country Name" required="">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?php echo $page ?>_master.php'">Search</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='dashboard.php'">Cancel</button>
                            <button type="submit" name="inputSave" class="btn btn-info pull-right">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<?php include("include/footer.php"); ?>
