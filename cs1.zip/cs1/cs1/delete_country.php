<?php
session_start();
include('config/connection.php');

// Check if the session is active
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Check if the country_id is provided via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['country_id'])) {
    $country_id = $_POST['country_id'];

    // Ensure country_id is an integer
    if (!filter_var($country_id, FILTER_VALIDATE_INT)) {
        die("Invalid country ID.");
    }

    // Check if the record exists
    $checkQuery = $connect->prepare("SELECT country_id FROM tbl_country_master WHERE country_id = :country_id");
    $checkQuery->bindParam(':country_id', $country_id, PDO::PARAM_INT);
    $checkQuery->execute();

    if ($checkQuery->rowCount() === 0) {
        die("Error: Record not found.");
    }

    // Delete the record
    $deleteQuery = $connect->prepare("DELETE FROM tbl_country_master WHERE country_id = :country_id");
    $deleteQuery->bindParam(':country_id', $country_id, PDO::PARAM_INT);

    if ($deleteQuery->execute()) {
        // Redirect back with success message
        header('Location: srh_country_master.php');
        exit();
    } else {
        die("Error: Unable to delete the record.");
    }
} else {
    die("Invalid request.");
}
?>
