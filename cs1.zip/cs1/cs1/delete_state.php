<?php
session_start();
include('config/connection.php');

// Redirect if session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Check if the 'state_id' is provided via POST
if (isset($_POST['state_id']) && is_numeric($_POST['state_id'])) {
    $stateId = $_POST['state_id'];

    // Start a transaction to ensure data integrity
    try {
        // Prepare the delete query
        $sql = "DELETE FROM tbl_state_master WHERE state_id = :state_id";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':state_id', $stateId, PDO::PARAM_INT);

        // Execute the delete query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'State deleted successfully';
        } else {
            $_SESSION['message'] = 'Failed to delete the state';
        }
    } catch (PDOException $e) {
        // Handle the error
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
    }

    // Redirect to the state master page with a message
    header('Location: srh_state_master.php');
    exit();
} else {
    $_SESSION['message'] = 'Invalid state ID';
    header('Location: srh_state_master.php');
    exit();
}
?>
