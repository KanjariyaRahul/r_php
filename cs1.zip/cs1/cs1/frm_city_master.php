<?php
session_start();
$page = "city";

// Include the database connection
include('config/connection.php');

// Redirect if the session is not set
if (!isset($_SESSION['ad_session'])) {
    header('Location: index.php');
    exit();
}

// Default values for a new record

$cityId = isset($_POST['city_id']) ? $_POST['city_id'] : ''; // Check for cityId in the URL

$city = [
    'state_id' => '',
    'city_name' => '',
    'created_date' => '',
    'created_by' => '',
    'modified_date' => '',
    'modified_by' => '',
    'country_name' => '' // Ensure we also handle country_name
];

// Fetch states and country mapping
try {
    $stmtStates = $connect->prepare("SELECT sm.state_id, sm.state_name, sm.country_id, cm.country_name 
                                    FROM tbl_state_master sm
                                    LEFT JOIN tbl_country_master cm ON sm.country_id = cm.country_id
                                    ORDER BY sm.state_name ASC");
    $stmtStates->execute();
    $states = $stmtStates->fetchAll(PDO::FETCH_ASSOC);

    // Create country mapping
    $countryMapping = [];
    foreach ($states as $state) {
        $countryMapping[$state['state_id']] = $state['country_id'];
        $countryMapping[$state['country_id']] = $state['country_name']; // Mapping state to its country_name
    }
} catch (PDOException $e) {
    echo "Error loading states: " . $e->getMessage();
}

// Fetch the city record if editing
if ($cityId) {
    $stmtCity = $connect->prepare("SELECT * FROM tbl_city_master WHERE city_id = :city_id");
    $stmtCity->bindParam(':city_id', $cityId, PDO::PARAM_INT);
    $stmtCity->execute();
    $city = $stmtCity->fetch(PDO::FETCH_ASSOC);

    if (!$city) {
        $_SESSION['message'] = 'City not found';
        header("Location: srh_{$page}_master.php");
        exit();
    }
}

// Save logic (Insert or Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputSave'])) {
    $stateId = trim($_POST['inputStateName'] ?? '');
    $cityName = trim($_POST['inputCityName'] ?? '');
    $countryId = trim($_POST['country_id'] ?? 0);
    $createdBy = $_SESSION['ad_session'];
    $modifiedBy = $_SESSION['ad_session'];

    // Basic validation
    if (empty($stateId) || empty($cityName)) {
        $_SESSION['message'] = 'State and City are required';
        header("Location: frm_{$page}_master.php");
        exit();
    }

    try {
        if ($cityId) {
            // Update existing city
            $sql = "UPDATE tbl_city_master SET state_id = :state_id, city_name = :city_name, country_id = :country_id, modified_date = NOW(), modified_by = :modified_by WHERE city_id = :city_id";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':city_id', $cityId, PDO::PARAM_INT);
        } else {
            // Insert new city
            $sql = "INSERT INTO tbl_city_master (state_id, city_name,country_id, created_date, created_by, modified_date, modified_by) 
                    VALUES (:state_id, :city_name, :country_id,NOW(), :created_by, NOW(), :modified_by)";
            $stmt = $connect->prepare($sql);
            $stmt->bindParam(':created_by', $createdBy, PDO::PARAM_STR);
            $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);
        }

        // Bind parameters
        $stmt->bindParam(':state_id', $stateId, PDO::PARAM_INT);
        $stmt->bindParam(':city_name', $cityName, PDO::PARAM_STR);
        $stmt->bindParam(':country_id', $countryId);
        $stmt->bindParam(':modified_by', $modifiedBy, PDO::PARAM_STR);

        // Execute query
        if ($stmt->execute()) {
            $_SESSION['message'] = 'City saved successfully';
            header("Location: srh_{$page}_master.php");
            exit();
        } else {
            $_SESSION['message'] = 'Failed to save data';
            header("Location: frm_{$page}_master.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error: ' . $e->getMessage();
        header("Location: frm_{$page}_master.php");
        exit();
    }
}
?>
<?php include("include/header.php"); ?>


<?php include("include/body_open.php"); ?>

<div class="wrapper">
    <?php include("include/navigation.php"); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1><?php echo $cityId ? 'Edit City' : 'Add City'; ?></h1>
        </section>

        <section class="content">
            <div class="col-md-6" style="padding:0;">
                <div class="box box-info">
                    <form class="form-horizontal" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="inputCityName" class="col-sm-4 control-label">City*</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCityName" name="inputCityName" 
                                           placeholder="Enter City" value="<?php echo htmlspecialchars($city['city_name']); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputStateName" class="col-sm-4 control-label">State*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="inputStateName" name="inputStateName" required>
                                        <option value="">Select State</option>
                                        <?php foreach ($states as $state): ?>
                                            <option value="<?= htmlspecialchars($state['state_id']); ?>" 
                                                    <?php echo $state['state_id'] == $city['state_id'] ? 'selected' : ''; ?>
                                                    data-country-name="<?php echo htmlspecialchars($state['country_name']); ?>">
                                                <?= htmlspecialchars($state['state_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputCountryName" class="col-sm-4 control-label">Country</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="inputCountryName" name="inputCountryName" value="<?php echo isset($city['country_name']) ? htmlspecialchars($city['country_name']) : ''; ?>" readonly>
                                    <input type="hidden" value="0" name="country_id" id="country_id" />
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="hidden" value="<?php echo $cityId; ?>" name="city_id" />
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onclick="location.href='srh_<?= $page ?>_master.php'">Cancel</button>
                            <button type="submit" class="btn btn-info pull-right" name="inputSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>

<script>
    const countryMapping = <?= json_encode($countryMapping); ?>;

    // Populate country field when state changes
    document.getElementById('inputStateName').addEventListener('change', function () {
        const selectedState = this.value;
        const countryField = document.getElementById('inputCountryName');

        // Auto-fill the country
        const countryId = countryMapping[selectedState];
        const countryName=countryMapping[countryId];
        if (countryName) {
            countryField.value = countryName;
            document.getElementById("country_id").value=countryId;
        } else {
            countryField.value = '';
        }
    });

    // When the page loads, set the country if already selected
    /*window.addEventListener('DOMContentLoaded', function() {
        const stateId = document.getElementById('inputStateName').value;
        const countryField = document.getElementById('inputCountryName');

        // Populate country field if a state is already selected on page load
        if (stateId) {
            const countryName = countryMapping[stateId];
            if (countryName) {
                countryField.value = countryName;
            }
        }
    });*/
</script>

<?php include('include/footer.php'); ?>
