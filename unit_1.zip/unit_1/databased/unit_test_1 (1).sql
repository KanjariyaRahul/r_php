-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2025 at 07:48 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unit_test_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `theme` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `username`, `password`, `theme`) VALUES
(1, 'rahul', 'rahul@gmail.com', 'rahul', 'rahul', 1),
(2, 'admin', 'admin@gmail.com', 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `due_date` date NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 2,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `total_time` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `user_id`, `created_by`, `assigned_by`, `title`, `description`, `due_date`, `attachment`, `time_limit`, `priority`, `created_at`, `updated_at`, `status`, `start_time`, `stop_time`, `total_time`) VALUES
(78, 1001, 1001, 0, 'testing', 'nothing', '2025-02-28', '67b5d7174d395.jpg', 14400, 2, '2025-02-19 09:04:22', '2025-02-19 09:04:22', 1, NULL, NULL, 0),
(89, 1002, 0, 2, 'testing', 'this are testing', '2025-02-21', NULL, 14400, 2, '2025-02-19 12:37:48', '2025-02-19 12:37:48', 2, '2025-02-26 11:58:44', NULL, 72643),
(92, 1002, 0, 2, 'sfsf', 'sfs', '2025-02-21', NULL, 12000, 2, '2025-02-20 11:52:45', '2025-02-20 11:52:45', 4, '2025-02-26 11:18:18', '2025-02-26 11:18:28', 145220),
(95, 1001, 0, 1, 'testing task', 'this task are testing task', '2025-02-28', NULL, 50400, 3, '2025-02-21 11:07:11', '2025-02-21 11:07:11', 1, NULL, NULL, 0),
(96, 1001, 0, 1, 'cscs', 'cscsc', '2025-02-28', NULL, 18000, 1, '2025-02-24 11:58:22', '2025-02-24 11:58:22', 1, NULL, NULL, 0),
(99, 1001, 0, 2, 'dff', 'sfsf', '2025-02-04', NULL, 13380, 2, '2025-02-24 12:44:11', '2025-02-24 12:44:11', 4, '2025-02-24 18:33:22', '2025-02-24 18:33:24', 60),
(100, 1001, 0, 2, 'ada', 'adad', '2025-02-12', NULL, 3180, 3, '2025-02-24 12:48:51', '2025-02-24 12:48:51', 1, NULL, NULL, 0),
(104, 1002, 1002, 0, 'raj update', 'ffs', '2025-02-28', NULL, 14400, 2, '2025-02-25 04:45:29', '2025-02-25 04:45:29', 4, '2025-02-26 11:29:35', '2025-02-26 11:29:37', 72396),
(105, 1002, 1002, 0, 'my task in raj', 'sfsf', '2025-02-28', NULL, 21600, 1, '2025-02-25 11:35:07', '2025-02-25 11:35:07', 2, '2025-02-26 11:59:17', NULL, 63209),
(114, 1002, 0, 1, 'sfs', 'sfsf', '2025-02-28', NULL, 21600, 2, '2025-02-26 04:38:40', '2025-02-26 04:38:40', 1, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `theme` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `gender`, `username`, `password`, `theme`) VALUES
(1001, 'jay', 'jay@gmail.com', 2147483647, 'male', 'jay', '$2y$10$uziBV27mV.I8qGDtyR5HUuS4q/JJ/x7q9oonEHAYHc.5lv5b3N4qG', 1),
(1002, 'raj singh', 'kabir@gamil.com', 2147483647, 'male', 'raj', '$2y$10$hSQFJKK9yjEC1/DPmkqCqu/EytX5WG082yzy/anL7iBm0PfGovtQ.', 1),
(1003, 'singh singh', 'kabir@gamil.com', 2147483647, 'male', 'rahul', '$2y$10$fvLOHk4NApxaInmUVSZcguOQH1LoTdvrbGmZqfNqiygLHClZFAFKq', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5965;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
