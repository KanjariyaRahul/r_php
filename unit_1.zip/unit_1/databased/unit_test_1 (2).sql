-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 06, 2025 at 01:50 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unit_test_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `theme` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `username`, `password`, `theme`) VALUES
(1, 'rahul', 'rahul@gmail.com', 'rahul', 'rahul', 1),
(2, 'admin', 'admin@gmail.com', 'admin', 'adminconnect', 1);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `due_date` date NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 2,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `total_time` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `user_id`, `created_by`, `assigned_by`, `title`, `description`, `due_date`, `attachment`, `time_limit`, `priority`, `created_at`, `updated_at`, `status`, `start_time`, `stop_time`, `total_time`) VALUES
(78, 1001, 1001, 2, 'testing', 'nothing', '2025-03-07', '67b5d7174d395.jpg', 14400, 1, '2025-02-19 09:04:22', '2025-02-19 09:04:22', 1, NULL, NULL, 0),
(89, 1002, 0, 2, 'testing', 'this are testing', '2025-02-21', NULL, 14400, 2, '2025-02-19 12:37:48', '2025-02-19 12:37:48', 3, '2025-03-03 10:56:34', '2025-03-04 17:37:54', 120480),
(92, 1002, 0, 2, 'test 1', 'sfs', '2025-02-21', NULL, 12000, 2, '2025-02-20 11:52:45', '2025-02-20 11:52:45', 3, '2025-02-28 10:06:20', '2025-02-28 10:06:57', 145280),
(95, 1001, 0, 1, 'testing task', 'this task are testing task', '2025-02-28', NULL, 50400, 3, '2025-02-21 11:07:11', '2025-02-21 11:07:11', 1, NULL, NULL, 0),
(96, 1001, 0, 1, 'cscs', 'cscsc', '2025-02-28', NULL, 18000, 1, '2025-02-24 11:58:22', '2025-02-24 11:58:22', 1, NULL, NULL, 0),
(99, 1001, 0, 2, 'dff', 'sfsf', '2025-02-04', NULL, 13380, 2, '2025-02-24 12:44:11', '2025-02-24 12:44:11', 1, '2025-02-24 18:33:22', '2025-02-24 18:33:24', 60),
(104, 1002, 1002, 0, 'raj  update', 'ffs update', '2025-03-06', NULL, 14400, 3, '2025-02-25 04:45:29', '2025-02-25 04:45:29', 3, '2025-03-06 15:55:02', '2025-03-06 15:55:04', 356057),
(114, 1002, 0, 1, 'sfs', 'sfsf', '2025-02-28', NULL, 21600, 2, '2025-02-26 04:38:40', '2025-02-26 04:38:40', 4, '2025-03-03 10:56:26', '2025-03-03 10:56:26', 202505),
(118, 1002, 0, 2, 'asdfasdf', 'asdfasdf', '0002-02-12', NULL, 0, 2, '2025-02-26 07:11:18', '2025-02-26 07:11:18', 3, '2025-02-27 17:54:38', '2025-02-27 17:54:49', 120),
(119, 1004, 0, 2, 'test 1', 'test 1', '2025-02-27', NULL, 0, 3, '2025-02-26 07:20:41', '2025-02-26 07:20:41', 1, NULL, NULL, 0),
(120, 1004, 0, 2, 'test 2', 'test 2', '2025-02-28', NULL, 0, 2, '2025-02-26 07:20:59', '2025-02-26 07:20:59', 4, '2025-03-03 12:08:08', '2025-03-03 12:08:10', 120),
(121, 1004, 0, 2, 'test 3', 'test 3', '2025-03-01', NULL, 0, 3, '2025-02-26 07:21:17', '2025-02-26 07:21:17', 4, '2025-03-03 12:06:35', '2025-03-03 12:06:36', 540),
(125, 1003, 1003, 2, '28-02-2025 testing', 'testing task', '2025-03-21', NULL, 82800, 3, '2025-02-28 05:29:19', '2025-02-28 05:29:19', 1, NULL, NULL, 0),
(129, 1002, 0, 2, 'fdf', 'ff', '2025-03-16', NULL, 0, 2, '2025-03-01 10:09:23', '2025-03-01 10:09:23', 4, '2025-03-03 10:54:46', '2025-03-03 10:54:47', 660),
(130, 1002, 0, 2, 'fdf', 'ff', '2025-03-16', NULL, 0, 2, '2025-03-01 10:10:03', '2025-03-01 10:10:03', 2, '2025-03-04 17:38:38', NULL, 120),
(132, 1002, 0, 2, 'sfsf', 'sfs', '2025-03-29', NULL, 0, 2, '2025-03-01 10:12:30', '2025-03-01 10:12:30', 4, '2025-03-03 10:54:46', '2025-03-03 10:54:47', 1320),
(134, 1003, 0, 2, 'test', 'xgfxg', '2025-03-13', NULL, 0, 2, '2025-03-01 10:13:45', '2025-03-01 10:13:45', 1, NULL, NULL, 0),
(145, 1002, 0, 2, '03-03-25 task', 'ADFF', '2025-03-13', NULL, 180, 2, '2025-03-03 13:00:28', '2025-03-03 13:00:28', 3, '2025-03-04 17:36:16', '2025-03-04 17:37:54', 790),
(146, 1004, 0, 2, 'sfsfsf', 'chang', '2025-03-16', NULL, 240, 2, '2025-03-03 13:01:15', '2025-03-03 13:01:15', 1, NULL, NULL, 0),
(151, 1002, 1002, 0, '05-03-25', 'testing task', '2025-03-07', NULL, 18000, 1, '2025-03-05 13:20:44', '2025-03-05 13:20:44', 1, NULL, NULL, 0),
(152, 1002, 1002, 0, 'TESTING ', 'fsfnsfnmsdbdm,.f. ,mfr.w,fm a.w,mfr;l\'Z:l\';l\';l\r\n\r\ns,sfsflw;l2\';@$@$#@%@#% .//\'[P]P[;.]/././././\r\n\r\nKLFJKKE TWT T/./>D/.G/D.G/D \'G\"\":\":\">?>>?#r?f?>?$>?> ?V/.ZDG\r\n\r\nthanks', '2025-03-15', NULL, 18000, 3, '2025-03-06 10:16:32', '2025-03-06 10:16:32', 1, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `gender` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `theme` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `gender`, `username`, `password`, `theme`) VALUES
(1001, 'jay', 'jay@gmail.com', 2147483647, 1, 'jay', '$2y$10$uziBV27mV.I8qGDtyR5HUuS4q/JJ/x7q9oonEHAYHc.5lv5b3N4qG', 1),
(1002, 'raj singh', 'kabir@gamil.com', 2147483647, 1, 'raj', '$2y$10$hSQFJKK9yjEC1/DPmkqCqu/EytX5WG082yzy/anL7iBm0PfGovtQ.', 1),
(1003, 'singh singh', 'kabir@gamil.com', 2147483647, 1, 'rahul', '$2y$10$fvLOHk4NApxaInmUVSZcguOQH1LoTdvrbGmZqfNqiygLHClZFAFKq', 1),
(1004, 'Repute info', 'testrepute123@gmail.com', 2147483647, 1, 'reputeinfo', '$2y$10$QNo0uWkoS90ZQdp96y2KWe1Ff1kXgvHEAb5NEO5Lbq/u5JGVlxOse', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5968;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
