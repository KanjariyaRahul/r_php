<?php
include 'includes/session.php';
include 'config/connect.php';
include 'config/function_config.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include_once "./root/function.php";
$error_message = '';
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

$tasksPerPage = 10;
$pageAssignedByAdmin = isset($_GET['page_assigned_by_admin']) ? (int) $_GET['page_assigned_by_admin'] : 1;
$pageCreatedByUser = isset($_GET['page_created_by_user']) ? (int) $_GET['page_created_by_user'] : 1;
$statusFilter = isset($_GET['status_filter']) ? (int) $_GET['status_filter'] : 0;

$limit = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$startAssignedByAdmin = ($pageAssignedByAdmin - 1) * $tasksPerPage;
$startCreatedByUser = ($pageCreatedByUser - 1) * $tasksPerPage;

$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$searchCondition = $searchQuery ? "AND (task.title LIKE :search OR admin.name LIKE :search)" : '';
$statusCondition = $statusFilter ? "AND task.status = :status" : '';

$queryAssignedByAdmin = "SELECT task.*, admin.name AS assigned_by_name
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = :user_id 
    AND admin.id > 0  
    $searchCondition
    $statusCondition
    ORDER BY task.due_date DESC
    LIMIT :limit OFFSET :offset";
    
$stmtAssignedByAdmin = $conn->prepare($queryAssignedByAdmin);
$stmtAssignedByAdmin->bindParam(':user_id', $user_id, PDO::PARAM_INT);
if ($searchQuery) {
    $stmtAssignedByAdmin->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
}
if ($statusFilter) {
    $stmtAssignedByAdmin->bindParam(':status', $statusFilter, PDO::PARAM_INT);
}
$stmtAssignedByAdmin->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmtAssignedByAdmin->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmtAssignedByAdmin->execute();
$resultAssignedByAdmin = $stmtAssignedByAdmin->fetchAll(PDO::FETCH_ASSOC);

$TasksAssignedByAdmin = "SELECT COUNT(*) AS total
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = :user_id 
    AND admin.id > 0 
    $searchCondition
    $statusCondition";
$stmtTasksAssignedByAdmin = $conn->prepare($TasksAssignedByAdmin);
$stmtTasksAssignedByAdmin->bindParam(':user_id', $user_id, PDO::PARAM_INT);

if ($searchQuery) {
    $stmtTasksAssignedByAdmin->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
}
if ($statusFilter) {
    $stmtTasksAssignedByAdmin->bindParam(':status', $statusFilter, PDO::PARAM_INT);
}

$stmtTasksAssignedByAdmin->execute();
$rowAssignedByAdmin = $stmtTasksAssignedByAdmin->fetch(PDO::FETCH_ASSOC);
$AssignedByAdmin = $rowAssignedByAdmin['total'];
$PagesAssignedByAdmin = ceil($AssignedByAdmin / $tasksPerPage);

$queryCreatedByUser = "SELECT COUNT(*) AS total FROM task WHERE created_by = :user_id AND title LIKE :search $statusCondition";
$stmtCreatedByUser = $conn->prepare($queryCreatedByUser);
$stmtCreatedByUser->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmtCreatedByUser->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
if ($statusFilter) {
    $stmtCreatedByUser->bindParam(':status', $statusFilter, PDO::PARAM_INT);
}
$stmtCreatedByUser->execute();
$rowCreatedByUser = $stmtCreatedByUser->fetch(PDO::FETCH_ASSOC);
$TasksCreatedByUser = $rowCreatedByUser['total'];
$PagesCreatedByUser = ceil($TasksCreatedByUser / $tasksPerPage);

$queryCreatedByUser = "SELECT * FROM task WHERE created_by = :user_id AND title LIKE :search $statusCondition LIMIT :start, :limit";
$stmtCreatedByUser = $conn->prepare($queryCreatedByUser);
$stmtCreatedByUser->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmtCreatedByUser->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
if ($statusFilter) {
    $stmtCreatedByUser->bindParam(':status', $statusFilter, PDO::PARAM_INT);
}
$stmtCreatedByUser->bindParam(':start', $startCreatedByUser, PDO::PARAM_INT);
$stmtCreatedByUser->bindParam(':limit', $tasksPerPage, PDO::PARAM_INT);
$stmtCreatedByUser->execute();
$tasksCreatedByUser = $stmtCreatedByUser->fetchAll(PDO::FETCH_ASSOC);

function getPriorityText($priority)
{
    switch ($priority) {
        case 1:
            return 'Low';
        case 2:
            return 'Medium';
        case 3:
            return 'High';
        default:
            return 'Unknown';
    }
}

function getStatusText($status)
{
    switch ($status) {
        case 1:
            return 'Padding';
        case 2:
            return 'In Progress';
        case 3:
            return 'Paused';
        case 4:
            return 'Completed';
        default:
            return 'Unknown';
    }
}

function getProgressPercentage($totalTime, $timeLimit)
{
    if ($timeLimit == 0)
        return 100;
    return min(($totalTime / $timeLimit) * 100, 100);
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id']) && isset($_POST['nonce_token'])) {
    $task_id = (int) $_POST['delete_id'];
    $nonce_token = $_POST['nonce_token'];

    if (verify_nonce_token($nonce_token)) {
       
        $delete_query = "DELETE FROM task WHERE id = :task_id AND user_id = :user_id";
        $stmtDelete = $conn->prepare($delete_query);
        $stmtDelete->bindParam(':task_id', $task_id, PDO::PARAM_INT);
        $stmtDelete->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmtDelete->execute();
        $message = 'Task deleted successfully!';
    } else {
        $error_message = 'Invalid request. Please try again.';
    }
} else {
    $nonce_token = generate_nonce_token();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Task List</title>
    <script src="./assets/js/script.js"></script>
</head>
<body>
    <div class="main-content">
        <h3>User Task List</h3>

        <div class="search-container">
            <form action="" method="GET">
                <input type="text" id="search_bar" name="search" placeholder="Search tasks..."
                    value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" class="btn-search ">Search</button>
                <div class="status-filter">
                    <select name="status_filter" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="1" <?php echo $statusFilter == 1 ? 'selected' : ''; ?>>Padding</option>
                        <option value="2" <?php echo $statusFilter == 2 ? 'selected' : ''; ?>>In Progress</option>
                        <option value="3" <?php echo $statusFilter == 3 ? 'selected' : ''; ?>>Paused</option>
                        <option value="4" <?php echo $statusFilter == 4 ? 'selected' : ''; ?>>Completed</option>
                    </select>
                </div>
            </form>
            <a href="add_task.php" class="add-task-button"> + Add Task</a>
        </div>
        <?php if ($error_message): ?>
            <div class="message error">
                <?php echo $error_message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <h3>Tasks Assigned By Admin</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Priority</th>
                    <th>Title</th>
                    <th>Due Date</th>
                    <th>Assigned By</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($resultAssignedByAdmin) > 0): ?>
                    <?php foreach ($resultAssignedByAdmin as $task): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($task['id']); ?></td>
                            <td><?php echo getPriorityText($task['priority']); ?></td>
                            <td><?php echo htmlspecialchars($task['title']); ?></td>
                            <td><?php echo htmlspecialchars($task['due_date']); ?></td>
                            <td><?php echo htmlspecialchars($task['assigned_by_name']); ?></td>
                            <td>
                                <div class="status-<?php
                                    $status = $task['status'];
                                    if ($status == 1)
                                        echo 'padding';
                                    elseif ($status == 2)
                                        echo 'in-progress';
                                    elseif ($status == 3)
                                        echo 'paused';
                                    elseif ($status == 4)
                                        echo 'completed';
                                ?>">
                                    <?php echo getStatusText($task['status']); ?>
                                </div>
                                <?php if ($task['status'] == 2): ?>
                                    <div class="progress-bar">
                                        <div class="progress"
                                            style="width: <?php echo getProgressPercentage($task['total_time'], $task['time_limit']); ?>%;">
                                        </div>
                                    </div>
                                    <small><?php echo number_format(getProgressPercentage($task['total_time'], $task['time_limit']), 2); ?>%</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="javascript:void(0);" class="view-task-details viewTask icon-link view-icon fas fa-eye"
                                    data-task-id="<?php echo $task['id']; ?>">
                                    <span class="tooltip">View</span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No tasks found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if ($PagesAssignedByAdmin > 1): ?>
        <div class="pagination">
            <span class="prev-btn">
                <a href="?page=<?php echo max(1, $page - 1); ?>" <?php echo $page == 1 ? 'class="disabled"' : ''; ?>>&laquo; Previous</a>
            </span>
            <?php for ($i = 1; $i <= $PagesAssignedByAdmin; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchQuery); ?>&status_filter=<?php echo $statusFilter; ?>"
                    class="<?php echo $i == $page ? 'current' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
            <span class="next-btn">
                <a href="?page=<?php echo min($PagesAssignedByAdmin, $page + 1); ?>" <?php echo $page == $PagesAssignedByAdmin ? 'class="disabled"' : ''; ?>>Next &raquo;</a>
            </span>
        </div>
        <?php endif; ?>

        <h3>Tasks Created By You</h3>
        
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Priority</th>
            <th>Title</th>
            <th>Description</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($tasksCreatedByUser) > 0): ?>
            <?php foreach ($tasksCreatedByUser as $task): ?>
                <tr>
                    <td><?php echo htmlspecialchars($task['id']); ?></td>
                    <td><?php echo getPriorityText($task['priority']); ?></td>
                    <td><?php echo htmlspecialchars($task['title']); ?></td>
                    <td>
                        <?php echo strlen($task['description']) > 50 ? htmlspecialchars(substr($task['description'], 0, 50)) . '... <a href="#" class="viewTask icon-link" data-task-id="' . $task['id'] . '">more</a>' : htmlspecialchars($task['description']); ?>
                    </td>
                    <td><?php echo htmlspecialchars($task['due_date']); ?></td>
                    <td>
                        <div class="status-<?php
                            $status = $task['status'];
                            if ($status == 1)
                                echo 'padding';
                            elseif ($status == 2)
                                echo 'in-progress';
                            elseif ($status == 3)
                                echo 'paused';
                            elseif ($status == 4)
                                echo 'completed';
                        ?>">
                            <?php echo getStatusText($task['status']); ?>
                        </div>
                        <?php if ($task['status'] == 2): ?>
                            <div class="progress-bar">
                                <div class="progress"
                                    style="width: <?php echo getProgressPercentage($task['total_time'], $task['time_limit']); ?>%;">
                                </div>
                            </div>
                            <small><?php echo number_format(getProgressPercentage($task['total_time'], $task['time_limit']), 2); ?>%</small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="add_task.php?id=<?php echo urlencode((int) $task['id']); ?>" class="icon-link edit-icon">
                            <i class="fas fa-pencil-alt"></i>
                            <span class="tooltip">Edit</span>
                        </a>
                        <form action="task_manage.php" method="POST" class="delete-buton">
                            <input type="hidden" name="delete_id" value="<?php echo $task['id']; ?>">
                            <input type="hidden" name="nonce_token" value="<?php echo $nonce_token; ?>">
                            <button type="submit" class="icon-link delete-icon delete-buton " onclick="return confirm('Are you sure you want to delete this task?')">
                                <i class="fas fa-trash-alt"></i>
                                <span class="tooltip">Delete</span>
                            </button>
                        </form>
                        <a href="javascript:void(0);" class="view-task-details viewTask icon-link view-icon fas fa-eye"
                            data-task-id="<?php echo $task['id']; ?>">
                            <span class="tooltip">View</span>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">No tasks found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


        <?php if ($PagesCreatedByUser > 1): ?>
        <div class="pagination">
            <span class="prev-btn">
                <a href="?page=<?php echo max(1, $page - 1); ?>" <?php echo $page == 1 ? 'class="disabled"' : ''; ?>>&laquo; Previous</a>
            </span>
            <?php for ($i = 1; $i <= $PagesCreatedByUser; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchQuery); ?>&status_filter=<?php echo $statusFilter; ?>"
                    class="<?php echo $i == $page ? 'current' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
            <span class="next-btn">
                <a href="?page=<?php echo min($PagesCreatedByUser, $page + 1); ?>" <?php echo $page == $PagesCreatedByUser ? 'class="disabled"' : ''; ?>>Next &raquo;</a>
            </span>
        </div>
        <?php endif; ?>
    </div>
    <div id="taskDetailsModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" id="closeModal">&times;</span>
            <h3>Task Details</h3>
            <div id="taskDetails"></div>
            <button id="startButton" class="taskButton">Start</button>
            <button id="stopButton" class="taskButton">Stop</button>
            <button id="resumeButton" class="taskButton">Resume</button>
            <button id="completeButton" class="taskButton">Complete</button>
        </div>
    </div>
</body>
</html>

