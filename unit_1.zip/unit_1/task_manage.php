<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'config/connect.php';
include 'includes/header.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

$tasksPerPage = 10;
$pageAssignedByAdmin = isset($_GET['page_assigned_by_admin']) ? (int) $_GET['page_assigned_by_admin'] : 1;
$pageCreatedByUser = isset($_GET['page_created_by_user']) ? (int) $_GET['page_created_by_user'] : 1;
$statusFilter = isset($_GET['status_filter']) ? (int) $_GET['status_filter'] : 0;

$limit = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$startAssignedByAdmin = ($pageAssignedByAdmin - 1) * $tasksPerPage;
$startCreatedByUser = ($pageCreatedByUser - 1) * $tasksPerPage;

$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$searchCondition = $searchQuery ? "AND (task.title LIKE ? OR admin.name LIKE ?)" : '';
$statusCondition = $statusFilter ? "AND task.status = ?" : '';

$queryAssignedByAdmin = "SELECT task.*, admin.name AS assigned_by_name
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = ? 
    AND admin.id > 0  
    $searchCondition
    $statusCondition
    ORDER BY task.due_date DESC
    LIMIT ? OFFSET ?";
$paramsAssignedByAdmin = array_merge(
    [$user_id], 
    $searchQuery ? ["%$searchQuery%", "%$searchQuery%"] : [],
    $statusFilter ? [$statusFilter] : [],
    [$limit, $offset]
);
$resultAssignedByAdmin = safe_query($queryAssignedByAdmin, str_repeat('s', count($paramsAssignedByAdmin)), $paramsAssignedByAdmin);

if (!$resultAssignedByAdmin) {
    die('Query Failed: ');
}

$TasksAssignedByAdmin = "SELECT COUNT(*) AS total
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = ? 
    AND admin.id > 0 
    $searchCondition
    $statusCondition";
$paramsAssignedByAdmin = array_merge(
    [$user_id], 
    $searchQuery ? ["%$searchQuery%", "%$searchQuery%"] : [],
    $statusFilter ? [$statusFilter] : []
);
$tasksAdminCount = safe_query($TasksAssignedByAdmin, str_repeat('s', count($paramsAssignedByAdmin)), $paramsAssignedByAdmin);
$rowAssignedByAdmin = $tasksAdminCount[0];
$AssignedByAdmin = $rowAssignedByAdmin['total'];
$PagesAssignedByAdmin = ceil($AssignedByAdmin / $tasksPerPage);

$queryCreatedByUser = "SELECT COUNT(*) AS total FROM task WHERE created_by = ? AND title LIKE ? $statusCondition";
$resultCreatedByUser = safe_query($queryCreatedByUser, 'ss', [$user_id, "%$searchQuery%"]);
if (!$resultCreatedByUser) {
    die('Query Failed: ');
}
$rowCreatedByUser = $resultCreatedByUser[0];
$TasksCreatedByUser = $rowCreatedByUser['total'];
$PagesCreatedByUser = ceil($TasksCreatedByUser / $tasksPerPage);

$queryCreatedByUser = "SELECT * FROM task WHERE created_by = ? AND title LIKE ? $statusCondition LIMIT ?, ?";
$tasksCreatedByUser = safe_query($queryCreatedByUser, 'ssii', [$user_id, "%$searchQuery%", $startCreatedByUser, $tasksPerPage]);
if (!$tasksCreatedByUser) {
    die('Query Failed: ');
}

function getPriorityText($priority)
{
    switch ($priority) {
        case 1:
            return 'Low';
        case 2:
            return 'Medium';
        case 3:
            return 'High';
        default:
            return 'Unknown';
    }
}

function getStatusText($status)
{
    switch ($status) {
        case 1:
            return 'Padding';
        case 2:
            return 'In Progress';
        case 3:
            return 'Paused';
        case 4:
            return 'Completed';
        default:
            return 'Unknown';
    }
}

function getProgressPercentage($totalTime, $timeLimit)
{
    if ($timeLimit == 0)
        return 100;
    return min(($totalTime / $timeLimit) * 100, 100);
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

if (isset($_GET['delete_id'])) {
    $task_id = (int) $_GET['delete_id'];
    $delete_query = "DELETE FROM task WHERE id = ? AND user_id = ?";
    $result = safe_query($delete_query, 'ii', [$task_id, $user_id]);
    $message = 'Task deleted successfully!';
    header('Location: task_manage.php?msg=3');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Task List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        body.dark {
            background-color: rgb(43, 43, 43);
            color: rgb(250, 250, 250);
        }

        body.dark table td {
            color: #f7f7f7;
        }

        .main-content {
            margin-left: 235px;
            padding: 40px;
            margin-top: 40px;
            flex-grow: 1;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
        }

        .success {
            background-color: rgb(100, 185, 103);
            color: white;
        }

        .error-message {
            background-color: rgb(247, 33, 33);
            color: white;
        }

        .search-container {
            display: flex;
            justify-content: space-between;

            flex-wrap: wrap;
        }

        .search-container form {
            display: flex;
            align-items: center;
            width: 100%;
            max-width: 800px;
        }

        #search_bar {
            flex-grow: 1;
            padding: 12px 20px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 12px 20px;
            background-color: #7380ec;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3sease;
        }

        button:hover {
            background-color: #7380ec;
        }

        .status-filter select {
            padding: 10px;
            margin-left: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .add-task-button {
            padding: 10px 20px;
            background-color: #7380ec;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }


        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th,
        table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #7380ec;
            color: white;
        }

        .actions a {
            text-decoration: none;
            color: #0275d8;
            padding: 5px 10px;
        }

        .actions a:hover {
            background-color: #f1f1f1;
            border-radius: 5px;
        }

        .pagination {
            text-align: right;
            margin-top: 20px;
        }

        .google-pagination a,
        .google-pagination span {
            padding: 8px 15px;
            color: #7380ec;
            font-size: 14px;
            border-radius: 5px;
            text-decoration: none;
        }

        .google-pagination a:hover {
            text-decoration: underline;
        }

        .google-pagination .current {
            color: #000;
            font-weight: bold;
            background-color: #f1f1f1;
        }

        .no-data {
            text-align: center;
            color: #999;
            font-style: italic;
        }

        .progress-bar {
            width: 100%;
            background-color: #f3f3f3;
            border-radius: 5px;
            margin-top: 5px;
        }

        .progress {
            height: 15px;
            border-radius: 5px;
            background-color: rgb(255, 217, 92);
        }

        .pagination {
            text-align: right;
            margin-top: 20px;
        }

        .google-pagination a,
        .google-pagination span {
            padding: 8px 15px;
            color: #4285f4;
            font-size: 14px;
            border-radius: 5px;
            text-decoration: none;
        }

        .google-pagination a:hover {
            text-decoration: underline;
        }

        .google-pagination .current {
            color: #000;
            font-weight: bold;
            background-color: #f1f1f1;
        }

        .google-pagination .disabled {
            color: #ccc;
            pointer-events: none;
        }

        .taskButton {
            margin: 5px;
            padding: 10px;
            cursor: pointer;
        }



        .taskButton {
            background-color: #7380ec;
            width: 100px;
            height: 40px;
            font-size: 16px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }


        #startButton:disabled,
        #stopButton:disabled,
        #resumeButton:disabled,
        #completeButton:disabled {
            background-color: #D3D3D3;
            color: #000;
            cursor: not-allowed;
        }

        .modal {
            display: none;
            position: fixed;
            width: 100%;
            /* margin-left: 100px; */
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            box-shadow: 0px 10px 5px #fff;

            box-shadow: #000;
            justify-content: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            width: 60%;
            color: #000;
            max-height: 80%;
            overflow-y: auto;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        body.dark .modal-content {
            box-shadow: 0px 10px 5px #000;
            background-color: rgb(35, 35, 35);
            color: rgb(250, 250, 250);
        }

        .modal-close {
            margin-left: 96%;
            top: 10px;
            right: 10px;
            background: #ff4d4d;
            color: white;
            padding: 10px;
            border-radius: 10%;
            cursor: pointer;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            transition: transform 0.3s ease;
            flex-direction: row;
            background-color: #dfdfdf;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card h3 {
            font-size: 22px;
            margin-bottom: 12px;
        }

        .card p {
            font-size: 16px;

        }

        .card .count {
            font-size: 30px;
            font-weight: bold;
            color: #2c3e50;
        }

        .card .icon {
            font-size: 40px;
            margin-right: 20px;
        }

        .status-padding {
            background-color: #f0ad4e;
            color: white;
        }

        .status-in-progress {
            background-color: #0275d8;
            color: white;
        }

        .status-paused {
            background-color: rgb(241, 213, 51);
            color: white;
        }

        .status-completed {
            background-color: rgb(68, 168, 82);
            color: white;
        }

        .add-task-button {
            padding: 10px 25px;
            border-radius: 5px;
            background-color: #7380ec;
            font-size: 16px;
            font-weight: bold;
            color: white;
            height: 20px;
            text-decoration: none;
        }

        .add-task-button:hover {
            background-color: #7376ec;
            color: white;
        }

        .status-padding,
        .status-in-progress,
        .status-paused,
        .status-completed {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            width: 100px;
        }

        .progress-padding {
            background-color: #f0ad4e;
            height: 10px;
            width: 100%;
        }

        .progress-in-progress {
            background-color: #0275d8;
            height: 10px;
            width: 100%;
        }

        .progress-paused {
            background-color: #f39c12;
            height: 10px;
            width: 100%;
        }

        .progress-completed {
            background-color: #5bc0de;
            height: 10px;
            width: 100%;
        }

        .icon-link {
            position: relative;
            text-decoration: none;
            margin-right: 10px;
            font-size: 20px;
            display: inline-block;
            transition: transform 0.2s ease;
        }

        .icon-link .tooltip {
            position: absolute;
            bottom: 100%;
            left: 100%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
            pointer-events: none;
        }

        .icon-link:hover .tooltip {
            opacity: 1;
            visibility: visible;
        }

        .icon-link i {
            transition: color 0.3s ease, transform 0.3s ease;
        }

        .icon-link:hover i {
            transform: scale(1.2);
        }

        .edit-icon i {
            color: rgb(107, 184, 110);
        }

        .edit-icon:hover i {
            color: #45a049;
        }

        .delete-icon i {
            color: rgb(230, 74, 62);
        }

        .delete-icon:hover i {
            color: #e53935;
        }

        .view-icon {
            color: #2196F3;
        }

        .view-icon:hover {
            color: #1976D2;
        }

        .status-filter select {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        @media (max-width: 768px) {
            .search-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .search-container form {
                width: 100%;
                flex-direction: column;
            }

            #search_bar {
                margin-bottom: 10px;
            }

            button {
                margin-bottom: 10px;
            }

            .add-task-button {
                margin-top: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="main-content">
        <h3>User Task List</h3>

        <div class="search-container">
            <form action="" method="GET">
                <input type="text" id="search_bar" name="search" placeholder="Search tasks..."
                    value="<?= htmlspecialchars($searchQuery) ?>">
                <button type="submit">Search</button>
                <div class="status-filter">
                    <select name="status_filter" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="1" <?= $statusFilter == 1 ? 'selected' : '' ?>>Padding</option>
                        <option value="2" <?= $statusFilter == 3 || $statusFilter == 3 ? 'selected' : '' ?>>In Progress
                        </option>
                        <option value="4" <?= $statusFilter == 4 ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
            </form>

            <a href="add_task.php" class="add-task-button"> + Add Task</a>
        </div>

        <?php if (isset($message) && $message != ""): ?>

            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        <h3>Tasks Assigned By Admin</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Priority</th>
                    <th>Title</th>
                    <th>Due Date</th>
                    <th>Assigned By</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
              
       <?php if (count($resultAssignedByAdmin) > 0): ?>
    <?php foreach ($resultAssignedByAdmin as $task): ?>
        <tr>
            <td><?= htmlspecialchars($task['id']) ?></td>
            <td><?= getPriorityText($task['priority']) ?></td>
            <td><?= htmlspecialchars($task['title']) ?></td>
            <td><?= htmlspecialchars($task['due_date']) ?></td>
            <td><?= htmlspecialchars($task['assigned_by_name']) ?></td>
            <td>
                <div class="status-<?php
                    $status = $task['status'];
                    if ($status == 1)
                        echo 'padding';
                    elseif ($status == 2)
                        echo 'in-progress';
                    elseif ($status == 3)
                        echo 'paused';
                    elseif ($status == 4)
                        echo 'completed';
                ?>">
                    <?= getStatusText($task['status']) ?>
                </div>
                <?php if ($task['status'] == 2): ?>
                    <div class="progress-bar">
                        <div class="progress"
                            style="width: <?= getProgressPercentage($task['total_time'], $task['time_limit']) ?>%;">
                        </div>
                    </div>
                    <small><?= number_format(getProgressPercentage($task['total_time'], $task['time_limit']), 2) ?>%</small>
                <?php endif; ?>
            </td>
            <td>
                <a href="javascript:void(0);" class="view-task-details viewTask icon-link view-icon fas fa-eye"
                    data-task-id="<?= $task['id'] ?>">
                    <span class="tooltip">View</span>
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="7">No tasks found</td>
    </tr>
<?php endif; ?>
            </tbody>
        </table>

        <?php if ($PagesAssignedByAdmin > 1): ?>
            <div class="pagination">
                <div class="google-pagination">
                    <span class="prev-btn">
                        <a href="?page=<?= max(1, $page - 1) ?>" <?= $page == 1 ? 'class="disabled"' : '' ?>>&laquo;
                            Previous</a>
                    </span>
                    <?php for ($i = 1; $i <= $PagesAssignedByAdmin; $i++): ?>
                        <a href="?page=<?= $i ?>&search=<?= urlencode($searchQuery) ?>&status_filter=<?= $statusFilter ?>"
                            class="<?= $i == $page ? 'current' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>

                    <span class="next-btn">
                        <a href="?page=<?= min($PagesAssignedByAdmin, $page + 1) ?>"
                            <?= $page == $PagesAssignedByAdmin ? 'class="disabled"' : '' ?>>Next &raquo;</a>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <h3>Tasks Created By You</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Priority</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
           <?php if (count($tasksCreatedByUser) > 0): ?>
    <?php foreach ($tasksCreatedByUser as $task): ?>
        <tr>
            <td><?= htmlspecialchars($task['id']) ?></td>
            <td><?= getPriorityText($task['priority']) ?></td>
            <td><?= htmlspecialchars($task['title']) ?></td>
            <td>
                <?= strlen($task['description']) > 50 ? htmlspecialchars(substr($task['description'], 0, 50)) . '... <a href="#" class="viewTask icon-link" data-task-id="' . $task['id'] . '">more</a>' : htmlspecialchars($task['description']) ?>
            </td>
            <td><?= htmlspecialchars($task['due_date']) ?></td>
            <td>
                <div class="status-<?php
                    $status = $task['status'];
                    if ($status == 1)
                        echo 'padding';
                    elseif ($status == 2)
                        echo 'in-progress';
                    elseif ($status == 3)
                        echo 'paused';
                    elseif ($status == 4)
                        echo 'completed';
                ?>">
                    <?= getStatusText($task['status']) ?>
                </div>
                <?php if ($task['status'] == 2): ?>
                    <div class="progress-bar">
                        <div class="progress"
                            style="width: <?= getProgressPercentage($task['total_time'], $task['time_limit']) ?>%;">
                        </div>
                    </div>
                    <small><?= number_format(getProgressPercentage($task['total_time'], $task['time_limit']), 2) ?>%</small>
                <?php endif; ?>
            </td>
            <td>
                <a href="add_task.php?id=<?= urlencode((int) $task['id']) ?>" class="icon-link edit-icon">
                    <i class="fas fa-pencil-alt"></i>
                    <span class="tooltip">Edit</span>
                </a>
                <a href="?delete_id=<?= $task['id'] ?>" class="icon-link delete-icon"
                    onclick="return confirm('Are you sure you want to delete this user?')">
                    <i class="fas fa-trash-alt"></i>
                    <span class="tooltip">Delete</span>
                </a>
                <a href="javascript:void(0);" class="view-task-details viewTask icon-link view-icon fas fa-eye"
                    data-task-id="<?= $task['id'] ?>">
                    <span class="tooltip">View</span>
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="6">No tasks found</td>
    </tr>
<?php endif; ?>

            </tbody>
        </table>

        <?php if ($PagesCreatedByUser > 1): ?>

            <div class="pagination">
                <div class="google-pagination">
                    <span class="prev-btn">
                        <a href="?page=<?= max(1, $page - 1) ?>" <?= $page == 1 ? 'class="disabled"' : '' ?>>&laquo;
                            Previous</a>
                    </span>
                    <?php for ($i = 1; $i <= $PagesCreatedByUser; $i++): ?>
                        <a href="?page=<?= $i ?>&search=<?= urlencode($searchQuery) ?>&status_filter=<?= $statusFilter ?>"
                            class="<?= $i == $page ? 'current' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>

                    <span class="next-btn">
                        <a href="?page=<?= min($PagesCreatedByUser, $page + 1) ?>" <?= $page == $PagesCreatedByUser ? 'class="disabled"' : '' ?>>Next &raquo;</a>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div id="taskDetailsModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" id="closeModal">&times;</span>
            <h3>Task Details</h3>
            <div id="taskDetails"></div>
            <button id="startButton" class="taskButton">Start</button>
            <button id="stopButton" class="taskButton">Stop</button>
            <button id="resumeButton" class="taskButton">Resume</button>
            <button id="completeButton" class="taskButton">Complete</button>
        </div>
    </div>

    </div>
    </div>
    <script>
        const viewButtons = document.querySelectorAll('.viewTask');
        viewButtons.forEach(button => {
            button.addEventListener('click', function () {
                const taskId = this.getAttribute('data-task-id');
                fetchTaskDetails(taskId);
                updateTaskStatus(taskId);
            });
        });

        document.getElementById('closeModal').addEventListener('click', function () {
            document.getElementById('taskDetailsModal').style.display = 'none';
        });

        function fetchTaskDetails(taskId) {
            fetch(`task_details.php?task_id=${taskId}`)
                .then(response => response.json())
                .then(data => {
                    let statusText = '';
                    if (data.status == 1) {
                        statusText = 'Padding';
                    } else if (data.status == 2 || data.status == 3) {
                        statusText = 'in-progress';
                    } else if (data.status == 4) {
                        statusText = 'Completed';
                    }
                    const taskDetailsDiv = document.getElementById('taskDetails');
                    taskDetailsDiv.innerHTML = `
                <p><strong>Task id:</strong> ${data.id}</p>
                <p><strong>Title:</strong> ${data.title}</p>
                <p><strong>Description:</strong> ${data.description}</p>
                <p><strong>Due Date:</strong> ${data.due_date}</p>
                <p><strong>Time Limit:</strong> ${data.time_limit}</p>
                <p><strong>Status:</strong> <span class="status-${statusText}">${statusText}</span></p>

                 <p><strong>Time Worked:</strong> ${data.total_time}</p>

            `;
                    document.getElementById('taskDetailsModal').style.display = 'flex';
                    setButtonStatus(data.status);
                });
        }
        function updateTaskStatus(taskId) {
            document.getElementById('startButton').addEventListener('click', function () {
                updateStatus(taskId, 'start');
            });

            document.getElementById('stopButton').addEventListener('click', function () {
                updateStatus(taskId, 'stop');
            });

            document.getElementById('resumeButton').addEventListener('click', function () {
                updateStatus(taskId, 'resume');
            });

            document.getElementById('completeButton').addEventListener('click', function () {
                updateStatus(taskId, 'complete');
            });
        }

        function updateStatus(taskId, action) {
            fetch('update_task_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `task_id=${taskId}&action=${action}`
            })
                .then(response => response.text())
                .then(data => {
                    fetchTaskDetails(taskId);
                })
                .catch(error => console.error('Error:', error));
        }

        function setButtonStatus(status) {
            const startButton = document.getElementById('startButton');
            const stopButton = document.getElementById('stopButton');
            const resumeButton = document.getElementById('resumeButton');
            const completeButton = document.getElementById('completeButton');

            startButton.disabled = true;
            stopButton.disabled = true;
            resumeButton.disabled = true;
            completeButton.disabled = true;

            status = Number(status);

            switch (status) {
                case 1:
                    startButton.disabled = false;
                    break;
                case 2:
                    stopButton.disabled = false;
                    completeButton.disabled = false;
                    break;
                case 3:
                    resumeButton.disabled = false;
                    break;
                case 4:
                    break;
                default:
                    console.error('Unknown status: ' + status);
                    break;
            }
        }
    </script>
</body>

</html>
<?php
ob_end_flush();
include "./includes/footer.php";
?>