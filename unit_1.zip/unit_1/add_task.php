<?php
include 'includes/session.php';
include_once "config/connect.php";
include_once "config/function_config.php";
include 'includes/header.php';
include 'includes/sidebar.php';
include_once "./root/function.php";  

$msg = $_GET['msg'] ?? '';
$message = '';
$error_message = ''; 

if ($msg == 1) {
    $message = "Task added successfully!";
} elseif ($msg == 2) {
    $message = "Task updated successfully!";
}

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: login.php");
    exit();
}

$task_id = $_GET['id'] ?? null;

if ($task_id) {
    $query = "SELECT * FROM task WHERE id = ? AND user_id = ?";
    $task = rpt_fetchData($query, [$task_id, $user_id]);

    if (empty($task)) {
        header("Location: task_manage.php");
        exit();
    }

    $task = $task[0];
    $title = $task['title'];
    $description = $task['description'];
    $due_date = $task['due_date'];
    $time_limit = $task['time_limit'];
    $priority = $task['priority'];
    $attachment = $task['attachment'];
} else {
    $title = '';
    $description = '';
    $due_date = ''; 
    $time_limit = 0;
    $priority = 2; 
    $attachment = '';
}

$nonce_token = generate_nonce_token();  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['nonce_token']) || !verify_nonce_token($_POST['nonce_token'])) {
        $error_message = "Something went wrong. Please try again."; 
    } else {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $due_date = $_POST['due_date'];
        $time_limit = $_POST['time_limit'] ?? '00:00';
        $priority = $_POST['priority'];
        $attachment = $_FILES['attachment']['name'];

        $time_limit_seconds = ($time_limit === "00:00") ? 0 : (explode(":", $time_limit)[0] * 3600) + (explode(":", $time_limit)[1] * 60);
        $file_query_part = '';
        
        if ($attachment) {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'doc', 'odt', 'pdf'];
            $file_extension = pathinfo($attachment, PATHINFO_EXTENSION);
            if (!in_array(strtolower($file_extension), $allowedExtensions)) {
                $error_message = 'Invalid file type. Only jpg, jpeg, png, doc, odt, pdf files are allowed.'; 
            } else {
                $unique_name = uniqid() . '.' . $file_extension;
                $target_file = "uploads/" . $unique_name;
                move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file);
                $file_query_part = ", attachment=?";
            }
        }

        if (!$error_message) { 
            if ($task_id) {
                $query = "UPDATE task SET title=?, description=?, due_date=?, time_limit=?, user_id=?, priority=?, created_by=?" . $file_query_part . " WHERE id=? AND user_id=?";
                $params = [$title, $description, $due_date, $time_limit_seconds, $user_id, $priority, $user_id];
                if ($attachment) {
                    $params[] = $unique_name;
                }
                $params[] = $task_id;
                $params[] = $user_id;
                rpt_executeQuery($query, $params);
                header("Location: task_manage.php?msg=2");
            } else {
                $query = "INSERT INTO task (title, description, due_date, time_limit, user_id, priority, created_by" . $file_query_part . ") 
                          VALUES (?, ?, ?, ?, ?, ?, ?" . ($attachment ? ', ?' : '') . ")";
                $params = [$title, $description, $due_date, $time_limit_seconds, $user_id, $priority, $user_id];
                if ($attachment) {
                    $params[] = $unique_name;
                }
                rpt_executeQuery($query, $params);
                header("Location: add_task.php?msg=1");
            }
            exit();
        }
    }
}

$hours = floor($time_limit / 3600);
$minutes = floor(($time_limit % 3600) / 60);
$seconds = $time_limit % 60;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</title>
    <script src="./assets/js/script.js"></script>
</head>
<body>
  <div class="main-content">
        <h1><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</h1>
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="message error">
                <?php echo $error_message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        
        <form id="taskForm" class="task-form" method="POST" enctype="multipart/form-data" onsubmit="return addtaskform()">
         <input type="hidden" id="nonce_token" name="nonce_token" value="<?php echo $nonce_token; ?>">
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="task-input" name="title" id="title" value="<?php echo htmlspecialchars($title); ?>" placeholder="Enter task title">
                <span id="title-error" class="error-message">Please enter title</span>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" class="task-input" id="description" placeholder="Enter task description"><?php echo htmlspecialchars($description); ?></textarea>
                <span id="description-error" class="error-message">Please enter description</span>
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="date" class="task-input" name="due_date" id="due_date" value="<?php echo htmlspecialchars($due_date); ?>" min="<?php echo date('Y-m-d'); ?>">
                <span id="due_date-error" class="error-message">Please enter due date</span>
            </div>

            <div class="form-group">
                <label for="time_limit">Time Limit</label>
                <input type="time" class="task-input" name="time_limit" id="time_limit" value="<?php echo str_pad($hours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ':' . str_pad($seconds, 2, '0', STR_PAD_LEFT); ?>" />
                <span id="time_limit-error" class="error-message">Please enter time limit</span>
            </div>

            <div class="form-group">
                <label for="priority">Priority</label>
                <div class="priority-wrapper">
                <label for="low">
                    <input type="radio" class="task-input" id="low" name="priority" value="1" <?php echo $priority == 1 ? 'checked' : ''; ?>> Low
                </label>
                <label for="medium">
                    <input type="radio" class="task-input" id="medium" name="priority" value="2" <?php echo $priority == 2 ? 'checked' : ''; ?>> Medium
                </label>
                <label for="high">
                    <input type="radio" class="task-input" id="high" name="priority" value="3" <?php echo $priority == 3 ? 'checked' : ''; ?>> High
                </label>
                <span id="priority-error" class="error-message">Please select priority</span>
                </div>
            </div>

            <div class="form-group">
                <label for="attachment">Attachment</label>
                <input type="file" class="task-input" name="attachment" id="attachment" accept=".jpg,.jpeg,.png,.doc,.odt,.pdf">
            <?php if ($attachment): ?>
                <p>Current file: <?php echo htmlspecialchars($attachment); ?></p>
            <?php endif; ?>
            </div>

            <div class="button-container">
                <button type="submit" class="btn-task"><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php include 'includes/footer.php'; ?>