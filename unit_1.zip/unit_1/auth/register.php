<?php
include_once "../config/connect.php";
include_once "../config/function_config.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : null;

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $result = rpt_safe_query("SELECT id FROM users ORDER BY id DESC LIMIT 1", '', []);
    $row = $result ? $result[0] : null;
    $user_id = $row ? $row['id'] + 1 : 1001;

    $username_check = rpt_safe_query("SELECT * FROM users WHERE username = ?", 's', [$username]);
    if (count($username_check) > 0) {
        echo "<script>alert('Username already exists. Choose another one.');</script>";
        return;
    }
    $query = "INSERT INTO users (id, name, email, phone, username, password, gender) VALUES (?, ?, ?, ?, ?, ?, ?)";
    if (rpt_safe_query($query, 'issssss', [$user_id, $name, $email, $phone, $username, $password_hashed, $gender])) {
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $name;
        $_SESSION['email'] = $email;
        $_SESSION['gender'] = $gender;
        header("Location: ../index.php");
        exit();
    } else {
        echo "<script>alert('Error during registration. Try again.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/script.js"></script>
</head>
<body>
    <div class="register-container">
        <div style="margin-bottom: 30px;">
            <h1>User Registration</h1>
            <p style="font-size: 14px;">Kindly fill the following details to create your account.</p>
        </div>
        <form id="registerForm" class="register-form" method="POST" action="register.php" onsubmit="return registerform()">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" placeholder=" Enter your full name">
            <span id="name-error" class="error-message">Please enter name</span>

            <label for="email">Email</label>
            <input type="text" name="email" id="email" placeholder=" Enter a valid email address">
            <span id="email-error" class="error-message">Please enter email address</span>

            <label for="phone">Phone Number</label>
            <input type="text" name="phone" id="phone" placeholder=" Enter your phone number (10 digits)">
            <div id="phone-error" class="error-message"></div>

            <label for="gender">Gender</label>
            <div class="gender-container">
                <input type="radio" name="gender" id="male" value="1">
                <label for="male">Male</label>
                <input type="radio" name="gender" id="female" value="2">
                <label for="female">Female</label>
                <input type="radio" name="gender" id="other" value="3">
                <label for="other">Other</label>
            </div>
            <div id="gender-error" class="error-message"></div>

            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder=" create a unique username">
            <div id="username-error" class="error-message"></div>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder=" Enter a secure password">
            <div id="password-error" class="error-message"></div>

            <label for="password_confirm">Confirm Password</label>
            <input type="password" name="password_confirm" id="password_confirm" placeholder=" confirm your password">
            <div id="password_confirm-error" class="error-message"></div>

            <button type="submit" class="btn-register">Register</button>
        </form>
        <div class="register-link">
            <p>Already have an account? <a href="login.php">Sign in here</a></p>
        </div>
    </div>
</body>
</html>

