<?php
session_start();
include "../config/connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = escape($_POST['name']);
    $email = escape($_POST['email']);
    $phone = escape($_POST['phone']);
    $username = escape($_POST['username']);
    $password = escape($_POST['password']);
    $password_confirm = escape($_POST['password_confirm']);
    $gender = isset($_POST['gender']) ? $_POST['gender'] : null;

    if ($password !== $password_confirm) {
        echo "<script>alert('Passwords do not match. Try again.');</script>";
        return;
    }

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $result = safe_query("SELECT id FROM users ORDER BY id DESC LIMIT 1");
    $row = mysqli_fetch_assoc($result);
    $user_id = $row ? $row['id'] + 1 : 1001;

    $username_check = safe_query("SELECT * FROM users WHERE username = ?", 's', [$username]);
    if (mysqli_num_rows($username_check) > 0) {
        echo "<script>alert('Username already exists. Choose another one.');</script>";
        return;
    }

    $query = "INSERT INTO users (id, name, email, phone, username, password, gender) VALUES (?, ?, ?, ?, ?, ?, ?)";
    if (safe_query($query, 'issssss', [$user_id, $name, $email, $phone, $username, $password_hashed, $gender])) {
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $name;
        $_SESSION['email'] = $email;
        $_SESSION['gender'] = $gender;
        header("Location: ../index.php");
        exit();
    } else {
        echo "<script>alert('Error during registration. Try again.');</script>";
    }
}
ob_end_flush();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
        }

        .container {
            width: 100%;
            max-width: 600px;
            margin: auto;
            padding: 40px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
        }

        h1 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #4f7092;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
            cursor: pointer;
        }

        input,
        select {
            margin-top: 8px;
            padding: 12px;
            margin-bottom: 16px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
        }

        button {
            padding: 12px;
            background-color: #34495e;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #435975;
        }

        footer {
            background-color: #4f7092;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 14px;
            margin-top: auto;
        }

        .error {
            border-color: red !important;
        }

        .error-message {
            color: red;
            font-size: 12px;
            margin-top: -12px;
            margin-bottom: 16px;
        }

        .focused {
            border-color: darkgray !important;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
        }

        .register-link a {
            color: #4f7092;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .gender-container {
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .gender-container input {
            cursor: pointer;
        }
        .gender-container label {
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            h1 {
                font-size: 24px;
            }

            button {
                font-size: 14px;
                padding: 10px 15px;
            }

            input,
            select {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
         <div style="margin-bottom: 30px;">
            <h1>User Registration</h1>
            <p style="font-size: 14px;">Kindly fill the following details to create your account.</p>
        </div>
        <form id="registerForm" method="POST" action="register.php">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" placeholder=" Enter your full name">
            <div id="name-error" class="error-message"></div>

            <label for="email">Email</label>
            <input type="text" name="email" id="email" placeholder=" Enter a valid email address">
            <div id="email-error" class="error-message"></div>

            <label for="phone">Phone Number</label>
            <input type="text" name="phone" id="phone" placeholder=" Enter your phone number (10 digits)">
            <div id="phone-error" class="error-message"></div>

            <label for="gender">Gender</label>
            <div class="gender-container">
                <input type="radio" name="gender" id="male" value="1">
                <label for="male">Male</label>
                <input type="radio" name="gender" id="female" value="2">
                <label for="female">Female</label>
                <input type="radio" name="gender" id="other" value="3">
                <label for="other">Other</label>
            </div>
            <div id="gender-error" class="error-message"></div>

            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder=" create a unique username">
            <div id="username-error" class="error-message"></div>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder=" Enter a secure password">
            <div id="password-error" class="error-message"></div>

            <label for="password_confirm">Confirm Password</label>
            <input type="password" name="password_confirm" id="password_confirm" placeholder=" confirm your password">
            <div id="password_confirm-error" class="error-message"></div>

            <button type="submit">Register</button>
        </form>
        <div class="register-link">
            <p>Already have an account? <a href="login.php">Sign in here</a></p>
        </div>
    </div>

      <script>
   document.addEventListener("DOMContentLoaded", function () {
    document.getElementById('FormValidation').onsubmit = function (event) {
        let hasErrors = false;
        let firstErrorField = null; 

        function validateField(id, errorMessage) {
            let input = document.getElementById(id);
            let errorDiv = document.getElementById(id + '-error');

            if (input.value.trim() === "") {
                input.classList.add('error');
                errorDiv.textContent = errorMessage;
                if (!hasErrors) {
                    firstErrorField = input;
                }
                hasErrors = true;
            } else {
                input.classList.remove('error');
                errorDiv.textContent = "";
            }
        }

       
        validateField("name", "Full name is required");

       
        let email = document.getElementById("email");
        let emailError = document.getElementById("email-error");
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email.value.trim() === "") {
            email.classList.add("error");
            emailError.textContent = "Email is required";
            if (!hasErrors) {
                firstErrorField = email;
            }
            hasErrors = true;
        } else if (!emailPattern.test(email.value.trim())) {
            email.classList.add("error");
            emailError.textContent = "Enter a valid email";
            if (!hasErrors) {
                firstErrorField = email;
            }
            hasErrors = true;
        } else {
            email.classList.remove("error");
            emailError.textContent = "";
        }
        
        validateField("phone", "Phone number is required");
      
        validateField("username", "Username is required");

        
        let password = document.getElementById("password");
        let passwordError = document.getElementById("password-error");
        let confirmPassword = document.getElementById("password_confirm");
        let confirmPasswordError = document.getElementById("password_confirm-error");

        if (password.value.trim() === "") {
            password.classList.add("error");
            passwordError.textContent = "Password is required";
            if (!hasErrors) {
                firstErrorField = password;
            }
            hasErrors = true;
        } else {
            password.classList.remove("error");
            passwordError.textContent = "";
        }

        if (confirmPassword.value.trim() === "") {
            confirmPassword.classList.add("error");
            confirmPasswordError.textContent = "Confirm password is required";
            if (!hasErrors) {
                firstErrorField = confirmPassword;
            }
            hasErrors = true;
        } else if (password.value !== confirmPassword.value) {
            confirmPassword.classList.add("error");
            confirmPasswordError.textContent = "Passwords do not match";
            if (!hasErrors) {
                firstErrorField = confirmPassword;
            }
            hasErrors = true;
        } else {
            confirmPassword.classList.remove("error");
            confirmPasswordError.textContent = "";
        }

     
        let genderInputs = document.querySelectorAll('input[name="gender"]');
        let genderError = document.getElementById("gender-error");
        let genderSelected = false;

        genderInputs.forEach(input => {
            if (input.checked) {
                genderSelected = true;
            }
        });

        if (!genderSelected) {
            genderError.textContent = "Please select a gender";
            if (!hasErrors) {
                firstErrorField = genderInputs[0]; 
            }
            hasErrors = true;
        } else {
            genderError.textContent = "";
        }

        
        if (firstErrorField) {
            setTimeout(() => firstErrorField.focus(), 500);
        }

        
        if (hasErrors) {
            event.preventDefault();
        }
    };

   
    document.querySelectorAll('input, select, textarea').forEach(function (input) {
        input.addEventListener('input', function () {
            this.classList.remove('error');
            let errorDiv = document.getElementById(this.id + '-error');
            if (errorDiv) errorDiv.textContent = "";
        });

        input.addEventListener('focus', function () {
            this.classList.remove('error');
            let errorDiv = document.getElementById(this.id + '-error');
            if (errorDiv) errorDiv.textContent = "";
        });
    });
});


    </script>
</body>
</html>
