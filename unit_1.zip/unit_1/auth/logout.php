<?php
session_start();
session_unset();
session_destroy();
setcookie('theme', '', time() - 3600, '/');
setcookie('user_id', '', time() - 3600, '/');
setcookie('user', '', time() - 3600, '/');
header('Location: login.php');
exit();
?>