<?php
ob_start();
session_start();
include "../config/connect.php";
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: auth/login.php');
    exit();
}

$user_id = isset($_GET['id']) ? $_GET['id'] : null;
$name = $email = $phone = $gender = $username = $password = $password_confirm = '';
$update = false;

if ($user_id) {
    $query = "SELECT * FROM users WHERE id = :user_id";
    $result = fetchData($query, ['user_id' => $user_id]);
    if (count($result) > 0) {
        $row = $result[0];
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $gender = $row['gender'];
        $username = $row['username'];
    }
    $update = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $username_check = fetchData("SELECT id FROM users WHERE username = :username", ['username' => $username]);
    if ($username_check && !$update) {
        echo "<script>alert('Username already exists. Choose another one.');</script>";
        return;
    }
    
    if ($password !== $password_confirm) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        if ($update) {
            if ($username !== $row['username']) {
                $query = "UPDATE users SET name = :name, email = :email, phone = :phone, gender = :gender, username = :username, password = :password WHERE id = :user_id";
                executeQuery($query, ['name' => $name, 'email' => $email, 'phone' => $phone, 'gender' => $gender, 'username' => $username, 'password' => $password_hashed, 'user_id' => $user_id]);
            } else {
                $query = "UPDATE users SET name = :name, email = :email, phone = :phone, gender = :gender, password = :password WHERE id = :user_id";
                executeQuery($query, ['name' => $name, 'email' => $email, 'phone' => $phone, 'gender' => $gender, 'password' => $password_hashed, 'user_id' => $user_id]);
            }
            header("Location: manage_user.php?msg=2");
        } else {
            $query = "INSERT INTO users (name, email, phone, gender, username, password) VALUES (:name, :email, :phone, :gender, :username, :password)";
            executeQuery($query, ['name' => $name, 'email' => $email, 'phone' => $phone, 'gender' => $gender, 'username' => $username, 'password' => $password_hashed]);
            header("Location: add_user.php?msg=1");
        }
        exit();
    }
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "User added successfully!";
    } else {
        $message = "";
    }
}
ob_end_flush();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($user_id) ? 'Edit User' : 'Add User' ?></title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        }

 body.light {
        color: #333;
    }

    body.dark {
        background-color: #2a2a2a;
        color: #f7f7f7;
    }
        h1 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        h2 {
            font-size: 25px;
        }

        form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            width: 100%;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        textarea,
        select {
            margin-top: 8px;
            padding: 12px;
            margin-bottom: 16px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
            width: 100%;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
        }

        .success {
            background-color: rgb(100, 185, 103);
            color: white;
        }

        input:focus,
        textarea:focus,
        select:focus {
            border-color: #4f7092;
            outline: none;
        }

        button {
            padding: 12px;
            background-color: #4f7092;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            width: 20%;
            cursor: pointer;
            transition: background-color 0.3s;
            grid-column: span 2;
        }

        button:hover {
            background-color: #435975;
        }


        .error {
            border-color: red !important;
        }

        .gender-wrapper {
            display: flex;
            gap: 10px;
            font-size: 18 margin-bottom: 16px;
            grid-column: span 2;
        }

        .gender-wrapper label {
            cursor: pointer;
            gap: 5px;
            display: flex;
            align-items: center;
            font-weight: normal;
        }

        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }

        .focused {
            border-color: #d9534f !important;
            outline: none;
        }

        @media (max-width: 768px) {
            form {
                grid-template-columns: 1fr;
                padding: 15px;
            }

            h1 {
                font-size: 20px;
            }

            button {
                font-size: 14px;
                padding: 10px 15px;
            }

            input,
            textarea {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>
    <div class="main-content">
        <h2><?= isset($user_id) ? 'Edit User' : 'Add User' ?></h2>
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        <form method="POST" action="" id="FormValidation">
            <div>
                <label for="name">Full Name</label>
                <input type="text" name="name" id="name" placeholder=" Enter Full Name"
                    value="<?= htmlspecialchars($name) ?>">
                <div id="name-error" class="error-message"></div>
            </div>

            <div>
                <label for="email">Email</label>
                <input type="text" name="email" id="email" placeholder="Enter Email Address"
                    value="<?= htmlspecialchars($email) ?>">
                <div id="email-error" class="error-message"></div>
            </div>

            <div>
                <label for="phone">Phone Number</label>
                <input type="text" name="phone" id="phone" placeholder=" Enter Phone Number"
                    value="<?= htmlspecialchars($phone) ?>">
                <div id="phone-error" class="error-message"></div>
            </div>

            <div>
                <label>Gender</label>
                <div class="gender-wrapper">
                    <label for="male">
                        <input type="radio" style="margin-top: 18px;" name="gender" id="male" value="1" <?= $gender === '1' ? 'checked' : '' ?>>
                        Male
                    </label>
                    <label for="female">
                        <input type="radio" style="margin-top: 17px;" name="gender" id="female" value="2"
                            <?= $gender === '2' ? 'checked' : '' ?>>
                        Female
                    </label>
                    <label for="other">
                        <input type="radio" style="margin-top: 16px; " name="gender" id="other" value="3"
                            <?= $gender === '3' ? 'checked' : '' ?>>
                        Other
                    </label>
                </div>
                <div id="gender-error" class="error-message"></div>
            </div>

            <div>
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder=" Enter Username"
                    value="<?= htmlspecialchars($username) ?>">
                <div id="username-error" class="error-message"></div>
            </div>

            <div>
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter Password">
                <div id="password-error" class="error-message"></div>
            </div>

            <div>
                <label for="password_confirm">Confirm Password</label>
                <input type="password" name="password_confirm" id="password_confirm"
                    placeholder=" Enter Confirm Password">
                <div id="password_confirm-error" class="error-message"></div>
            </div>

            <button type="submit"><?= isset($user_id) ? 'Update User' : 'Add User' ?></button>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.getElementById('FormValidation').onsubmit = function (event) {
                let hasErrors = false;
                let firstErrorField = null;

                function validateField(id, errorMessage) {
                    let input = document.getElementById(id);
                    let errorDiv = document.getElementById(id + '-error');

                    if (input.value.trim() === "") {
                        input.classList.add('error');
                        errorDiv.textContent = errorMessage;
                        if (!hasErrors) {
                            firstErrorField = input;
                        }
                        hasErrors = true;
                    } else {
                        input.classList.remove('error');
                        errorDiv.textContent = "";
                    }
                }


                validateField("name", "Full name is required");


                let email = document.getElementById("email");
                let emailError = document.getElementById("email-error");
                let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (email.value.trim() === "") {
                    email.classList.add("error");
                    emailError.textContent = "Email is required";
                    if (!hasErrors) {
                        firstErrorField = email;
                    }
                    hasErrors = true;
                } else if (!emailPattern.test(email.value.trim())) {
                    email.classList.add("error");
                    emailError.textContent = "Enter a valid email";
                    if (!hasErrors) {
                        firstErrorField = email;
                    }
                    hasErrors = true;
                } else {
                    email.classList.remove("error");
                    emailError.textContent = "";
                }

                validateField("phone", "Phone number is required");

                validateField("username", "Username is required");


                let password = document.getElementById("password");
                let passwordError = document.getElementById("password-error");
                let confirmPassword = document.getElementById("password_confirm");
                let confirmPasswordError = document.getElementById("password_confirm-error");

                if (password.value.trim() === "") {
                    password.classList.add("error");
                    passwordError.textContent = "Password is required";
                    if (!hasErrors) {
                        firstErrorField = password;
                    }
                    hasErrors = true;
                } else {
                    password.classList.remove("error");
                    passwordError.textContent = "";
                }

                if (confirmPassword.value.trim() === "") {
                    confirmPassword.classList.add("error");
                    confirmPasswordError.textContent = "Confirm password is required";
                    if (!hasErrors) {
                        firstErrorField = confirmPassword;
                    }
                    hasErrors = true;
                } else if (password.value !== confirmPassword.value) {
                    confirmPassword.classList.add("error");
                    confirmPasswordError.textContent = "Passwords do not match";
                    if (!hasErrors) {
                        firstErrorField = confirmPassword;
                    }
                    hasErrors = true;
                } else {
                    confirmPassword.classList.remove("error");
                    confirmPasswordError.textContent = "";
                }


                let genderInputs = document.querySelectorAll('input[name="gender"]');
                let genderError = document.getElementById("gender-error");
                let genderSelected = false;

                genderInputs.forEach(input => {
                    if (input.checked) {
                        genderSelected = true;
                    }
                });

                if (!genderSelected) {
                    genderError.textContent = "Please select a gender";
                    if (!hasErrors) {
                        firstErrorField = genderInputs[0];
                    }
                    hasErrors = true;
                } else {
                    genderError.textContent = "";
                }


                if (firstErrorField) {
                    setTimeout(() => firstErrorField.focus(), 500);
                }


                if (hasErrors) {
                    event.preventDefault();
                }
            };

            document.querySelectorAll('input, select, textarea').forEach(function (input) {
                input.addEventListener('input', function () {
                    this.classList.remove('error');
                    let errorDiv = document.getElementById(this.id + '-error');
                    if (errorDiv) errorDiv.textContent = "";
                });

                input.addEventListener('focus', function () {
                    this.classList.remove('error');
                    let errorDiv = document.getElementById(this.id + '-error');
                    if (errorDiv) errorDiv.textContent = "";
                });
            });
        });
    </script>
</body>
<?php include 'includes/footer.php'; ?>

</html>
