<?php
include 'includes/permission_check.php';
include 'includes/session.php';
include "../config/connect.php";
include "../config/function_config.php";
include 'includes/navbar.php';
include 'includes/sidebar.php';

$user_id = isset($_GET['id']) ? $_GET['id'] : null;
$name = $email = $phone = $gender = $username = $password = $password_confirm = '';
$update = false;
$permission_error_msg = '';

function fetchDatas($query, $params = []) {
    global $conn;
    $stmt = rpt_prepare($query);
    if ($params) {
        $i = 1;
        foreach ($params as $key => $value) {
            $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
            rpt_bindValue($stmt, $key, $value, $paramType);
        }
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function executeQuerys($query, $params = []) {
    global $conn;
    $stmt = rpt_prepare($query);
    foreach ($params as $key => $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, ":$key", $value, $paramType);
    }
    return $stmt->execute();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if (!hasPermission('can_add_user')) {
        $permission_error_msg = 'You do not have permission to add a user.';
    }

    if ($permission_error_msg === '') {
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);

        if ($user_id) {
            if ($password !== $password_confirm) {
                $permission_error_msg = 'Passwords do not match';
            } else {
                if (!hasPermission('can_edit_user')) {
                    $permission_error_msg = 'You do not have permission to edit a user.';
                }

                if ($permission_error_msg === '') {
                    $query = "UPDATE users SET name = :name, email = :email, phone = :phone, gender = :gender, username = :username, password = :password WHERE id = :user_id";
                    $params = [
                        'name' => $name,
                        'email' => $email,
                        'phone' => $phone,
                        'gender' => $gender,
                        'username' => $username,
                        'password' => password_hash($password, PASSWORD_DEFAULT),
                        'user_id' => $user_id
                    ];
                    executeQuerys($query, $params);
                    header("Location: manage_user.php?msg=2");
                }
            }
        } else {
            $query = "INSERT INTO users (name, email, phone, gender, username, password) VALUES (:name, :email, :phone, :gender, :username, :password)";
            $params = [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'gender' => $gender,
                'username' => $username,
                'password' => password_hash($password, PASSWORD_DEFAULT)
            ];
            executeQuerys($query, $params);
            header("Location: add_user.php?msg=1");
        }
        exit();
    }
}

if ($user_id) {
    $query = "SELECT * FROM users WHERE id = :id";
    $result = fetchDatas($query, ['id' => $user_id]);
    if ($result) {
        $row = $result[0];
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $gender = $row['gender'];
        $username = $row['username'];
    }
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "User added successfully!";
    } elseif ($msg == 2) {
        $message = "User updated successfully!";
    } else {
        $message = "";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($user_id) ? 'Edit User' : 'Add User' ?></title>
    <script src="./assets/js/script.js"></script> 
</head>
<body>
    <div class="main-content">
        <h3><?= isset($user_id) ? 'Edit User' : 'Add User' ?></h3>
        
        <?php if ($permission_error_msg != ''): ?>
            <div class="message error">
                <?php  echo $permission_error_msg; ?>
            </div>
             <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <form method="POST" class="task-form" action="" id="FormValidation" onsubmit="return adduservalidation()">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" class="task-input" name="name" id="name" placeholder=" Enter Full Name"
                    value="<?= htmlspecialchars($name) ?>">
                <div id="name-error" class="error-message"></div>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="task-input"  name="email" id="email" placeholder="Enter Email Address"
                    value="<?= htmlspecialchars($email) ?>">
                <div id="email-error" class="error-message"></div>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" class="task-input" name="phone" id="phone" placeholder=" Enter Phone Number"
                    value="<?= htmlspecialchars($phone) ?>">
                <div id="phone-error" class="error-message"></div>
            </div>

            <div class="form-group" >
                <label>Gender</label>
                <div class="priority-wrapper">
                    <label for="male">
                        <input type="radio" class="task-input"  name="gender" id="male" value="1" <?= $gender === '1' ? 'checked' : '' ?>>
                        Male
                    </label>
                    <label for="female">
                        <input type="radio" class="task-input"  name="gender" id="female" value="2"
                            <?= $gender === '2' ? 'checked' : '' ?>>
                        Female
                    </label>
                    <label for="other">
                        <input type="radio"  class="task-input" name="gender" id="other" value="3"
                            <?= $gender === '3' ? 'checked' : '' ?>>
                        Other
                    </label>
                </div>
                <div id="gender-error" class="error-message"></div>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="task-input" name="username" id="username" placeholder=" Enter Username"
                    value="<?= htmlspecialchars($username) ?>">
                <div id="username-error" class="error-message"></div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="task-input" name="password" id="password" placeholder="Enter Password" 
                  value="<?= htmlspecialchars($password) ?>">
                <div id="password-error" class="error-message"></div>
            </div>

            <div class="form-group">
                <label for="password_confirm">Confirm Password</label>
                <input type="password" class="task-input" name="password_confirm" id="password_confirm"
                    placeholder=" Enter Confirm Password">
                <div id="password_confirm-error" class="error-message"></div>
            </div>

            <div class="button-container">
            <button type="submit" class="btn-task"><?= isset($user_id) ? 'Update User' : 'Add User' ?></button>
            </div>
        </form>
    </div>
</body>
</html>

<?php
include "./includes/footer.php";
?>
