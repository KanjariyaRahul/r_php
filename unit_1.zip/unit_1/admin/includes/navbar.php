<?php
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: auth/login.php');
    exit();
}
include_once '../config/connect.php';
include_once '../config/function_config.php';


$user_id = $_SESSION['user_id'];
$query = "SELECT a.theme, a.username FROM admin a WHERE a.id = :user_id";
$stmt = $conn->prepare($query);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['username'] = $result['username'];

    $is_admin = $_SESSION['role'] === 'admin';
    $theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : ($result['theme'] == 2 ? 'dark' : 'light');

    if (isset($_GET['theme'])) {
        $new_theme = $_GET['theme'];
        $theme_value = ($new_theme == 'dark') ? 2 : 1;
        $update_query = "UPDATE admin SET theme = :theme_value WHERE id = :user_id";
        $update_stmt = $conn ->prepare($update_query);
        $update_stmt->bindValue(':theme_value', $theme_value, PDO::PARAM_INT);
        $update_stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $update_stmt->execute();

        $_SESSION['theme'] = $new_theme;
        setcookie('theme', $new_theme, time() + 3600, "/");

        echo json_encode(['status' => 'success', 'theme' => $new_theme]);
        exit();
    }
} else {
    die('Error: User not found');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<link rel="stylesheet" href="./assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<header>
    <div class="logo">
        <a href="index.php">Task Manager</a>
    </div>
    <div class="nav-right">
        <span class="username">Welcome, <?php echo $_SESSION['username']; ?></span>
        <div class="icon-container">
            <a href="auth/logout.php" class="logout-icon"><i class="fas fa-sign-out-alt"></i></a>
        </div>
        <div class="icon-container">
            <div class="theme-toggle" id="themeIcon">
                <span class="theme-icon">
                    <i class="fas fa-moon"></i>
                </span>
            </div>
            <span class="tooltip" style="margin-left: -50px" id="themeTooltip"><?php echo $theme == 'dark' ? 'Light Theme' : 'Dark Theme'; ?></span>
        </div>
    </div>
</header>
<script>
    let isChangingTheme = false;

    function applyThemeImmediately(newTheme) {
        document.body.classList.remove('dark', 'light');
        document.body.classList.add(newTheme);
        document.cookie = "theme=" + newTheme + "; path=/";
        document.getElementById('themeIcon').innerHTML = newTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        document.getElementById('themeTooltip').textContent = newTheme === 'dark' ? 'Light Theme' : 'Dark Theme';
    }

    function setInitialTheme() {
        let theme = '<?php echo $theme; ?>';
        applyThemeImmediately(theme);
    }

    window.onload = function () {
        setInitialTheme();
    };

    document.getElementById('themeIcon').addEventListener('click', function () {
        if (isChangingTheme) return;

        let newTheme = document.body.classList.contains('dark') ? 'light' : 'dark';
        
        applyThemeImmediately(newTheme);

        isChangingTheme = true;
        this.style.pointerEvents = 'none';

        let xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.href + '?theme=' + newTheme, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                }
            }
            isChangingTheme = false;
            document.getElementById('themeIcon').style.pointerEvents = 'auto';
        };
        xhr.send();
    });

    document.querySelectorAll('.icon-container').forEach(function(iconContainer) {
        iconContainer.addEventListener('mouseover', function() {
            iconContainer.querySelector('.tooltip').classList.add('show-tooltip');
        });

        iconContainer.addEventListener('mouseout', function() {
            iconContainer.querySelector('.tooltip').classList.remove('show-tooltip');
        });
    });
</script>
</body>
</html>


