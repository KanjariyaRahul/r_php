<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT a.theme, a.username FROM admin a WHERE a.id = :user_id";
$stmt = getConnection()->prepare($query);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['username'] = $result['username'];

    $is_admin = $_SESSION['role'] === 'admin';
    $theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : ($result['theme'] == 2 ? 'dark' : 'light');

    if (isset($_GET['theme'])) {
        $new_theme = $_GET['theme'];
        $theme_value = ($new_theme == 'dark') ? 2 : 1;
        $update_query = "UPDATE admin SET theme = :theme_value WHERE id = :user_id";
        $update_stmt = getConnection()->prepare($update_query);
        $update_stmt->bindValue(':theme_value', $theme_value, PDO::PARAM_INT);
        $update_stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $update_stmt->execute();

        $_SESSION['theme'] = $new_theme;
        setcookie('theme', $new_theme, time() + 3600, "/");

        echo json_encode(['status' => 'success', 'theme' => $new_theme]);
        exit();
    }
} else {
    die('Error: User not found');
}
ob_end_flush();
?>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        height: 100%;
        display: flex;
        min-height: 100vh;
        flex-direction: column;
    }
    header {
        background-color: #fcfcfc;
        padding: 15px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 100;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    header a {
        color: #333;
        text-decoration: none;
        font-size: 18px;
        margin-right: 20px;
    }

    .logo a {
        color: #333;
        font-size: 24px;
        font-weight: bold;
    }

    .nav-right {
        display: flex;
        margin-right: 45px;
        align-items: center;
        color: #333;
    }

    .username {
        margin-right: 30px;
        font-size: 18px;
        font-weight: bold;
    }

    .theme-icon {
        font-size: 24px;
        cursor: pointer;
    }

    .logout-icon {
        color: #333;
        font-size: 22px;
        margin-right: 20px;
        cursor: pointer;
    }
    .logout-icon:hover{
    color: red;
        font-size: 22px;
        margin-right: 20px;
        cursor: pointer;
    }

    .theme-toggle {
        cursor: pointer;
        display: flex;
        align-items: center;
    }
    .tooltip {
   
        visibility: hidden;
        position: absolute;
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 5px;
        border-radius: 5px;
        z-index: 1;
        font-size: 14px;
        transition: visibility 0.3s;
    }

    .show-tooltip {
        visibility: visible;
    }

    .icon-container {
        position: relative;
    }

    @media (max-width: 768px) {
        header {
            flex-direction: column;
            align-items: flex-start;
        }

        .theme-icon {
            margin-top: 10px;
        }
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<header>
    <div class="logo">
        <a href="index.php">Task Manager</a>
    </div>
    <div class="nav-right">
        <span class="username">Welcome, <?php echo $_SESSION['username']; ?></span>
        <div class="icon-container">
            <a href="auth/logout.php" class="logout-icon"><i class="fas fa-sign-out-alt"></i></a>
        </div>
        <div class="icon-container">
            <div class="theme-toggle" id="themeIcon">
                <span class="theme-icon">
                    <i class="fas fa-moon"></i>
                </span>
            </div>
            <span class="tooltip" style="margin-left: -50px" id="themeTooltip"><?php echo $theme == 'dark' ? 'Light Theme' : 'Dark Theme'; ?></span>
        </div>
    </div>
</header>

<script>
    let isChangingTheme = false;

    function applyThemeImmediately(newTheme) {
        document.body.classList.remove('dark', 'light');
        document.body.classList.add(newTheme);
        document.cookie = "theme=" + newTheme + "; path=/";
        document.getElementById('themeIcon').innerHTML = newTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        document.getElementById('themeTooltip').textContent = newTheme === 'dark' ? 'Light Theme' : 'Dark Theme';
    }

    function setInitialTheme() {
        let theme = '<?php echo $theme; ?>';
        applyThemeImmediately(theme);
    }

    window.onload = function () {
        setInitialTheme();
    };

    document.getElementById('themeIcon').addEventListener('click', function () {
        if (isChangingTheme) return;

        let newTheme = document.body.classList.contains('dark') ? 'light' : 'dark';
        
        applyThemeImmediately(newTheme);

        isChangingTheme = true;
        this.style.pointerEvents = 'none';

        let xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.href + '?theme=' + newTheme, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                }
            }
            isChangingTheme = false;
            document.getElementById('themeIcon').style.pointerEvents = 'auto';
        };
        xhr.send();
    });

    document.querySelectorAll('.icon-container').forEach(function(iconContainer) {
        iconContainer.addEventListener('mouseover', function() {
            iconContainer.querySelector('.tooltip').classList.add('show-tooltip');
        });

        iconContainer.addEventListener('mouseout', function() {
            iconContainer.querySelector('.tooltip').classList.remove('show-tooltip');
        });
    });
</script>
