<style>
footer {
    text-align: center;
    padding: 10px;
    color: #333;
    position: auto;
    margin-top: 10px;
    bottom: 0;
    margin-left: 230px;
    
}
footer p {
    font-size: 14px;
}
body.dark footer {
    color: white;
}
</style>
<footer>
    <p>&copy; <?= date('Y'); ?> Task Manager. All rights reserved.</p>
</footer>