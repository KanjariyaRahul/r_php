<?php
session_start();

if (!isset($_SESSION['admin_permissions'])) {
    header('Location: no_access.php');
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);

if (!in_array($current_page, $_SESSION['admin_permissions'])) {
    header('Location: no_access.php');
    exit();
}

function hasPermission($permission) {
    if (isset($_SESSION['permissions'][$permission]) && $_SESSION['permissions'][$permission]) {
        return true;
    } else {
        return false;
    }
}
?>
