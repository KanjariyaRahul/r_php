<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/connect.php';

$current_page = basename($_SERVER['PHP_SELF'], ".php");
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : (isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light');

if (isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    $_SESSION['theme'] = $theme;
    setcookie('theme', $theme, time() + (86400 * 30), "/"); 
    header("Location: ".$_SERVER['PHP_SELF']); 
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }
        .sidebar {
            height: 100%;
            width: 203.8px;
            color: #ecf0f1;
            position: fixed;
            top: 58px;
            left: 0;
            padding-top: 20px;
            z-index: 100;
            transition: width 0.3s;
            box-shadow: 0px 0px 4px #ddd;
        }

        .sidebar-header {
            text-align: center;
            padding: 10px;
            font-size: 24px;
            font-weight: bold;
            color: #ecf0f1;
        }

        .sidebar-links {
            list-style-type: none;
            padding: 0;
        }

        .sidebar-links li {
            text-align: left;
        }

        .sidebar-links li a {
            padding: 15px;
            color: #000;
            text-decoration: none;
            display: flex;
            align-items: center;
            font-size: 18px;
        }
        body.dark  .sidebar-links li a 
        {
            color : white;
        }
        .sidebar-links li a i {
            margin-right: 10px;
        }

        .sidebar-links li:hover {
            background-color: #34495e;
        }

        .sidebar-links li a:hover {
            color: #bdc3c7;
        }

        .sidebar-links li.active a {
            color: #1abc9c; 
        }
        body.dark  .sidebar-links li.active a 
        {
            color : #1abc9c;
        }
        .main-content {
            margin-left: 235.5px;
            padding: 10px;
            margin-top: 65.9px;
            flex-grow: 1;
            margin-right: 15px;
            transition: background-color 0.3s ease;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 210px;
            }
        }

        @media (max-width: 480px) {
            .sidebar {
                width: 0;
                padding-top: 0;
                display: none;
            }

            .sidebar-header {
                padding: 0;
                font-size: 20px;
            }

            .sidebar-links {
                display: none;
            }
        }
    </style>
</head>
<body class="<?= $theme == 'dark' ? 'dark' : '' ?>">

    <div class="sidebar">
      
        <ul class="sidebar-links">
            <li class="<?= ($current_page == 'index') ? 'active' : ''; ?>"><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li class="<?= ($current_page == 'manage_task') ? 'active' : ''; ?>"><a href="manage_task.php"><i class="fas fa-tasks"></i> Manage Task</a></li>
            <li class="<?= ($current_page == 'manage_user') ? 'active' : ''; ?>"><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <li class="<?= ($current_page == 'user_tasks') ? 'active' : ''; ?>"><a href="user_tasks.php"><i class="fas fa-users"></i>Users Created Task</a></li>
        </ul>
    </div>
</body>
</html>
