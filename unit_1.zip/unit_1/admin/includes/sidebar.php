<?php
include './includes/session.php';
include '../config/connect.php';

$current_page = basename($_SERVER['PHP_SELF'], ".php");
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : (isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light');

if (isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    $_SESSION['theme'] = $theme;
    setcookie('theme', $theme, time() + (86400 * 30), "/"); 
    header("Location: ".$_SERVER['PHP_SELF']); 
    exit;
}

$admin_permissions = isset($_SESSION['admin_permissions']) ? $_SESSION['admin_permissions'] : [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
</head>
<body class="<?= $theme == 'dark' ? 'dark' : '' ?>">

    <div class="sidebar">
        <ul class="sidebar-links">
            <?php if (in_array('index.php', $admin_permissions)): ?>
                <li class="<?= ($current_page == 'index') ? 'active' : ''; ?>"><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <?php endif; ?>
            
            <?php if (in_array('manage_task.php', $admin_permissions)): ?>
                <li class="<?= ($current_page == 'manage_task') ? 'active' : ''; ?>"><a href="manage_task.php"><i class="fas fa-tasks"></i> Manage Task</a></li>
            <?php endif; ?>

            <?php if (in_array('manage_user.php', $admin_permissions)): ?>
                <li class="<?= ($current_page == 'manage_user') ? 'active' : ''; ?>"><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <?php endif; ?>

            <?php if (in_array('user_tasks.php', $admin_permissions)): ?>
                <li class="<?= ($current_page == 'user_tasks') ? 'active' : ''; ?>"><a href="user_tasks.php"><i class="fas fa-users"></i> Users Created Task</a></li>
            <?php endif; ?>
        </ul>
    </div>

</body>
</html>