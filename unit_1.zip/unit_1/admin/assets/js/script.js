// Login form validation
function loginform() {
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let hasErrors = false;

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    return !hasErrors;
}

window.onload = function () {
    let errorMessage = document.getElementById('error-message');
    if (errorMessage) {
        errorMessage.style.display = 'block';
        setTimeout(() => { errorMessage.style.display = 'none'; }, 5000);
    }
    document.querySelectorAll('input[type="text"], input[type="password"]').forEach(function (input) {
        input.addEventListener('input', function () {
            let error = document.getElementById(this.id + '-error');
            if (this.value.trim() !== "") {
                this.classList.remove('invalid');
                error.style.display = 'none';
            }
        });
        input.addEventListener('focus', function () {
            this.classList.remove('invalid');
            let error = document.getElementById(this.id + '-error');
            error.style.display = 'none';
        });

        input.addEventListener('blur', function () {
            if (this.classList.contains('invalid')) {
                setTimeout(() => this.focus(), 1000);
            }
        });
    });
};

// add user  form validation
function adduservalidation() {
    let name = document.getElementById('name');
    let email = document.getElementById('email');
    let phone = document.getElementById('phone');
    let gender = document.querySelector('input[name="gender"]:checked');
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let password_confirm = document.getElementById('password_confirm');

    let nameError = document.getElementById('name-error');
    let emailError = document.getElementById('email-error');
    let phoneError = document.getElementById('phone-error');
    let genderError = document.getElementById('gender-error');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let passwordConfirmError = document.getElementById('password_confirm-error');

    let hasErrors = false;

    if (name.value.trim() === "") {
        name.classList.add('invalid');
        nameError.textContent = "Please enter your full name.";
        nameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => name.focus(), 1000);
        }
        hasErrors = true;
    } else {
        name.classList.remove('invalid');
        nameError.style.display = 'none';
    }

    if (email.value.trim() === "") {
        email.classList.add('invalid');
        emailError.textContent = "Please enter your email address.";
        emailError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => email.focus(), 1000);
        }
        hasErrors = true;
    } else if (!/\S+@\S+\.\S+/.test(email.value)) {
        email.classList.add('invalid');
        emailError.textContent = "Please enter a valid email address (e.g., example@domain.com).";
        emailError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => email.focus(), 1000);
        }
        hasErrors = true;
    } else {
        email.classList.remove('invalid');
        emailError.style.display = 'none';
    }

    if (phone.value.trim() === "") {
        phone.classList.add('invalid');
        phoneError.textContent = "Please enter your phone number.";
        phoneError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => phone.focus(), 1000);
        }
        hasErrors = true;
    } else if (!/^\d{10}$/.test(phone.value)) {
        phone.classList.add('invalid');
        phoneError.textContent = "Please enter a valid 10-digit phone number.";
        phoneError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => phone.focus(), 1000);
        }
        hasErrors = true;
    } else {
        phone.classList.remove('invalid');
        phoneError.style.display = 'none';
    }

    if (!gender) {
        document.querySelectorAll('input[name="gender"]').forEach(function (radio) {
            radio.classList.add('invalid');
        });
        genderError.textContent = "Please select your gender.";
        genderError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => document.querySelector('input[name="gender"]').focus(), 1000);
        }
        hasErrors = true;
    } else {
        document.querySelectorAll('input[name="gender"]').forEach(function (radio) {
            radio.classList.remove('invalid');
        });
        genderError.style.display = 'none';
    }

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.textContent = "Please enter a username.";
        usernameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.textContent = "Please enter a password.";
        passwordError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    if (password_confirm.value.trim() === "") {
        password_confirm.classList.add('invalid');
        passwordConfirmError.textContent = "Please confirm your password.";
        passwordConfirmError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password_confirm.focus(), 1000);
        }
        hasErrors = true;
    } else if (password.value !== password_confirm.value) {
        password_confirm.classList.add('invalid');
        passwordConfirmError.textContent = "Passwords do not match.";
        passwordConfirmError.style.display = 'block';
        hasErrors = true;
    } else {
        password_confirm.classList.remove('invalid');
        passwordConfirmError.style.display = 'none';
    }

    return !hasErrors;
}

document.querySelectorAll('input[type="text"], input[type="password"] , input[type="select"], input[type="textarea"] , input[type="radio"]').forEach(function (input) {
    input.addEventListener('input', function () {
        let error = document.getElementById(this.id + '-error');
        if (this.value.trim() !== "" || (this.type === 'radio' && document.querySelector('input[name="gender"]:checked'))) {
            this.classList.remove('invalid');
            error.style.display = 'none';
        }
    });
    input.addEventListener('focus', function () {
        this.classList.remove('invalid');
        let error = document.getElementById(this.id + '-error');
        error.style.display = 'none';
    });

    input.addEventListener('blur', function () {
        if (this.classList.contains('invalid')) {
            setTimeout(() => this.focus(), 1000);
        }
    });
});
//add task validation 
function addtaskform(event) {
    event.preventDefault();
    let user_id = document.getElementById('user_id');
    let title = document.getElementById('title');
    let description = document.getElementById('description');
    let due_date = document.getElementById('due_date');
    let time_limit = document.getElementById('time_limit');
    let priority = document.querySelector('input[name="priority"]:checked');
    
    let user_idError = document.getElementById('user_id-error');
    let titleError = document.getElementById('title-error');
    let descriptionError = document.getElementById('description-error');
    let due_dateError = document.getElementById('due_date-error');
    let time_limitError = document.getElementById('time_limit-error');
    let priorityError = document.getElementById('priority-error');
    
    let hasErrors = false;
    let firstErrorElement = null;

    if (!user_id.value.trim()) {
        user_id.classList.add('invalid');
        user_idError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = user_id;
        }
        hasErrors = true;
    } else {
        user_id.classList.remove('invalid');
        user_idError.style.display = 'none';
    }

    if (title.value.trim() === "") {
        title.classList.add('invalid');
        titleError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = title;
        }
        hasErrors = true;
    } else {
        title.classList.remove('invalid');
        titleError.style.display = 'none';
    }

    if (description.value.trim() === "") {
        description.classList.add('invalid');
        descriptionError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = description;
        }
        hasErrors = true;
    } else {
        description.classList.remove('invalid');
        descriptionError.style.display = 'none';
    }

    if (!due_date.value.trim()) {
        due_date.classList.add('invalid');
        due_dateError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = due_date;
        }
        hasErrors = true;
    } else {
        due_date.classList.remove('invalid');
        due_dateError.style.display = 'none';
    }

    if (!time_limit.value.trim()) {
        time_limit.classList.add('invalid');
        time_limitError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = time_limit;
        }
        hasErrors = true;
    } else {
        time_limit.classList.remove('invalid');
        time_limitError.style.display = 'none';
    }

    if (!priority) {
        priorityError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = document.querySelector('input[name="priority"]');
        }
        hasErrors = true;
    } else {
        priorityError.style.display = 'none';
    }

    if (!hasErrors) {
        document.getElementById('taskForm').submit();
    }

    // If there are errors, focus on the first error element
    if (firstErrorElement) {
        setTimeout(() => firstErrorElement.focus(), 500);
    }

    return !hasErrors;
}



window.onload = function () {
    document.querySelectorAll('input[type="text"], input[type="file"], input[type="date"], input[type="time"], textarea , select').forEach(function (input) {
        input.addEventListener('input', function () {
            let error = document.getElementById(this.id + '-error');
            if (this.value.trim() !== "") {
                this.classList.remove('invalid');
                error.style.display = 'none';
            }
        });
        input.addEventListener('focus', function () {
            this.classList.remove('invalid');
            let error = document.getElementById(this.id + '-error');
            error.style.display = 'none';
        });

        input.addEventListener('blur', function () {
        if (this.classList.contains('invalid')) {
            setTimeout(() => this.focus(), 1000);      
        }
    });
    });

    document.querySelectorAll('input[name="priority"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            let error = document.getElementById('priority-error');
            error.style.display = 'none';
        });
    });
};


//manage_task page 
document.addEventListener('DOMContentLoaded', function () {
    function openModal(taskId) {
        document.getElementById('task-modal').style.display = 'flex';
        fetchTaskDetails(taskId);
    }

    document.getElementById('closeModal').addEventListener('click', function () {
        document.getElementById('task-modal').style.display = 'none';
    });
    function fetchTaskDetails(taskId) {
        const taskDetailsElement = document.getElementById('task-details');
        fetch('task_details.php?task_id=' + taskId)
            .then(response => response.json())
            .then(data => {
                if (data.details) {
                    let statusText = '';
                    if (data.details.status == 1) {
                        statusText = 'Padding';
                    } else if (data.details.status == 2 || data.details.status == 3) {
                        statusText = 'in-progress';
                    } else if (data.details.status == 4) {
                        statusText = 'Completed';
                    }

                    taskDetailsElement.innerHTML = `
                                <p><strong>Task Id :</strong> ${data.details.id}</p>
                                <p><strong>Title:</strong> ${data.details.title}</p>
                                <p><strong>Description:</strong> ${data.details.description}</p>
                                <p><strong>Due Date:</strong> ${data.details.due_date}</p>
                                <p><strong>Status:</strong> <span class="status-${statusText}">${statusText}</span></p>
                                <p><strong>Time Limit:</strong> ${secondsToTime(data.details.time_limit)}</p>
                                <p><strong>Time Worked:</strong> ${secondsToTime(data.details.total_time)}</p>
                            `;
                } else if (data.error) {
                    taskDetailsElement.innerHTML = `<p>${data.error}</p>`;
                }
            })
            .catch(error => console.error('Error fetching task details:', error));
    }

    document.querySelectorAll('.view-task-details').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const taskId = event.target.getAttribute('data-task-id');
            openModal(taskId);
        });
    });

    function secondsToTime(seconds) {
        var hours = Math.floor(seconds / 3600);
        var minutes = Math.floor((seconds % 3600) / 60);
        var seconds = seconds % 60;
        return hours.toString().padStart(2, '0') + ':' + minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');
    }
});

function adduservalidation() {
    let name = document.getElementById('name');
    let email = document.getElementById('email');
    let phone = document.getElementById('phone');
    let gender = document.querySelector('input[name="gender"]:checked');
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let password_confirm = document.getElementById('password_confirm');
    
    let nameError = document.getElementById('name-error');
    let emailError = document.getElementById('email-error');
    let phoneError = document.getElementById('phone-error');
    let genderError = document.getElementById('gender-error');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let password_confirmError = document.getElementById('password_confirm-error');

    let hasErrors = false;

    if (name.value.trim() === "") {
        name.classList.add('invalid');
        nameError.style.display = 'block';
        nameError.textContent = "Please enter name";
        if (!hasErrors) {
            setTimeout(() => name.focus(), 1000);
        }
        hasErrors = true;
    } else {
        name.classList.remove('invalid');
        nameError.style.display = 'none';
    }

    if (email.value.trim() === "") {
        email.classList.add('invalid');
        emailError.style.display = 'block';
        emailError.textContent = "Please enter email";
        if (!hasErrors) {
            setTimeout(() => email.focus(), 1000);
        }
        hasErrors = true;
    } else {
        email.classList.remove('invalid');
        emailError.style.display = 'none';
    }

    if (phone.value.trim() === "") {
        phone.classList.add('invalid');
        phoneError.style.display = 'block';
        phoneError.textContent = "Please enter phone number";
        if (!hasErrors) {
            setTimeout(() => phone.focus(), 1000);
        }
        hasErrors = true;
    } else {
        phone.classList.remove('invalid');
        phoneError.style.display = 'none';
    }

    if (!gender) {
        genderError.style.display = 'block';
        genderError.textContent = "Please select gender";
        hasErrors = true;
    } else {
        genderError.style.display = 'none';
    }

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.style.display = 'block';
        usernameError.textContent = "Please enter username";
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.style.display = 'block';
        passwordError.textContent = "Please enter password";
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    if (password_confirm.value.trim() === "" || password.value !== password_confirm.value) {
        password_confirm.classList.add('invalid');
        password_confirmError.style.display = 'block';
        password_confirmError.textContent = "Passwords do not match or confirm password is empty";
        if (!hasErrors) {
            setTimeout(() => password_confirm.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password_confirm.classList.remove('invalid');
        password_confirmError.style.display = 'none';
    }

    return !hasErrors;
}
