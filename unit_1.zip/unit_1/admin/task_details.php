<?php
include '../config/connect.php';
include '../config/function_config.php';

if (isset($_GET['task_id'])) {
    $taskId = (int) $_GET['task_id'];
    
    $taskQuery = "SELECT * FROM task WHERE id = :task_id";
    $stmt = rpt_prepare($taskQuery);
    rpt_bindValue($stmt, ':task_id', $taskId, PDO::PARAM_INT);
    $stmt->execute();
    $taskDetails = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($taskDetails) {
        echo json_encode([
            'details' => $taskDetails,
        ]);
    } else {
        echo json_encode([
            'error' => 'Task not found',
        ]);
    }
} else {
    echo json_encode([
        'error' => 'No task ID provided',
    ]);
}
?>


