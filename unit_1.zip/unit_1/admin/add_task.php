
<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once "../config/connect.php";
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: auth/login.php');
    exit();
}
$admin_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $due_date = $_POST['due_date'];
    $time_limit = $_POST['time_limit'] ?? '00:00';
    $user_id = $_POST['user_id'];
    $priority = $_POST['priority'];
    $attachment = $_FILES['attachment']['name'];

    if ($time_limit == "00:00") {
        $time_limit_seconds = 0;
    } else {
        $time_parts = explode(":", $time_limit);
        $time_limit_seconds = ($time_parts[0] * 3600) + ($time_parts[1] * 60) + (isset($time_parts[2]) ? $time_parts[2] : 0);
    }

    $file_query_part = '';
    if ($attachment) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'doc', 'odt', 'pdf'];
        $file_extension = pathinfo($attachment, PATHINFO_EXTENSION);
        if (!in_array(strtolower($file_extension), $allowedExtensions)) {
            echo "<script>alert('Invalid file type.');</script>";
            return;
        }
        $unique_name = uniqid() . '.' . $file_extension;
        $target_file = "uploads/" . $unique_name;
        move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file);
        $file_query_part = ", attachment=:attachment";
    }

    if (isset($_GET['id'])) {
        $task_id = $_GET['id'];
        $query = "UPDATE task SET 
                    title=:title, 
                    description=:description, 
                    due_date=:due_date, 
                    time_limit=:time_limit, 
                    user_id=:user_id, 
                    priority=:priority" . $file_query_part . ", assigned_by=:assigned_by 
                  WHERE id=:task_id";
        $stmt = rpt_prepare($query);
        rpt_bindValue($stmt, ':task_id', $task_id, PDO::PARAM_INT);
    } else {
        $query = "INSERT INTO task (title, description, due_date, time_limit, user_id, assigned_by, priority" . $file_query_part . ") 
                  VALUES (:title, :description, :due_date, :time_limit, :user_id, :assigned_by, :priority" . $file_query_part . ")";
        $stmt = rpt_prepare($query);
    }

    rpt_bindValue($stmt, ':title', $title);
    rpt_bindValue($stmt, ':description', $description);
    rpt_bindValue($stmt, ':due_date', $due_date);
    rpt_bindValue($stmt, ':time_limit', $time_limit_seconds, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':user_id', $user_id, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':assigned_by', $admin_id, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':priority', $priority, PDO::PARAM_INT);
    
    if ($attachment) {
        rpt_bindValue($stmt, ':attachment', $unique_name);
    }

    $stmt->execute();

    if (isset($_GET['id'])) {
        header("Location: manage_task.php?msg=2");
    } else {
        header("Location: add_task.php?msg=1");
    }
    exit();
}

$query = "SELECT * FROM users";
$users_result = fetchData($query);

if (isset($_GET['id'])) {
    $task_id = $_GET['id'];
    $query = "SELECT * FROM task WHERE id = :task_id";
    $stmt = rpt_prepare($query);
    rpt_bindValue($stmt, ':task_id', $task_id, PDO::PARAM_INT);
    $stmt->execute();
    $task = $stmt->fetch(PDO::FETCH_ASSOC);

    $title = $task['title'];
    $description = $task['description'];
    $due_date = $task['due_date'];
    $time_limit = $task['time_limit'];
    $user_id = $task['user_id'];
    $priority = $task['priority'];
    $attachment = $task['attachment'];
} else {
    $title = '';
    $description = '';
    $due_date = '';
    $time_limit = 0;
    $user_id = '';
    $priority = 2;
    $attachment = '';
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

$hours = floor($time_limit / 3600);
$minutes = floor(($time_limit % 3600) / 60);
$seconds = $time_limit % 60;

ob_end_flush();
?>

    
    <title><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</title>     
    <style>         
        body {             
            display: flex;             
            flex-direction: column;             
            min-height: 100vh;         
        }   
         body.light {
        color: #333;
    }

    body.dark {
        background-color: #2a2a2a;
        color: #f7f7f7;
    }       
        h1 {             
            margin-bottom: 20px;             
            font-size: 24px;         
        } 
        .message {
            padding: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
        }

        .success {
            background-color: rgb(100, 185, 103);
            color: white;
        }         
        form {             
               display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    width: 100%;             
        }          
        .form-group {             
            flex: 1 1 45%;             
            display: flex;             
            flex-direction: column;             
        }          
        label {             
            font-weight: bold;         
        }          
        input,         
        textarea,         
        select {             
            margin-top: 8px;             
            padding: 12px;             
            margin-bottom: 16px;             
            border-radius: 4px;             
            border: 1px solid #ddd;             
            font-size: 14px;             
            width: 100%;         
        }          
        input[type="file"] {             
            margin-bottom: 10px;         
        }          
        input:focus,         
        textarea:focus,         
        select:focus {             
            border-color: #4f7092;             
            outline: none;         
        } 
        .priority-wrapper {
            display: flex;
            gap: 10px;
            font-size: 18
            margin-bottom: 16px;
            grid-column: span 2;
        }
        .priority-wrapper label {
            cursor: pointer;
            gap: 5px;
            display: flex;
            align-items: center;
            font-weight: normal;
        }     
        .priority-wrapper input {
           margin-top: 15px;
        }     
          button {
            padding: 12px;
            background-color: #4f7092;
            color: white;
            border: none;
            width: 20%;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            grid-column: span 2;
        }
        button:hover {
            background-color: #435975;
        }         
        .error {             
            border-color: red !important;             
            scroll-margin-top: 90px;   
             color: red;      
        } 
        .invalid {
        border: 2px solid red !important;
    }
   
                 
        @media (max-width: 768px) {             
            form {                 
                flex-direction: column;                 
            }               
            .form-group {                 
                flex: 1 1 100%;             
            }               
            button {                 
                font-size: 14px;                 
                padding: 10px 15px;             
            }               
            input,             
            textarea {                 
                font-size: 12px;             
            }         
        }     
    </style> 
</head>  

   
    <div class="main-content">         
        <h1><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</h1>   
         <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
             <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>      
        <form id="taskForm" method="POST" enctype="multipart/form-data">             
            <div class="form-group">                 
                <label for="user_id">Assigned User</label>                 
                <select name="user_id" id="user_id">                     
                    <option value="">Select a User</option>                     
                    <?php foreach ($users_result as $user): ?>                         
                        <option value="<?php echo $user['id']; ?>" <?php echo $user_id == $user['id'] ? 'selected' : ''; ?>>                         
                            <?php echo htmlspecialchars($user['username']); ?>                         
                        </option>                     
                    <?php endforeach; ?>             
                </select>             
            </div>              

            <div class="form-group">                 
                <label for="title">Title</label>                 
                <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($title); ?>" placeholder="Enter task title">             
            </div>              

            <div class="form-group">                 
                <label for="description">Description</label>                 
                <textarea name="description" id="description" placeholder="Enter task description"><?php echo htmlspecialchars($description); ?></textarea>             
            </div>              

            <div class="form-group">                 
                <label for="due_date">Due Date</label>                 
                <input type="date" name="due_date" id="due_date" value="<?php echo htmlspecialchars($due_date); ?>" min="<?php echo date('Y-m-d'); ?>">             
            </div>              

            <div class="form-group">                 
                <label for="time_limit">Time Limit</label>                 
                <input type="time" name="time_limit" id="time_limit" value="<?php echo str_pad($hours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ':' . str_pad($seconds, 2, '0', STR_PAD_LEFT); ?>" />             
            </div>              

            <div class="form-group" >                 
                <label for="priority">Priority</label>                 
                <div class="priority-wrapper">
                <label for="low">
                    <input type="radio" id="low" name="priority" value="1" <?php echo $priority == 1 ? 'checked' : ''; ?>> Low
                </label>
                <label for="medium">
                    <input type="radio" id="medium" name="priority" value="2" <?php echo $priority == 2 ? 'checked' : ''; ?>> Medium
                </label>
                <label for="high">
                    <input type="radio" id="high" name="priority" value="3" <?php echo $priority == 3 ? 'checked' : ''; ?>> High
                </label>
                </div>             
            </div>              

            <div class="form-group">                 
                <label for="attachment">Attachment</label>                 
                <input type="file" name="attachment" id="attachment" accept=".jpg,.jpeg,.png,.doc,.odt,.pdf">             
            </div>              

            <?php if ($attachment): ?>                 
                <p>Current file: <?php echo htmlspecialchars($attachment); ?></p>             
            <?php endif; ?>              

            <button type="submit"><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</button>         
        </form>     
    </div>      
   <script>
function validateTaskForm() {
    let hasErrors = false;

    
    let user = document.getElementById('user_id');
    let userError = document.createElement('div');
    userError.className = 'error';
    userError.innerText = 'Please select a user';
    if (user.value.trim() === "") {
        if (!user.nextElementSibling) user.parentNode.appendChild(userError);
        user.classList.add('invalid');
        if (!hasErrors) {
            setTimeout(() => user.focus(), 1000);
        }
        hasErrors = true;
    } else {
        user.classList.remove('invalid');
        if (user.nextElementSibling) user.nextElementSibling.remove();
    }


    let title = document.getElementById('title');
    let titleError = document.createElement('div');
    titleError.className = 'error';
    titleError.innerText = 'Title is required';
    if (title.value.trim() === "") {
        if (!title.nextElementSibling) title.parentNode.appendChild(titleError);
        title.classList.add('invalid');
        if (!hasErrors) {
            setTimeout(() => title.focus(), 1000);
        }
        hasErrors = true;
    } else {
        title.classList.remove('invalid');
        if (title.nextElementSibling) title.nextElementSibling.remove();
    }

   
    let description = document.getElementById('description');
    let descriptionError = document.createElement('div');
    descriptionError.className = 'error';
    descriptionError.innerText = 'Description is required';
    if (description.value.trim() === "") {
        if (!description.nextElementSibling) description.parentNode.appendChild(descriptionError);
        description.classList.add('invalid');
        if (!hasErrors) {
            setTimeout(() => description.focus(), 1000);
        }
        hasErrors = true;
    } else {
        description.classList.remove('invalid');
        if (description.nextElementSibling) description.nextElementSibling.remove();
    }

    let dueDate = document.getElementById('due_date');
    let dueDateError = document.createElement('div');
    dueDateError.className = 'error';
    dueDateError.innerText = 'Due date is required';
    if (dueDate.value.trim() === "") {
        if (!dueDate.nextElementSibling) dueDate.parentNode.appendChild(dueDateError);
        dueDate.classList.add('invalid');
        if (!hasErrors) {
            setTimeout(() => dueDate.focus(), 1000);
        }
        hasErrors = true;
    } else {
        dueDate.classList.remove('invalid');
        if (dueDate.nextElementSibling) dueDate.nextElementSibling.remove();
    }

    
    let timeLimit = document.getElementById('time_limit');
    let timeLimitError = document.createElement('div');
    timeLimitError.className = 'error';
    timeLimitError.innerText = 'Time limit is required';
    if (timeLimit.value.trim() === "") {
        if (!timeLimit.nextElementSibling) timeLimit.parentNode.appendChild(timeLimitError);
        timeLimit.classList.add('invalid');
        if (!hasErrors) {
            setTimeout(() => timeLimit.focus(), 1000);
        }
        hasErrors = true;
    } else {
        timeLimit.classList.remove('invalid');
        if (timeLimit.nextElementSibling) timeLimit.nextElementSibling.remove();
    }

    let priority = document.querySelectorAll('input[name="priority"]');
    let priorityChecked = false;
    priority.forEach(function (radio) {
        if (radio.checked) {
            priorityChecked = true;
        }
    });

    if (!priorityChecked) {
        alert("Please select a priority");
        hasErrors = true;
    }

    return !hasErrors;
}

document.querySelectorAll('input, select, textarea').forEach(function (input) {
    input.addEventListener('input', function () {
        this.classList.remove('invalid');
        if (this.nextElementSibling && this.nextElementSibling.classList.contains('error')) {
            this.nextElementSibling.remove();
        }
    });

    input.addEventListener('focus', function () {
        this.classList.remove('invalid');
        if (this.nextElementSibling && this.nextElementSibling.classList.contains('error')) {
            this.nextElementSibling.remove();
        }
    });

    input.addEventListener('blur', function () {
        if (this.classList.contains('invalid')) {
            setTimeout(() => this.focus(), 1000);      
        } 
    });
});

document.getElementById('taskForm').onsubmit = function () {
    return validateTaskForm();
};
</script>
 

<?php include 'includes/footer.php'; ?>
