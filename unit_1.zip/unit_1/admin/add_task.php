<?php
include 'includes/permission_check.php';
include 'includes/session.php';
include_once "../config/connect.php";
include_once "../config/function_config.php";
include 'includes/navbar.php';
include 'includes/sidebar.php';

$admin_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $due_date = $_POST['due_date'];
    $time_limit = $_POST['time_limit'] ?? '00:00';
    $user_id = $_POST['user_id'];
    $priority = $_POST['priority'];
    $attachment = $_FILES['attachment']['name'];

    if (!hasPermission('can_add_task')) {
        $permission_error_msg = 'You do not have permission to add a task.';
    }

    if ($time_limit == "00:00") {
        $time_limit_seconds = 0;
    } else {
        $time_parts = explode(":", $time_limit);
        $time_limit_seconds = ($time_parts[0] * 3600) + ($time_parts[1] * 60) + (isset($time_parts[2]) ? $time_parts[2] : 0);
    }

    $file_query_part = '';
    if ($attachment) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'doc', 'odt', 'pdf'];
        $file_extension = pathinfo($attachment, PATHINFO_EXTENSION);
        if (!in_array(strtolower($file_extension), $allowedExtensions)) {
            echo "<script>alert('Invalid file type.');</script>";
            return;
        }
        $unique_name = uniqid() . '.' . $file_extension;
        $target_file = "uploads/" . $unique_name;
        move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file);
        $file_query_part = ", attachment=:attachment";
    }

    if (isset($_GET['id'])) {
        if (!hasPermission('can_edit_task')) {
            $permission_error_msg = 'You do not have permission to edit a task.';
        }
        $task_id = $_GET['id'];
        $query = "UPDATE task SET 
                    title=:title, 
                    description=:description, 
                    due_date=:due_date, 
                    time_limit=:time_limit, 
                    user_id=:user_id, 
                    priority=:priority" . $file_query_part . ", assigned_by=:assigned_by 
                  WHERE id=:task_id";
        $stmt = rpt_prepare($query);
        rpt_bindValue($stmt, ':task_id', $task_id, PDO::PARAM_INT);
    } else {
        $query = "INSERT INTO task (title, description, due_date, time_limit, user_id, assigned_by, priority" . $file_query_part . ") 
                  VALUES (:title, :description, :due_date, :time_limit, :user_id, :assigned_by, :priority" . $file_query_part . ")";
        $stmt = rpt_prepare($query);
    }

    rpt_bindValue($stmt, ':title', $title);
    rpt_bindValue($stmt, ':description', $description);
    rpt_bindValue($stmt, ':due_date', $due_date);
    rpt_bindValue($stmt, ':time_limit', $time_limit_seconds, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':user_id', $user_id, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':assigned_by', $admin_id, PDO::PARAM_INT);
    rpt_bindValue($stmt, ':priority', $priority, PDO::PARAM_INT);
    
    if ($attachment) {
        rpt_bindValue($stmt, ':attachment', $unique_name);
    }
    $stmt->execute();

    if (isset($_GET['id'])) {
        header("Location: manage_task.php?msg=2");
    } else {
        header("Location: add_task.php?msg=1");
    }
    exit();
}

$query = "SELECT * FROM users";
$users_result = rpt_fetchData($query);

if (isset($_GET['id'])) {
    $task_id = $_GET['id'];
    $query = "SELECT * FROM task WHERE id = :task_id";
    $stmt = rpt_prepare($query);
    rpt_bindValue($stmt, ':task_id', $task_id, PDO::PARAM_INT);
    $stmt->execute();
    $task = $stmt->fetch(PDO::FETCH_ASSOC);

    $title = $task['title'];
    $description = $task['description'];
    $due_date = $task['due_date'];
    $time_limit = $task['time_limit'];
    $user_id = $task['user_id'];
    $priority = $task['priority'];
    $attachment = $task['attachment'];
} else {
    $title = '';
    $description = '';
    $due_date = '';
    $time_limit = 0;
    $user_id = '';
    $priority = 2;
    $attachment = '';
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

$hours = floor($time_limit / 3600);
$minutes = floor(($time_limit % 3600) / 60);
$seconds = $time_limit % 60;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</title>    
    <script src="./assets/js/script.js"></script> 
</head>
<body>
    <div class="main-content">         
        <h3><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</h3>   
         <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
             <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>      
        <form id="taskForm" class="task-form" method="POST" enctype="multipart/form-data" onsubmit="addtaskform(event)">             
    <div class="form-group">                 
        <label for="user_id">Assigned User</label>                 
        <select name="user_id" id="user_id" class="task-input">                     
            <option value="">Select a User</option>                     
            <?php foreach ($users_result as $user): ?>                         
                <option value="<?php echo $user['id']; ?>" <?php echo $user_id == $user['id'] ? 'selected' : ''; ?>>                         
                    <?php echo htmlspecialchars($user['username']); ?>                         
                </option>                     
            <?php endforeach; ?>             
        </select>             
        <span id="user_id-error" class="error-message">Please select a user</span>
    </div>              

    <div class="form-group">                 
        <label for="title">Title</label>                 
        <input type="text" class="task-input" name="title" id="title" value="<?php echo htmlspecialchars($title); ?>" placeholder="Enter task title">             
        <span id="title-error" class="error-message">Please enter title</span>
    </div>              

    <div class="form-group">                 
        <label for="description">Description</label>                 
        <textarea name="description" class="task-input" id="description" placeholder="Enter task description"><?php echo htmlspecialchars($description); ?></textarea>           
        <span id="description-error" class="error-message">Please enter description</span>
    </div>              

    <div class="form-group">                 
        <label for="due_date">Due Date</label>                 
        <input type="date" class="task-input" name="due_date" id="due_date" value="<?php echo htmlspecialchars($due_date); ?>" min="<?php echo date('Y-m-d'); ?>">         
        <span id="due_date-error" class="error-message">Please enter due date</span>
    </div>              

    <div class="form-group">                 
        <label for="time_limit">Time Limit</label>                 
        <input type="time" class="task-input" name="time_limit" id="time_limit" value="<?php echo str_pad($hours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ':' . str_pad($seconds, 2, '0', STR_PAD_LEFT); ?>" />    
        <span id="time_limit-error" class="error-message">Please enter time limit</span>
    </div>              

    <div class="form-group">                 
        <label for="priority">Priority</label>                 
        <div class="priority-wrapper">
            <label for="low">
                <input type="radio" class="task-input" id="low" name="priority" value="1" <?php echo $priority == 1 ? 'checked' : ''; ?>> Low
            </label>
            <label for="medium">
                <input type="radio" class="task-input" id="medium" name="priority" value="2" <?php echo $priority == 2 ? 'checked' : ''; ?>> Medium
            </label>
            <label for="high">
                <input type="radio" class="task-input" id="high" name="priority" value="3" <?php echo $priority == 3 ? 'checked' : ''; ?>> High
            </label>
        </div>             
        <span id="priority-error" class="error-message">Please select priority</span>
    </div>              

    <div class="form-group">                 
        <label for="attachment">Attachment</label>                 
        <input type="file" class="task-input" name="attachment" id="attachment" accept=".jpg,.jpeg,.png,.doc,.odt,.pdf">             
        <?php if ($attachment): ?>                 
            <p style="margin: 0px; font-weight: bold;">Current file: <?php echo htmlspecialchars($attachment); ?></p>             
        <?php endif; ?>              
    </div>             
    <div class="button-container">
        <button type="submit" class="btn-task"><?php echo isset($task_id) ? 'Update' : 'Add'; ?> Task</button>         
    </div>
</form>    
    </div>   
 </body>
 </html>

<?php include 'includes/footer.php'; ?>