<?php
include 'includes/session.php';      
include_once '../config/connect.php'; 
include_once '../config/function_config.php'; 
include 'includes/navbar.php';      
include 'includes/sidebar.php';  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>No Access</title>
</head>
<body>
    <div class="access-content">
        <div class="no-access">
        <img src="./image/no-access.jpg" alt="Access Denied" class="error-img">
        <h1 class="sorry">Sorry!</h1>
        <p>You do not have permission to access this page.</p>
        <a href="index.php" class="add-task-button"><i class="fas fa-arrow-left"></i> Go back to Dashboard</a>
        </div>
    </div>

</body>
</html>
