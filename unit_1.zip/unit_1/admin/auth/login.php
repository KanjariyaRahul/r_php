<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once '../../config/connect.php'; 

$error_message = '';

if (isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])) {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT id, username, password, theme FROM admin WHERE username = ?";

    $conn = getConnection(); 

    $stmt = $conn->prepare($query);
    $stmt->bindValue(1, $username, PDO::PARAM_STR);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        if ($password == $result['password']) {
            $_SESSION['user_id'] = $result['id'];
            $_SESSION['username'] = $username;
            $_SESSION['theme'] = $result['theme'];
            $_SESSION['role'] = 'admin';

            if (isset($_POST['remember'])) {
                setcookie('user_id', $result['id'], time() + 86400, "/");
                setcookie('user', $username, time() + 86400, "/");
                setcookie('theme', $result['theme'], time() + 86400, "/");
            }

            header('Location: ../index.php');
            exit();
        } else {
            $_SESSION['error_message'] = 'The password you entered is incorrect. Please try again.';
        }
    } else {
        $_SESSION['error_message'] = 'The username you entered does not exist. Please check and try again.';
    }
}
ob_end_flush();
?>
    

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f7fa;
        }

        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            font-size: 28px;
            padding: 0px;
            margin: 0px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        input[type="text"].invalid,
        input[type="password"].invalid {
            border-color: red;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        .remember-me {
            font-size: 14px;
            color: #555;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #34495e;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(23, 35, 48);
        }

        .alert {
            color: red;
            text-align: center;
            margin-bottom: 12px;
        }

        .error-message {
            margin: 5px;
            color: red;
            font-size: 12px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div style="margin-bottom: 30px;">
            <h2>Welcome Back!</h2>
            <p style="font-size: 12px;">Please Enter admin login details below</p>
        </div>
        
        <?php if (isset($_SESSION['error_message']) && !empty($_SESSION['error_message'])): ?>
            <div class="alert"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>
        
        <form action="" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder="Enter your username">
                <span id="username-error" class="error-message">Please enter a valid username.</span>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter your password">
                <span id="password-error" class="error-message">Please enter a valid password.</span>
            </div>

            <div class="form-group">
                <label class="remember-me">
                    <input type="checkbox" name="remember" id="remember"> Remember me
                </label>
            </div>

            <button type="submit">Sign In</button>
        </form>
    
    </div>
<script>
function validateForm() {
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let hasErrors = false;

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    return !hasErrors;
}
 window.onload = function () {
            let errorMessage = document.getElementById('error-message');
            if (errorMessage) {
                errorMessage.style.display = 'block';
                setTimeout(() => { errorMessage.style.display = 'none'; }, 5000);
            }
        };
document.querySelectorAll('input[type="text"], input[type="password"]').forEach(function (input) {
    input.addEventListener('input', function () {
        let error = document.getElementById(this.id + '-error');
        if (this.value.trim() !== "") {
            this.classList.remove('invalid');
            error.style.display = 'none';
        }
    });

    input.addEventListener('focus', function () {
        this.classList.remove('invalid');
        let error = document.getElementById(this.id + '-error');
        error.style.display = 'none';
    });

    input.addEventListener('blur', function () {
        if (this.classList.contains('invalid')) {
            setTimeout(() => this.focus(), 1000);
        }
    });
});
</script>
</body>
</html>
