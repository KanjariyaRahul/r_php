<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['user_id']) || isset($_COOKIE['user_id'])) {
    header('Location: ../index.php');
    exit();
}
include_once '../../config/connect.php';

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT id, username, password, theme FROM admin WHERE username = ?";

    global  $conn ;

    $stmt = $conn->prepare($query);
    $stmt->bindValue(1, $username, PDO::PARAM_STR);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        if ($password == $result['password']) {
            $_SESSION['user_id'] = $result['id'];
            $_SESSION['username'] = $username;
            $_SESSION['theme'] = $result['theme'];
            $_SESSION['role'] = 'admin';

            $_SESSION['admin_permissions'] = [
                'add_task.php',
                'manage_task.php',
                'index.php',
                'user_tasks.php',
                'manage_user.php',
                'add_user.php',
                'task_details.php',
            ];

            $_SESSION['permissions'] = [
                'can_add_user' => false,
                'can_edit_user' => true,
                'can_delete_user' => true,

                'can_add_task' => true,
                'can_edit_task' => true,
                'can_delete_task' => true,

                'can_user_created_task_view' => true,  
                'can_user_created_task_delete' => false,  
            ];

            if (isset($_POST['remember'])) {
                setcookie('user_id', $result['id'], time() + 86400, "/");
                setcookie('user', $username, time() + 86400, "/");
                setcookie('theme', $result['theme'], time() + 86400, "/");
            }

            header('Location: ../index.php');
            exit();
        } else {
            $error_message = 'The password you entered is incorrect. Please try again.';
        }
    } else {
        $error_message = 'The username you entered does not exist. Please check and try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/script.js"></script>
</head>
<body>
    <div class="login-container">
        <div style="margin-bottom: 30px;">
            <h2>Welcome Back!</h2>
            <p style="font-size: 12px;">Please Enter login details below</p>
        </div>
        <?php if (!empty($error_message)): ?>
            <div class="alert" id="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form action="" class="login-form" method="post" onsubmit="return loginform()">
            <div>
                <label for="username">Username</label>
                <input type="text" class="login-input" name="username" id="username"  placeholder="Enter your username">
                <span id="username-error" class="error-message">Please enter username</span>
            </div>

            <div>
                <label for="password">Password</label>
                <input type="password" class="login-input" name="password" id="password" placeholder="Enter your password">
                <span id="password-error" class="error-message">Please enter password</span>
            </div>

            <div class="">
                <label class="remember-me">
                    <input type="checkbox" class="login-checbox" name="remember" id="remember"> Remember me
                </label>
            </div>

            <button type="submit" class="login-btn">Sign In</button>
        </form>

        <div class="register-link">
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</body>
</html>
