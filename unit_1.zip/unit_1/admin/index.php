<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/connect.php';
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: admin/auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = fetchData("SELECT * FROM admin WHERE id = ?", [$user_id]);
$user = $query ? $query[0] : null;

$task_query = fetchData("
    SELECT 
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COUNT(*) FROM task) AS total_tasks,
        COUNT(CASE WHEN status = '4' THEN 1 END) AS completed_tasks,
        COUNT(CASE WHEN status = '1' THEN 1 END) AS pending_tasks,
        COUNT(CASE WHEN status IN ('2', '3') THEN 1 END) AS in_progress
    FROM task
");

if ($task_query) {
    $task_data = $task_query[0];

    $total_users = $task_data['total_users'] ?? 0;
    $total_tasks = $task_data['total_tasks'] ?? 0;
    $completed_tasks = $task_data['completed_tasks'] ?? 0;
    $pending_tasks = $task_data['pending_tasks'] ?? 0;
    $in_progress = $task_data['in_progress'] ?? 0;
} else {
    $total_users = $total_tasks = $completed_tasks = $pending_tasks = $in_progress = 0;
}
?>





<style>
    .dashboard {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: space-between;
    }

    body.light {
        color: #333;
    }

    body.dark {
        background-color: #2a2a2a;
        color: #f7f7f7;
    }

    h2 {
        font-size: 25px;
    }

    .card {
        border-radius: 10px;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
        padding: 20px;
        width: 100%;
        height: 100px;
        display: flex;
        align-items: center;
        text-decoration: none;
        transition: transform 0.3s ease;
        flex-direction: row;
        background-color: #dfdfdf;
    }

    .card:hover {
        transform: scale(1.05);
    }


    .card .count {
        font-size: 22px;
        font-weight: bold;
        color: #2c3e50;
    }

    .card .icon {
        color: midnightblue;
        font-size: 40px;
        margin-right: 20px;
    }

    .card-text {
        width: 100%;
        justify-content: center;
        text-align: left;
        margin: 10%;
    }

    .card .icon {
        font-size: 40px;
        margin-right: 20px;
    }

    @media (max-width: 768px) {
        .dashboard {
            flex-direction: column;
            align-items: center;
        }

        .card {
            width: 100%;
            max-width: 400px;
        }
    }

    @media (min-width: 769px) {
        .card {
            width: 20%
        }
    }
</style>

<div class="main-content">
    <h3>Welcome to the Admin Dashboard</h3>
    <div class="dashboard">
        <a href="manage_user.php" class="card card-users">
            <div class="icon"><i class="fas fa-users"></i></div>
            <div class="card-text">
                <h3>Total Users</h3>
                <p class="count"><?php echo $total_users; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=0" class="card card-tasks">
            <div class="icon"><i class="fas fa-tasks"></i></div>
            <div class="card-text">
                <h3>Total Tasks</h3>
                <p class="count"><?php echo $total_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=4" class="card card-completed">
            <div class="icon"><i class="fas fa-check-circle"></i></div>
            <div class="card-text">
                <h3>Completed Tasks</h3>
                <p class="count"><?php echo $completed_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=1" class="card card-pending">
            <div class="icon"><i class="fas fa-hourglass-half"></i></div>
            <div class="card-text">
                <h3>Pending Tasks</h3>
                <p class="count"><?php echo $pending_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=2" class="card card-inprogress">
            <div class="icon"><i class="fas fa-spinner"></i></div>
            <div class="card-text">
                <h3>In Progress Tasks</h3>
                <p class="count"><?php echo $in_progress; ?></p>
            </div>
        </a>
    </div>
</div>

<?php
ob_end_flush();
include "./includes/footer.php";
?>