<?php
include 'includes/session.php';      
include_once '../config/connect.php'; 
include_once '../config/function_config.php'; 
include 'includes/navbar.php';      
include 'includes/sidebar.php';     

$user_id = $_SESSION['user_id'];

$query = "SELECT * FROM admin WHERE id = :user_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$task_query = "
    SELECT 
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COUNT(*) FROM task) AS total_tasks,
        COUNT(CASE WHEN status = '4' THEN 1 END) AS completed_tasks,
        COUNT(CASE WHEN status = '1' THEN 1 END) AS pending_tasks,
        COUNT(CASE WHEN status IN ('2', '3') THEN 1 END) AS in_progress
    FROM task
";

$task_stmt = $conn->query($task_query);

if ($task_stmt) {
    $task_data = $task_stmt->fetch(PDO::FETCH_ASSOC);

    $total_users = $task_data['total_users'] ?? 0;
    $total_tasks = $task_data['total_tasks'] ?? 0;
    $completed_tasks = $task_data['completed_tasks'] ?? 0;
    $pending_tasks = $task_data['pending_tasks'] ?? 0;
    $in_progress = $task_data['in_progress'] ?? 0;
} else {
    $total_users = $total_tasks = $completed_tasks = $pending_tasks = $in_progress = 0;
}
?>
<div class="main-content">
    <h3>Welcome to the Admin Dashboard</h3>
    <div class="dashboard">
        <a href="manage_user.php" class="card card-users">
            <div class="icon"><i class="fas fa-users"></i></div>
            <div class="card-text">
                <h3>Total Users</h3>
                <p class="count"><?php echo $total_users; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=0" class="card card-tasks">
            <div class="icon"><i class="fas fa-tasks"></i></div>
            <div class="card-text">
                <h3>Total Tasks</h3>
                <p class="count"><?php echo $total_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=4" class="card card-completed">
            <div class="icon"><i class="fas fa-check-circle"></i></div>
            <div class="card-text">
                <h3>Completed Tasks</h3>
                <p class="count"><?php echo $completed_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=1" class="card card-pending">
            <div class="icon"><i class="fas fa-hourglass-half"></i></div>
            <div class="card-text">
                <h3>Pending Tasks</h3>
                <p class="count"><?php echo $pending_tasks; ?></p>
            </div>
        </a>
        <a href="manage_task.php?search=&status_filter=2" class="card card-inprogress">
            <div class="icon"><i class="fas fa-spinner"></i></div>
            <div class="card-text">
                <h3>In Progress Tasks</h3>
                <p class="count"><?php echo $in_progress; ?></p>
            </div>
        </a>
    </div>
</div>
<?php
include "./includes/footer.php";
?>
