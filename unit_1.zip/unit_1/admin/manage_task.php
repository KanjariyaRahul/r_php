<?php
include 'includes/permission_check.php';
include 'includes/session.php';
include '../config/connect.php';
include '../config/function_config.php';
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$limit = 10;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$page = max(1, $page);
$offset = ($page - 1) * $limit;

$searchQuery = '';
$statusFilter = '';
$permission_error_msg = '';

if (isset($_GET['search'])) {
    $searchQuery = $_GET['search'];
}


$query_assigned = "SELECT task.*, users.username, task.total_time, 
                    COUNT(*) OVER() AS total 
                   FROM task 
                   INNER JOIN users ON task.user_id = users.id 
                   WHERE (task.title LIKE :searchQuery OR users.username LIKE :searchQuery 
                   OR task.description LIKE :searchQuery OR task.due_date LIKE :searchQuery) 
                   AND task.created_by = 0";
if ($role != 'admin') {
    $query_assigned .= " AND task.assigned_by = :user_id";
}

if (isset($_GET['status_filter'])) {
    $statusFilter = (int) $_GET['status_filter'];
}

if ($statusFilter) {
    if ($statusFilter == 2 || $statusFilter == 3) {
        $query_assigned .= " AND (task.status = 2 OR task.status = 3)";
    } else {
        $query_assigned .= " AND task.status = :statusFilter";
    }
}
$query_assigned .= " LIMIT :limit OFFSET :offset";

$stmt = $conn->prepare($query_assigned);

$stmt->bindValue(':searchQuery', "%$searchQuery%", PDO::PARAM_STR);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
if ($statusFilter) {
    $stmt->bindValue(':statusFilter', $statusFilter, PDO::PARAM_INT);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$stmt->execute();

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_assigned_tasks = $tasks[0]['total'] ?? 0;
$total_pages_assigned = ceil($total_assigned_tasks / $limit);

$range = 10;
$start = max(1, $page - floor($range / 2));
$end = min($total_pages_assigned, $start + $range - 1);

if ($end - $start < $range - 1) {
    $start = max(1, $end - $range + 1);
}

if (isset($_GET['delete_id'])) {
    if (!hasPermission('can_delete_task')) {
        $permission_error_msg = 'You do not have permission to delete a task.';
    } else {
        if ($role == 'admin') {
            $task_id = (int) $_GET['delete_id'];
            $delete_query = "DELETE FROM task WHERE id = :task_id";
            $stmt = $conn->prepare($delete_query);
            $stmt->bindValue(':task_id', $task_id, PDO::PARAM_INT);
            if ($stmt->execute()) {
                header('Location: manage_task.php?msg=3');
                exit();
            }
        }
    }
}

function secondsToTime($seconds)
{
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $seconds = $seconds % 60;
    return sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Task List</title>
    <script src="./assets/js/script.js"></script>
</head>
<body>
    <div class="main-content">
        <h3>Task List</h3>
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" id="search_bar" name="search" placeholder="Search tasks..."
                    value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" class="btn-search">Search</button>
                <div class="status-filter">
                    <select name="status_filter" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="1" <?php echo $statusFilter == 1 ? 'selected' : ''; ?>>Padding</option>
                        <option value="2" <?php echo $statusFilter == 2 || $statusFilter == 3 ? 'selected' : ''; ?>>In Progress</option>
                        <option value="4" <?php echo $statusFilter == 4 ? 'selected' : ''; ?>>Completed</option>
                    </select>
                </div>
            </form>
            <a href="add_task.php" class="add-task-button">+ Add Task</a>
        </div>
      <?php if ($permission_error_msg != ''): ?>
            <div class="message error">
                <?php  echo $permission_error_msg; ?>
            </div>
             <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Assignee</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Attachment</th>
                        <th>Status</th>
                        <th>Total Time Worked</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($tasks)): ?>
                        <?php foreach ($tasks as $task): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($task['id']); ?></td>
                                <td><?php echo htmlspecialchars($task['username']); ?></td>
                                <td><?php echo htmlspecialchars($task['title']); ?></td>
                                <td>
                                    <?php echo strlen($task['description']) > 50 ? htmlspecialchars(substr($task['description'], 0, 50)) . '... <a href="#" class="view-task-details" data-task-id="' . $task['id'] . '">more</a>' : htmlspecialchars($task['description']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($task['due_date']); ?></td>
                                <td><?php echo $task['attachment'] ? htmlspecialchars($task['attachment']) : 'No attachment'; ?></td>
                                <td class="status-<?php
                                $status = $task['status'];
                                if ($status == 1)
                                    echo 'padding';
                                elseif ($status == 2 || $status == 3)
                                    echo 'in-progress';
                                elseif ($status == 4)
                                    echo 'completed';
                                ?>">
                                    <?php echo $status == 1 ? 'Padding' : ($status == 2 || $status == 3 ? 'In Progress' : 'Completed'); ?>
                                </td>
                                <td><?php echo secondsToTime($task['total_time']); ?></td>
                                <td>
                                    <a href="add_task.php?id=<?php echo $task['id']; ?>" class="icon-link edit-icon">
                                        <i class="fas fa-pencil-alt"></i>
                                        <span class="tooltip">Edit</span>
                                    </a>
                                    <a href="?delete_id=<?php echo $task['id']; ?>" class="icon-link delete-icon"
                                        onclick="return confirm('Are you sure you want to delete this user?')">
                                        <i class="fas fa-trash-alt"></i>
                                        <span class="tooltip">Delete</span>
                                    </a>
                                    <a href="#" class="view-task-details icon-link view-icon">
                                        <i class="fas fa-eye" data-task-id="<?php echo $task['id']; ?>"></i>
                                        <span class="tooltip">View</span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="no-data">No tasks found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_assigned_tasks > $limit): ?>
            <div class="pagination">
                <div class="google-pagination">
                    <span class="prev-btn">
                        <a href="?page=<?php echo max(1, $page - 1); ?>" <?php echo $page == 1 ? 'class="disabled"' : ''; ?>>&laquo; Previous</a>
                    </span>

                    <?php for ($i = 1; $i <= $total_pages_assigned; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchQuery); ?>&status_filter=<?php echo $statusFilter; ?>"
                            class="<?php echo $i == $page ? 'current' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <span class="next-btn">
                        <a href="?page=<?php echo min($total_pages_assigned, $page + 1); ?>" <?php echo $page == $total_pages_assigned ? 'class="disabled"' : ''; ?>>Next &raquo;</a>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <div id="task-modal" class="modal">
            <div class="modal-content">
                <span class="modal-close" id="closeModal">&times;</span>
                <h3>Task Details</h3>
                <div id="task-details"></div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
include "./includes/footer.php";
?>
 