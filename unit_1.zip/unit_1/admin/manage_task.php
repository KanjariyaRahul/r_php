<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/connect.php';
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 1) {
        $message = "Task added successfully!";
    } elseif ($msg == 2) {
        $message = "Task updated successfully!";
    } elseif ($msg == 3) {
        $message = "Task deleted successfully!";
    } else {
        $message = "";
    }
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$limit = 10;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$page = max(1, $page);
$offset = ($page - 1) * $limit;

$searchQuery = '';
$statusFilter = '';

if (isset($_GET['search'])) {
    $searchQuery = $_GET['search'];
}

$query_assigned = "SELECT task.*, users.username, task.total_time, 
                    COUNT(*) OVER() AS total 
                   FROM task 
                   INNER JOIN users ON task.user_id = users.id 
                   WHERE (task.title LIKE :searchQuery OR users.username LIKE :searchQuery 
                   OR task.description LIKE :searchQuery OR task.due_date LIKE :searchQuery)";

if ($role != 'admin') {
    $query_assigned .= " AND task.assigned_by = :user_id";
}

if (isset($_GET['status_filter'])) {
    $statusFilter = (int) $_GET['status_filter'];
}

if ($statusFilter) {
    if ($statusFilter == 2 || $statusFilter == 3) {
        $query_assigned .= " AND (task.status = 2 OR task.status = 3)";
    } else {
        $query_assigned .= " AND task.status = :statusFilter";
    }
}

$query_assigned .= " LIMIT :limit OFFSET :offset";

$stmt = getConnection()->prepare($query_assigned);

$stmt->bindValue(':searchQuery', "%$searchQuery%", PDO::PARAM_STR);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
if ($statusFilter) {
    $stmt->bindValue(':statusFilter', $statusFilter, PDO::PARAM_INT);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$stmt->execute();

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_assigned_tasks = $tasks[0]['total'] ?? 0;
$total_pages_assigned = ceil($total_assigned_tasks / $limit);

$range = 10;
$start = max(1, $page - floor($range / 2));
$end = min($total_pages_assigned, $start + $range - 1);

if ($end - $start < $range - 1) {
    $start = max(1, $end - $range + 1);
}

if (isset($_GET['delete_id'])) {
    if ($role == 'admin') {
        $task_id = (int) $_GET['delete_id'];
        $delete_query = "DELETE FROM task WHERE id = :task_id";
        $stmt = getConnection()->prepare($delete_query);
        $stmt->bindValue(':task_id', $task_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            header('Location: manage_task.php?msg=3');
            exit();
        }
    }
}

function secondsToTime($seconds)
{
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $seconds = $seconds % 60;
    return sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
}

ob_end_flush();
?>


<title>Admin Task List</title>
<style>
    * {
        text-decoration: none;
    }

    body {
        font-family: Arial, sans-serif;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    body.light {
        color: #333;
    }

    body.dark {
        background-color: #2a2a2a;
        color: #f7f7f7;
    }

    h2 {
        font-size: 25px;
    }

    .message {
        padding: 10px;
        margin-bottom: 20px;
        font-weight: bold;
        border-radius: 5px;
    }

    .success {
        background-color: rgb(100, 185, 103);
        color: white;
    }

    .search-container {
        display: flex;
        justify-content: space-between;

        flex-wrap: wrap;
    }

    .search-container form {
        display: flex;
        align-items: center;
        width: 100%;
        max-width: 800px;
    }

    #search_bar {
        flex-grow: 1;
        padding: 12px 20px;
        margin-right: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    button {
        padding: 12px 20px;
        background-color: rgb(37, 71, 100);
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3sease;
    }

    button:hover {
        background-color: rgb(20, 35, 48);
    }

    .status-filter select {
        padding: 10px;
        margin-left: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .add-task-button {
        padding: 10px 20px;
        background-color: rgb(37, 71, 100);
        color: white;
        border-radius: 5px;
        text-decoration: none;
    }

    .table-container {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    table th,
    table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    table th {
        background-color: rgb(37, 71, 100);
        color: white;
    }

    body.dark table td {
        color: #f7f7f7;
    }

    .actions a {
        text-decoration: none;
        color: #007BFF;
        padding: 5px 10px;
    }

    .actions a:hover {
        background-color: #f1f1f1;
        border-radius: 5px;
    }

    .pagination {
        text-align: right;
        margin-top: 20px;
    }

    .google-pagination a,
    .google-pagination span {
        padding: 8px 15px;
        color: #4285f4;
        font-size: 14px;
        border-radius: 5px;
        text-decoration: none;
    }

    .google-pagination a:hover {
        text-decoration: underline;
    }

    .google-pagination .current {
        color: #000;
        font-weight: bold;
        background-color: #f1f1f1;
    }

    .google-pagination .disabled {
        color: #ccc;
        pointer-events: none;
    }

    .no-data {
        text-align: center;
        color: #999;
        font-style: italic;
    }

    .status-padding {
        font-weight: bold;
        color: #f39c12;
    }

    .status-in-progress {
        font-weight: bold;
        color: #2980b9;
    }

    .status-completed {
        font-weight: bold;
        color: #27ae60;
    }

    .add-task-button {
        padding: 10px 25px;
        border-radius: 5px;
        background-color: rgb(37, 71, 100);
        font-size: 16px;
        font-weight: bold;
        color: white;
        height: 20px;
        text-decoration: none;
    }

    .add-task-button:hover {
        background-color: rgb(18, 32, 46);
        color: white;
    }

    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        z-index: 1000;
        align-items: center;
        justify-content: center;
    }

    body.dark .model-content {
        color: #000;
    }

    .modal-content {
        background-color: white;
        padding: 20px;
        width: 60%;
        color: #000;
        max-height: 80%;
        overflow-y: auto;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .modal-close {
        margin-left: 97%;
        top: 10px;
        right: 10px;
        background: #ff4d4d;
        color: white;
        padding: 10px;
        border-radius: 10%;
        cursor: pointer;
    }

    .icon-link {
        position: relative;
        text-decoration: none;
        margin-right: 10px;
        font-size: 20px;
        display: inline-block;
        transition: transform 0.2s ease;
    }

    .icon-link .tooltip {
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        background-color: rgba(0, 0, 0, 0.7);
        color: #fff;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 12px;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease;
        pointer-events: none;
    }

    .icon-link:hover .tooltip {
        opacity: 1;
        visibility: visible;
    }

    .icon-link i {
        transition: color 0.3s ease, transform 0.3s ease;
    }

    .icon-link:hover i {
        transform: scale(1.2);
    }

    .edit-icon i {
        color: rgb(107, 184, 110);
    }

    .edit-icon:hover i {
        color: #45a049;
    }

    .delete-icon i {
        color: rgb(230, 74, 62);
    }

    .delete-icon:hover i {
        color: #e53935;
    }

    .view-icon {
        color: #2196F3;
    }

    .view-icon:hover {
        color: #1976D2;
    }

    .status-filter select {
        padding: 10px;
        font-size: 16px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    @media (max-width: 768px) {
        .search-container {
            flex-direction: column;
            align-items: flex-start;
        }

        .search-container form {
            width: 100%;
            flex-direction: column;
        }

        #search_bar {
            margin-bottom: 10px;
        }

        button {
            margin-bottom: 10px;
        }

        .add-task-button {
            margin-top: 10px;
        }
    }
</style>

<body>
    <div class="main-content">
        <h3>Task List</h3>
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" id="search_bar" name="search" placeholder="Search tasks..."
                    value="<?= htmlspecialchars($searchQuery) ?>">
                <button type="submit">Search</button>
                <div class="status-filter">
                    <select name="status_filter" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="1" <?= $statusFilter == 1 ? 'selected' : '' ?>>Padding</option>
                        <option value="2" <?= $statusFilter == 2 || $statusFilter == 3 ? 'selected' : '' ?>>In Progress
                        </option>
                        <option value="4" <?= $statusFilter == 4 ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
            </form>
            <a href="add_task.php" class="add-task-button">+ Add Task</a>
        </div>

        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Assignee</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Attachment</th>
                        <th>Status</th>
                        <th>Total Time Worked</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($tasks)): ?>
                        <?php foreach ($tasks as $task): ?>
                            <tr>
                                <td><?= htmlspecialchars($task['id']) ?></td>
                                <td><?= htmlspecialchars($task['username']) ?></td>
                                <td><?= htmlspecialchars($task['title']) ?></td>
                                <td>
                                    <?= strlen($task['description']) > 50 ? htmlspecialchars(substr($task['description'], 0, 50)) . '... <a href="#" class="view-task-details" data-task-id="' . $task['id'] . '">more</a>' : htmlspecialchars($task['description']) ?>
                                </td>
                                <td><?= htmlspecialchars($task['due_date']) ?></td>
                                <td><?= $task['attachment'] ? htmlspecialchars($task['attachment']) : 'No attachment' ?></td>
                                <td class="status-<?php
                                $status = $task['status'];
                                if ($status == 1)
                                    echo 'padding';
                                elseif ($status == 2 || $status == 3)
                                    echo 'in-progress';
                                elseif ($status == 4)
                                    echo 'completed';
                                ?>">
                                    <?= $status == 1 ? 'Padding' : ($status == 2 || $status == 3 ? 'In Progress' : 'Completed') ?>
                                </td>
                                <td><?= secondsToTime($task['total_time']) ?></td>
                                <td>
                                    <a href="add_task.php?id=<?= $task['id'] ?>" class="icon-link edit-icon">
                                        <i class="fas fa-pencil-alt"></i>
                                        <span class="tooltip">Edit</span>
                                    </a>
                                    <a href="?delete_id=<?= $task['id'] ?>" class="icon-link delete-icon"
                                        onclick="return confirm('Are you sure you want to delete this user?')">
                                        <i class="fas fa-trash-alt"></i>
                                        <span class="tooltip">Delete</span>
                                    </a>
                                    <a href="#" class="view-task-details icon-link view-icon">
                                        <i class="fas fa-eye" data-task-id="<?= $task['id'] ?> "></i>
                                        <span class="tooltip">View</span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="no-data">No tasks found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_assigned_tasks > $limit): ?>
            <div class="pagination">
                <div class="google-pagination">
                    <span class="prev-btn">
                        <a href="?page=<?= max(1, $page - 1) ?>" <?= $page == 1 ? 'class="disabled"' : '' ?>>&laquo;
                            Previous</a>
                    </span>

                    <?php for ($i = 1; $i <= $total_pages_assigned; $i++): ?>
                        <a href="?page=<?= $i ?>&search=<?= urlencode($searchQuery) ?>&status_filter=<?= $statusFilter ?>"
                            class="<?= $i == $page ? 'current' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>

                    <span class="next-btn">
                        <a href="?page=<?= min($total_pages_assigned, $page + 1) ?>" <?= $page == $total_pages_assigned ? 'class="disabled"' : '' ?>>Next &raquo;</a>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <div id="task-modal" class="modal">
            <div class="modal-content">
                <span class="modal-close" onclick="closeModal()">&times;</span>
                <h3>Task Details</h3>
                <div id="task-details"></div>
            </div>
        </div>
    </div>
</body>

<script>
    function openModal(taskId) {
        document.getElementById('task-modal').style.display = 'flex';
        fetchTaskDetails(taskId);
    }

    function closeModal() {
        document.getElementById('task-modal').style.display = 'none';
    }

    function fetchTaskDetails(taskId) {
        const taskDetailsElement = document.getElementById('task-details');
        fetch('task_details.php?task_id=' + taskId)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.details) {
                    let statusText = '';
                    if (data.details.status == 1) {
                        statusText = 'Padding';
                    } else if (data.details.status == 2 || data.details.status == 3) {
                        statusText = 'in-progress';
                    } else if (data.details.status == 4) {
                        statusText = 'Completed';
                    }

                    taskDetailsElement.innerHTML = `
                            <p><strong>Task Id :</strong> ${data.details.id}</p>
                            <p><strong>Title:</strong> ${data.details.title}</p>
                            <p><strong>Description:</strong> ${data.details.description}</p>
                            <p><strong>Due Date:</strong> ${data.details.due_date}</p>
                            <p><strong>Status:</strong> <span class="status-${statusText}">${statusText}</span></p>
                            <p><strong>Time Limit:</strong> ${secondsToTime(data.details.time_limit)}</p>
                            <p><strong>Time Worked:</strong> ${secondsToTime(data.details.total_time)}</p>
                        `;
                } else if (data.error) {
                    taskDetailsElement.innerHTML = `<p>${data.error}</p>`;
                }

            })
            .catch(error => console.error('Error fetching task details:', error));
    }

    document.querySelectorAll('.view-task-details').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const taskId = event.target.getAttribute('data-task-id');
            openModal(taskId);
        });
    });

    function secondsToTime(seconds) {
        var hours = Math.floor(seconds / 3600);
        var minutes = Math.floor((seconds % 3600) / 60);
        var seconds = seconds % 60;
        return hours.toString().padStart(2, '0') + ':' + minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');
    }
</script>

</html>
<?php
ob_end_flush();
include "./includes/footer.php";
?>