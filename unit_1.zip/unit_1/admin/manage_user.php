<?php
include 'includes/permission_check.php';
include 'includes/session.php';
include_once '../config/connect.php';
include_once '../config/function_config.php';
include 'includes/navbar.php';
include 'includes/sidebar.php';

$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$genderFilter = isset($_GET['gender']) ? $_GET['gender'] : '';
$permission_error_msg = '';
$query = "SELECT * FROM users WHERE 1";

if ($searchQuery != '') {
    $query .= " AND (name LIKE :search OR email LIKE :search OR username LIKE :search)";
}
if ($genderFilter != '') {
    $query .= " AND gender = :gender";
}
$query .= " ORDER BY id DESC";

$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;
$query .= " LIMIT :limit OFFSET :offset";

$stmt = $conn->prepare($query);

if ($searchQuery != '') {
    $stmt->bindValue(':search', '%' . $searchQuery . '%', PDO::PARAM_STR);
}

if ($genderFilter != '') {
    $stmt->bindValue(':gender', $genderFilter, PDO::PARAM_INT);
}

$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalQuery = "SELECT COUNT(*) FROM users WHERE 1";
if ($searchQuery != '') {
    $totalQuery .= " AND (name LIKE :search OR email LIKE :search OR username LIKE :search)";
}
if ($genderFilter != '') {
    $totalQuery .= " AND gender = :gender";
}

$totalStmt = $conn->prepare($totalQuery);

if ($searchQuery != '') {
    $totalStmt->bindValue(':search', '%' . $searchQuery . '%', PDO::PARAM_STR);
}

if ($genderFilter != '') {
    $totalStmt->bindValue(':gender', $genderFilter, PDO::PARAM_INT);
}

if (isset($_GET['delete'])) {
    if (!hasPermission('can_delete_user')) {
        $permission_error_msg = 'You do not have permission to delete a user.';
    } else {
        $userId = (int) $_GET['delete'];
        $delete_query = "DELETE FROM users WHERE id = :userId";
        $stmt = $conn->prepare($delete_query);
        $stmt->bindValue(':userId', $userId, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $message = 'User deleted successfully!';
            header('Location: manage_user.php?msg=3');
            exit();
        } else {
            $message = 'Error deleting user!';
            header('Location: manage_user.php?msg=4');
            exit();
        }
    }
}

$totalStmt->execute();
$totalUsers = $totalStmt->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 2) {
        $message = "User updated successfully!";
    } elseif ($msg == 3) {
        $message = "User deleted successfully!";
    } elseif ($msg == 4) {
        $message = "Error deleting user!";
    } else {
        $message = "";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
</head>
<body>
    <div class="main-content" id="main-content">
        <h3>User List</h3>
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" name="search" id="search_bar" placeholder="Search users..."
                    value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" class="btn-search">Search</button>
                <div class="status-filter">
                    <select name="gender" onchange="this.form.submit()">
                        <option value="" <?php echo $genderFilter === '' ? 'selected' : ''; ?>>All Gender</option>
                        <option value="1" <?php echo $genderFilter == 1 ? 'selected' : ''; ?>>Male</option>
                        <option value="2" <?php echo $genderFilter == 2 ? 'selected' : ''; ?>>Female</option>
                        <option value="3" <?php echo $genderFilter == 3 ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
            </form>
            <a href="add_user.php" class="add-task-button">+ Add User</a>
        </div>
        <?php if ($permission_error_msg != ''): ?>
            <div class="message error">
                <?php  echo $permission_error_msg; ?>
            </div>
             <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>
        <?php if (isset($message) && $message != ""): ?>
            <div class="message success"><?php echo $message; ?></div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Gender</th>
                        <th>Username</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($users) > 0): ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['id']); ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td>
                                    <?php
                                    if ($user['gender'] == 1)
                                        echo "Male";
                                    elseif ($user['gender'] == 2)
                                        echo "Female";
                                    elseif ($user['gender'] == 3)
                                        echo "Other";
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td>
                                    <a href="add_user.php?id=<?php echo $user['id']; ?>" class="icon-link edit-icon">
                                        <i class="fas fa-pencil-alt"></i>
                                        <span class="tooltip">Edit</span>
                                    </a>
                                    <a href="?delete=<?php echo $user['id']; ?>"
                                        onclick="return confirm('Are you sure you want to delete this user?')"
                                        class="icon-link delete-icon">
                                        <i class="fas fa-trash-alt"></i>
                                        <span class="tooltip">Delete</span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">Record not found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (count($users) > 0): ?>
            <div class="pagination">
                <div class="google-pagination">
                    <span class="prev-btn">
                        <a href="?page=<?php echo max(1, $page - 1); ?>" <?php echo $page == 1 ? 'class="disabled"' : ''; ?>>&laquo; Previous</a>
                    </span>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchQuery); ?>&gender=<?php echo $genderFilter; ?>"
                            class="<?php echo $i == $page ? 'current' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <span class="next-btn">
                        <a href="?page=<?php echo min($totalPages, $page + 1); ?>" <?php echo $page == $totalPages ? 'class="disabled"' : ''; ?>>Next &raquo;</a>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
include "./includes/footer.php";
?>