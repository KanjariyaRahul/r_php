<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/connect.php';
include 'includes/navbar.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

$searchQuery = '';
$genderFilter = '';
if (isset($_GET['search'])) {
    $searchQuery = $_GET['search'];
}

if (isset($_GET['gender'])) {
    $genderFilter = $_GET['gender'];
}

$perPage = 5;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

$query = "
    SELECT * 
    FROM users 
    WHERE (name LIKE ? 
        OR email LIKE ? 
        OR username LIKE ?)";
$params = ["%$searchQuery%", "%$searchQuery%", "%$searchQuery%"];

if ($genderFilter !== '') {
    $query .= " AND gender = ?";
    $params[] = $genderFilter;
}

$totalQuery = $query;
$totalResult = safe_query($totalQuery, str_repeat('s', count($params)), $params);
$totalUsers = count($totalResult); 
$totalPages = ceil($totalUsers / $perPage);

$query .= " LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

$types = str_repeat('s', count($params) - 2) . 'ii'; 
$users = safe_query($query, $types, $params);

if (!$users) {
    die('Query failed.');
}

if (isset($_GET['delete'])) {
    $userId = (int) $_GET['delete'];
    $deleteQuery = "DELETE FROM users WHERE id = ?";
    $deleteResult = safe_query($deleteQuery, 'i', [$userId]);
        $message = 'User deleted successfully!';
        header('Location: manage_user.php?msg=3');
        exit();
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    if ($msg == 2) {
        $message = "User updated successfully!";
    } elseif ($msg == 3) {
        $message = "User deleted successfully!";
    } else {
        $message = "";
    }
}
ob_end_flush();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        body.light {
            color: #333;
        }

        body.dark {
            background-color: #2a2a2a;
            color: #f7f7f7;
        }

        h2 {
            font-size: 25px;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
        }

        .success {
            background-color: rgb(100, 185, 103);
            color: white;
        }

        .search-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .search-container form {
            display: flex;
            align-items: center;
            width: 100%;
            max-width: 800px;
        }

        #search_bar {
            flex-grow: 1;
            padding: 12px 20px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 12px 20px;
            background-color: rgb(37, 71, 100);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3sease;
        }

        button:hover {
            background-color: rgb(20, 35, 48);
        }

        .status-filter select {
            padding: 10px;
            margin-left: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .add-task-button {
            padding: 10px 20px;
            background-color: rgb(37, 71, 100);
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th,
        table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: rgb(37, 71, 100);
            color: white;
        }

        body.dark table td {
            color: #f7f7f7;
        }

        .actions a {
            text-decoration: none;
            color: #007BFF;
            padding: 5px 10px;
        }

        .actions a:hover {
            background-color: #f1f1f1;
            border-radius: 5px;
        }

        .pagination {
            text-align: right;
            margin-top: 20px;
        }

        .google-pagination a,
        .google-pagination span {
            padding: 8px 15px;
            color: #4285f4;
            font-size: 14px;
            border-radius: 5px;
            text-decoration: none;
        }

        .google-pagination a:hover {
            text-decoration: underline;
        }

        .google-pagination .current {
            color: #000;
            font-weight: bold;
            background-color: #f1f1f1;
        }

        .google-pagination .disabled {
            color: #ccc;
            pointer-events: none;
        }

        .no-data {
            text-align: center;
            color: #999;
            font-style: italic;
        }

        .status-padding {
            font-weight: bold;
            color: #f39c12;
        }

        .status-in-progress {
            font-weight: bold;
            color: #2980b9;
        }

        .status-completed {
            font-weight: bold;
            color: #27ae60;
        }

        .add-task-button {
            padding: 10px 25px;
            border-radius: 5px;
            background-color: rgb(37, 71, 100);
            font-size: 16px;
            font-weight: bold;
            color: white;
            height: 20px;
            text-decoration: none;
        }

        .add-task-button:hover {
            background-color: rgb(18, 32, 46);
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            width: 60%;
            max-height: 80%;
            overflow-y: auto;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-close {
            margin-left: 97%;
            top: 10px;
            right: 10px;
            background: #ff4d4d;
            color: white;
            padding: 10px;
            border-radius: 10%;
            cursor: pointer;
        }

        .icon-link {
            position: relative;
            text-decoration: none;
            margin-right: 10px;
            font-size: 20px;
            display: inline-block;
            transition: transform 0.2s ease;
        }

        .icon-link .tooltip {
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
            pointer-events: none;
        }

        .icon-link:hover .tooltip {
            opacity: 1;
            visibility: visible;
        }

        .icon-link i {
            transition: color 0.3s ease, transform 0.3s ease;
        }

        .icon-link:hover i {
            transform: scale(1.2);
        }

        .edit-icon i {
            color: rgb(107, 184, 110);
        }

        .edit-icon:hover i {
            color: #45a049;
        }

        .delete-icon i {
            color: rgb(230, 74, 62);
        }

        .delete-icon:hover i {
            color: #e53935;
        }

        .view-icon {
            color: #2196F3;
        }

        .view-icon:hover {
            color: #1976D2;
        }

        .status-filter select {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        @media (max-width: 768px) {
            .search-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .search-container form {
                width: 100%;
                flex-direction: column;
            }

            #search_bar {
                margin-bottom: 10px;
            }

            button {
                margin-bottom: 10px;
            }

            .add-task-button {
                margin-top: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="main-content" id="main-content">
        <h3>User List</h3>
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" name="search" id="search_bar" placeholder="Search users..."
                    value="<?= htmlspecialchars($searchQuery) ?>">
                <button type="submit">Search</button>
                <div class="status-filter">
                    <select name="gender" onchange="this.form.submit()">
                        <option value="" <?= $genderFilter === '' ? 'selected' : '' ?>>All Gender</option>
                        <option value="1" <?= $genderFilter == 1 ? 'selected' : '' ?>>Male</option>
                        <option value="2" <?= $genderFilter == 2 ? 'selected' : '' ?>>Female</option>
                        <option value="3" <?= $genderFilter == 3 ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>
            </form>
            <a href="add_user.php" class="add-task-button">+ Add User</a>
        </div>

        <?php if (isset($message) && $message != ""): ?>
            <div class="message success">
                <?php echo $message; ?>
            </div>
            <script>
                setTimeout(function () {
                    document.querySelector('.message').style.display = 'none';
                }, 5000);
            </script>
        <?php endif; ?>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Gender</th>
                        <th>Username</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    <?php if (count($users) > 0): ?> 
        <?php foreach ($users as $user): ?> 
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td><?= htmlspecialchars($user['name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['phone']) ?></td>
                <td>
                    <?php
                    if ($user['gender'] == 1)
                        echo "Male";
                    elseif ($user['gender'] == 2)
                        echo "Female";
                    elseif ($user['gender'] == 3)
                        echo "Other";
                    ?>
                </td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td>
                    <a href="add_user.php?id=<?= $user['id'] ?>" class="icon-link edit-icon">
                        <i class="fas fa-pencil-alt"></i>
                        <span class="tooltip">Edit</span>
                    </a>
                    <a href="?delete=<?= $user['id'] ?>"
                        onclick="return confirm('Are you sure you want to delete this user?')"
                        class="icon-link delete-icon">
                        <i class="fas fa-trash-alt"></i>
                        <span class="tooltip">Delete</span>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="7" class="text-center">Record not found</td>
        </tr>
    <?php endif; ?>
</tbody>

            </table>
        </div>

       <?php if (count($users) > 0): ?> 
    <div class="pagination">
        <div class="google-pagination">
            <span class="prev-btn">
                <a href="?page=<?= max(1, $page - 1) ?>" <?= $page == 1 ? 'class="disabled"' : '' ?>>
                    &laquo; Previous
                </a>
            </span>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&search=<?= urlencode($searchQuery) ?>&gender=<?= $genderFilter ?>"
                    class="<?= $i == $page ? 'current' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <span class="next-btn">
                <a href="?page=<?= min($totalPages, $page + 1) ?>" <?= $page == $totalPages ? 'class="disabled"' : '' ?>>
                    Next &raquo;
                </a>
            </span>
        </div>
    </div>
<?php endif; ?>

        
    </div>
</body>
<script>
    function loadPage(page) {
        const mainContent = document.getElementById("main-content");

        fetch(page)
            .then(response => response.text())
            .then(data => {
                mainContent.innerHTML = data;
                const links = document.querySelectorAll('.sidebar-links li');
                links.forEach(link => link.classList.remove('active'));
                const activeLink = Array.from(links).find(link => link.querySelector('a').getAttribute('href') === `javascript:void(0);` && link.querySelector('a').textContent.trim() === page.replace('.php', '').replace('_', ' ').toUpperCase());
                if (activeLink) activeLink.classList.add('active');
            })
            .catch(error => {
                console.error('Error loading page:', error);
            });
    }
</script>

</html>
<?php
ob_end_flush();
include "./includes/footer.php";
?>