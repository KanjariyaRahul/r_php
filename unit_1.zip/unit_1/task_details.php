<?php
require_once 'config/connect.php';

if (isset($_GET['task_id'])) {
    $task_id = (int)$_GET['task_id'];
    $conn = getConnection(); 
    $sql = "SELECT * FROM task WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bindValue(1, $task_id, PDO::PARAM_INT);
        $stmt->execute();
        $task = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($task) {
            $taskDetails = [
                'id' => $task['id'],
                'title' => $task['title'],
                'description' => $task['description'] ? $task['description'] : 'No description',
                'due_date' => $task['due_date'],
                'time_limit' => gmdate("H:i:s", $task['time_limit']),
                'status' => $task['status'],
                'total_time' => isset($task['total_time']) ? gmdate("H:i:s", $task['total_time']) : '0:00:00'
            ];
            echo json_encode($taskDetails);
        } else {
            echo json_encode(['error' => 'Task not found']);
        }
    } else {
        echo json_encode(['error' => 'Failed to prepare SQL statement']);
    }
}
?>
