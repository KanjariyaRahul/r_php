<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "unit_test_1";
$conn = null;

function getConnection() {
    global $conn;
    if ($conn === null) {
        $conn = new PDO("mysql:host={$GLOBALS['host']};dbname={$GLOBALS['dbname']}", $GLOBALS['user'], $GLOBALS['pass']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $conn;
}

function rpt_prepare($query) {
    $conn = getConnection();
    return $conn->prepare($query);
}

function rpt_bindValue($stmt, $key, $value, $paramType = PDO::PARAM_STR) {
    return $stmt->bindValue( $key, $value, $paramType);
}

function safe_query($query, $types, $params) {
    $conn = getConnection();
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function fetchData($query, $params = []) {
    $conn = getConnection();
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);
    }
     
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function executeQuery($query, $params = []) {
    $conn = getConnection();
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);
    }
    return $stmt->execute();
}

function closeConnection() {
    global $conn;
    if ($conn) {
        $conn = null;
    }
}

function escape($data) {
    $conn = getConnection();
    return $conn->quote($data);
}
?>
