<?php
date_default_timezone_set('Asia/Kolkata');

$host = "localhost";
$username = "root";
$password = "";
$dbname = "unit_test_1";
$conn = null;
try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit; 
}
?>

