<?php
include 'connect.php'; 
function rpt_prepare($query) {
    global $conn;
    return $conn->prepare($query);
}
    
function rpt_bindValue($stmt, $key, $value, $paramType = PDO::PARAM_STR) {
    return $stmt->bindValue($key, $value, $paramType);
}

function rpt_safe_query($query, $types, $params) {
    global $conn;
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);  
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function rpt_fetchData($query, $params = []) {
    global $conn;
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);
   }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function rpt_executeQuery($query, $params = []) {
    global $conn;
    $stmt = rpt_prepare($query);
    $i = 1;
    foreach ($params as $value) {
        $paramType = (is_int($value)) ? PDO::PARAM_INT : PDO::PARAM_STR;
        rpt_bindValue($stmt, $i++, $value, $paramType);
    }
    return $stmt->execute();
}
function rpt_closeConnection() {
    global $conn;
    if ($conn) {
        $conn = null;
    }
}
function rpt_escape($data) {
    global $conn;
    return $conn->quote($data);
}
?>
