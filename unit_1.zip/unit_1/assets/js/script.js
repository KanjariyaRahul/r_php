function toggleTheme() {
    let currentTheme = document.body.classList.contains('dark') ? 'dark' : 'light';
    let newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    document.body.classList.remove(currentTheme);
    document.body.classList.add(newTheme);

    document.cookie = "theme=" + newTheme + "; path=/";

    window.location.herf= "./index.php?forsthem=1&theme"+newTheme;

}

