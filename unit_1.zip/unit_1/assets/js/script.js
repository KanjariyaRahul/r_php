function loginform() {
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let hasErrors = false;

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    return !hasErrors;
}

window.onload = function () {
    let errorMessage = document.getElementById('error-message');
    if (errorMessage) {
        errorMessage.style.display = 'block';
        setTimeout(() => { errorMessage.style.display = 'none'; }, 5000);
    }
    document.querySelectorAll('input[type="text"], input[type="password"]').forEach(function (input) {
        input.addEventListener('input', function () {
            let error = document.getElementById(this.id + '-error');
            if (this.value.trim() !== "") {
                this.classList.remove('invalid');
                error.style.display = 'none';
            }
        });
        input.addEventListener('focus', function () {
            this.classList.remove('invalid');
            let error = document.getElementById(this.id + '-error');
            error.style.display = 'none';
        });

        input.addEventListener('blur', function () {
            if (this.classList.contains('invalid')) {
                setTimeout(() => this.focus(), 1000);
            }
        });
    });
};

function registerform() {
    let name = document.getElementById('name');
    let email = document.getElementById('email');
    let phone = document.getElementById('phone');
    let gender = document.querySelector('input[name="gender"]:checked');
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    let password_confirm = document.getElementById('password_confirm');
    
    let nameError = document.getElementById('name-error');
    let emailError = document.getElementById('email-error');
    let phoneError = document.getElementById('phone-error');
    let genderError = document.getElementById('gender-error');
    let usernameError = document.getElementById('username-error');
    let passwordError = document.getElementById('password-error');
    let passwordConfirmError = document.getElementById('password_confirm-error');

    let hasErrors = false;

    if (name.value.trim() === "") {
        name.classList.add('invalid');
        nameError.textContent = "Please enter your full name.";
        nameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => name.focus(), 1000);
        }
        hasErrors = true;
    } else {
        name.classList.remove('invalid');
        nameError.style.display = 'none';
    }

    if (email.value.trim() === "") {
        email.classList.add('invalid');
        emailError.textContent = "Please enter your email address.";
        emailError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => email.focus(), 1000);
        }
        hasErrors = true;
    } else if (!/\S+@\S+\.\S+/.test(email.value)) {
        email.classList.add('invalid');
        emailError.textContent = "Please enter a valid email address (e.g., example@domain.com).";
        emailError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => email.focus(), 1000);
        }
        hasErrors = true;
    } else {
        email.classList.remove('invalid');
        emailError.style.display = 'none';
    }

    if (phone.value.trim() === "") {
        phone.classList.add('invalid');
        phoneError.textContent = "Please enter your phone number.";
        phoneError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => phone.focus(), 1000);
        }
        hasErrors = true;
    } else if (!/^\d{10}$/.test(phone.value)) {
        phone.classList.add('invalid');
        phoneError.textContent = "Please enter a valid 10-digit phone number.";
        phoneError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => phone.focus(), 1000);
        }
        hasErrors = true;
    } else {
        phone.classList.remove('invalid');
        phoneError.style.display = 'none';
    }

    if (!gender) {
        document.querySelectorAll('input[name="gender"]').forEach(function (radio) {
            radio.classList.add('invalid');
        });
        genderError.textContent = "Please select your gender.";
        genderError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => document.querySelector('input[name="gender"]').focus(), 1000);
        }
        hasErrors = true;
    } else {
        document.querySelectorAll('input[name="gender"]').forEach(function (radio) {
            radio.classList.remove('invalid');
        });
        genderError.style.display = 'none';
    }

    if (username.value.trim() === "") {
        username.classList.add('invalid');
        usernameError.textContent = "Please enter a username.";
        usernameError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => username.focus(), 1000);
        }
        hasErrors = true;
    } else {
        username.classList.remove('invalid');
        usernameError.style.display = 'none';
    }

    if (password.value.trim() === "") {
        password.classList.add('invalid');
        passwordError.textContent = "Please enter a password.";
        passwordError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password.focus(), 1000);
        }
        hasErrors = true;
    } else {
        password.classList.remove('invalid');
        passwordError.style.display = 'none';
    }

    if (password_confirm.value.trim() === "") {
        password_confirm.classList.add('invalid');
        passwordConfirmError.textContent = "Please confirm your password.";
        passwordConfirmError.style.display = 'block';
        if (!hasErrors) {
            setTimeout(() => password_confirm.focus(), 1000);
        }
        hasErrors = true;
    } else if (password.value !== password_confirm.value) {
        password_confirm.classList.add('invalid');
        passwordConfirmError.textContent = "Passwords do not match.";
        passwordConfirmError.style.display = 'block';
        hasErrors = true;
    } else {
        password_confirm.classList.remove('invalid');
        passwordConfirmError.style.display = 'none';
    }

    return !hasErrors;
}

function addtaskform() {
    event.preventDefault();
    let title = document.getElementById('title');
    let description = document.getElementById('description');
    let due_date = document.getElementById('due_date');
    let time_limit = document.getElementById('time_limit');
    let priority = document.querySelector('input[name="priority"]:checked');
    
    let user_idError = document.getElementById('user_id-error');
    let titleError = document.getElementById('title-error');
    let descriptionError = document.getElementById('description-error');
    let due_dateError = document.getElementById('due_date-error');
    let time_limitError = document.getElementById('time_limit-error');
    let priorityError = document.getElementById('priority-error');
    
    let hasErrors = false;
    let firstErrorElement = null;


    if (title.value.trim() === "") {
        title.classList.add('invalid');
        titleError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = title;
        }
        hasErrors = true;
    } else {
        title.classList.remove('invalid');
        titleError.style.display = 'none';
    }

    if (description.value.trim() === "") {
        description.classList.add('invalid');
        descriptionError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = description;
        }
        hasErrors = true;
    } else {
        description.classList.remove('invalid');
        descriptionError.style.display = 'none';
    }

    if (!due_date.value.trim()) {
        due_date.classList.add('invalid');
        due_dateError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = due_date;
        }
        hasErrors = true;
    } else {
        due_date.classList.remove('invalid');
        due_dateError.style.display = 'none';
    }

    if (!time_limit.value.trim()) {
        time_limit.classList.add('invalid');
        time_limitError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = time_limit;
        }
        hasErrors = true;
    } else {
        time_limit.classList.remove('invalid');
        time_limitError.style.display = 'none';
    }

    if (!priority) {
        priorityError.style.display = 'block';
        if (!hasErrors) {
            firstErrorElement = document.querySelector('input[name="priority"]');
        }
        hasErrors = true;
    } else {
        priorityError.style.display = 'none';
    }

    if (!hasErrors) {
        document.getElementById('taskForm').submit();
    }

    // If there are errors, focus on the first error element
    if (firstErrorElement) {
        setTimeout(() => firstErrorElement.focus(), 500);
    }

    return !hasErrors;
}



window.onload = function () {
    document.querySelectorAll('input[type="text"], input[type="file"], input[type="date"], input[type="time"], textarea , select').forEach(function (input) {
        input.addEventListener('input', function () {
            let error = document.getElementById(this.id + '-error');
            if (this.value.trim() !== "") {
                this.classList.remove('invalid');
                error.style.display = 'none';
            }
        });
        input.addEventListener('focus', function () {
            this.classList.remove('invalid');
            let error = document.getElementById(this.id + '-error');
            error.style.display = 'none';
        });

        input.addEventListener('blur', function () {
        if (this.classList.contains('invalid')) {
            setTimeout(() => this.focus(), 1000);      
        }
    });
    });

    document.querySelectorAll('input[name="priority"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            let error = document.getElementById('priority-error');
            error.style.display = 'none';
        });
    });
};


document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.viewTask');
    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const taskId = this.getAttribute('data-task-id');
            fetchTaskDetails(taskId);
            updateTaskStatus(taskId);
        });
    });

    document.getElementById('closeModal').addEventListener('click', function () {
        document.getElementById('taskDetailsModal').style.display = 'none';
    });

    function fetchTaskDetails(taskId) {
        fetch(`task_details.php?task_id=${taskId}`)
            .then(response => response.json())
            .then(data => {
                let statusText = '';
                if (data.status == 1) {
                    statusText = 'Padding';
                } else if (data.status == 2 || data.status == 3) {
                    statusText = 'in-progress';
                } else if (data.status == 4) {
                    statusText = 'Completed';
                }
                const taskDetailsDiv = document.getElementById('taskDetails');
                taskDetailsDiv.innerHTML = `
                    <p><strong>Task id:</strong> ${data.id}</p>
                    <p><strong>Title:</strong> ${data.title}</p>
                    <p><strong>Description:</strong> ${data.description}</p>
                    <p><strong>Due Date:</strong> ${data.due_date}</p>
                    <p><strong>Time Limit:</strong> ${data.time_limit}</p>
                    <p><strong>Status:</strong> <span class="status-${statusText}">${statusText}</span></p>
                    <p><strong>Time Worked:</strong> ${data.total_time}</p>
                `;
                document.getElementById('taskDetailsModal').style.display = 'flex';
                setButtonStatus(data.status);
            });
    }

    function updateTaskStatus(taskId) {
        document.getElementById('startButton').addEventListener('click', function () {
            updateStatus(taskId, 'start');
        });

        document.getElementById('stopButton').addEventListener('click', function () {
            updateStatus(taskId, 'stop');
        });

        document.getElementById('resumeButton').addEventListener('click', function () {
            updateStatus(taskId, 'resume');
        });

        document.getElementById('completeButton').addEventListener('click', function () {
            updateStatus(taskId, 'complete');
        });
    }

    function updateStatus(taskId, action) {
        fetch('update_task_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `task_id=${taskId}&action=${action}`
        })
            .then(response => response.text())
            .then(data => {
                fetchTaskDetails(taskId);
            })
            .catch(error => console.error('Error:', error));
    }

    function setButtonStatus(status) {
        const startButton = document.getElementById('startButton');
        const stopButton = document.getElementById('stopButton');
        const resumeButton = document.getElementById('resumeButton');
        const completeButton = document.getElementById('completeButton');

        startButton.disabled = true;
        stopButton.disabled = true;
        resumeButton.disabled = true;
        completeButton.disabled = true;

        status = Number(status);

        switch (status) {
            case 1:
                startButton.disabled = false;
                break;
            case 2:
                stopButton.disabled = false;
                completeButton.disabled = false;
                break;
            case 3:
                resumeButton.disabled = false;
                break;
            case 4:
                break;
            default:
                console.error('Unknown status: ' + status);
                break;
        }
    }
});

