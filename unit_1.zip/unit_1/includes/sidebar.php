<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once 'config/connect.php';

$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : (isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light');

if (isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    $_SESSION['theme'] = $theme;
    setcookie('theme', $theme, time() + (86400 * 30), "/");
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theme Toggle Example</title>
    <style>
        :root {
            --color-primary: #7380ec;
            --color-danger: #ff7782;
            --color-success: #41f1b6;
            --color-warning: #ffbb55;
            --color-white: #fff;
            --color-info-dark: #7d8da1;
            --color-info-light: #dce1eb;
            --color-dark: #363949;
            --color-light: rgba(132, 139, 200, 0.18);
            --color-primary-variant: #111e88;
            --color-dark-variant: #677483;
            --color-background: #f6f6f6;
            --card-border-radius: 2rem;
            --border-radius-1: .4rem;
            --border-radius-2: .8rem;
            --border-radius-3: 1.2rem;
            --card-padding: 1.8rem;
            --padding-1: 1.2rem;
            --box-shadow: 0 2rem 3rem var(--color-light);
        }

        .dark-theme-variables {
            --color-background: #181a1e;
            --color-white: #202528;
            --color-dark: #edeffd;
            --color-dark-variant: #a3bdcc;
            --color-light: rgba(0, 0, 0, .4);
            --box-shadow: 0 2rem 3rem var(--color-light);
        }

        * {
            text-decoration: none;
        }

        body {
            width: 100vw;
            height: 100vh;
            font-family: poppins, sans-serif;
            user-select: none;
            overflow-x: hidden;
        }

        .sidebar {
            height: 100%;
            width: 230px;
            position: fixed;
            left: 0;
            padding-top: 90px;
            transition: width 0.3s;
            z-index: 100;
            box-shadow: 0px 0px 4px #ddd;
        }

        a {
            color: var(--color-dark);
        }

        .text-muted {
            color: var(--color-info-dark);
        }

        p {
            color: var(--color-dark-variant);
        }

        b {
            size: 20px;
            color: var(--color-dark);
        }

        .primary {
            color: var(--color-primary);
        }

        aside {
            height: 100vh;
            position: fixed;
        }

        body.dark .sidebar {
            box-shadow: 0px 0px 5px #000;
        }

        aside .top {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        aside .sidebar {
            display: flex;
            flex-direction: column;
            height: 92vh;
            position: relative;
        }

        aside h3 {
            font-weight: 500;
        }

        aside .sidebar a {
            display: flex;
            color: var(--color-info-dark);
            margin-left: 2rem;
            gap: 1rem;
            align-items: center;
            position: relative;
            height: 3.7rem;
            transition: all 300ms ease;
        }

        aside .sidebar a span {
            font-size: 1.6rem;
            transition: all 300ms ease;
        }

        aside .sidebar a:last-child {
            position: absolute;
            bottom: 2rem;
            width: 100%;
        }

        aside .sidebar a.active {
            background: var(--color-light);
            color: var(--color-primary);
            margin-left: 0;
        }

        aside .sidebar a.active::before {
            content: '';
            width: 6px;
            height: 100%;
            background: var(--color-primary);
        }

        aside .sidebar a.active span {
            color: var(--color-primary);
            margin-left: calc(1rem - 3px);
        }

        aside .sidebar a:hover {
            color: var(--color-primary);
        }

        aside .sidebar a:hover span {
            margin-left: 1rem;
        }

        aside .sidebar .message-count {
            background: var(--color-danger);
            color: var(--color-white);
            padding: 2px 10px;
            font-size: 11px;
            border-radius: var(--border-radius-1);
        }

        aside .sidebar:hover .message-count {
            margin-left: 0;
        }

        @media screen and (max-width: 1200px) {
            .container {
                width: 94%;
                grid-template-columns: 7rem auto 23rem;
            }

            aside .logo h2 {
                display: none;
            }

            aside .sidebar h3 {
                display: none;
            }

            aside .sidebar a {
                width: 5.6rem;
            }

            aside .sidebar a:last-child {
                position: relative;
                margin-top: 1.8rem;
            }
        }

        @media screen and (max-width: 768px) {
            .container {
                width: 100%;
                grid-template-columns: 1fr;
            }

            aside {
                position: fixed;
                left: -100%;
                background: var(--color-white);
                width: 18rem;
                z-index: 3;
                box-shadow: 1rem 3rem 4rem var(--color-light);
                height: 100vh;
                padding-right: var(--card-padding);
                display: none;
                animation: showMenu .4s ease forwards;
            }

            @keyframes showMenu {
                to {
                    left: 0;
                }
            }

            aside .logo {
                margin-left: 1rem;
            }

            aside .logo h2 {
                display: inline;
            }

            aside .sidebar h3 {
                display: inline;
            }

            aside .sidebar a {
                width: 100%;
                height: 3.8rem;
            }

            aside .sidebar a:last-child {
                position: absolute;
                bottom: 5rem;
            }

            aside .close {
                display: inline-block;
                cursor: pointer;
            }
        }
    </style>
</head>

<body class="<?= $theme == 'dark' ? 'dark' : '' ?>">
    <aside>
        <div class="sidebar">
            <a href="index.php" class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
                <span class="material-icons-sharp fas fa-tachometer-alt"></span>
                <h3>Dashboard</h3>
            </a>
            <a href="task_manage.php"
                class="<?= basename($_SERVER['PHP_SELF']) == 'task_manage.php' ? 'active' : '' ?>">
                <span class="material-icons-sharp fas fa-tasks"></span>
                <h3>Task Manage</h3>
            </a>
            <a href="auth/logout.php">
                <span class=" fas fa-sign-out-alt"></span>
                <h3>Logout</h3>
            </a>
        </div>
    </aside>
</body>

</html>