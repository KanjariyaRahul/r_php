<?php
include_once 'config/connect.php';
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : (isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light');

if (isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    $_SESSION['theme'] = $theme;
    setcookie('theme', $theme, time() + (86400 * 30), "/");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theme Toggle Example</title>
</head>
<body class="<?= $theme == 'dark' ? 'dark' : '' ?>">
    <aside>
        <div class="sidebar">
            <a href="index.php" class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
                <span class="material-icons-sharp fas fa-tachometer-alt"></span>
                <h3>Dashboard</h3>
            </a>
            <a href="task_manage.php"
                class="<?= basename($_SERVER['PHP_SELF']) == 'task_manage.php' ? 'active' : '' ?>">
                <span class="material-icons-sharp fas fa-tasks"></span>
                <h3>Task Manage</h3>
            </a>
            <a href="auth/logout.php">
                <span class=" fas fa-sign-out-alt"></span>
                <h3>Logout</h3>
            </a>
        </div>
    </aside>
</body>
</html>