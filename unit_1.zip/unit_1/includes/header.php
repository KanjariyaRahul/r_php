<?php
include './includes/session.php';
include_once 'config/connect.php';
include_once 'config/function_config.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['status' => 'error', 'message' => 'User not logged in']));
}

$user_id = $_SESSION['user_id'];
$query = "SELECT u.theme, u.username FROM users u WHERE u.id = ?";
$params = [$user_id];
$result = rpt_safe_query($query, 'i', $params);

if (!$result) {
    die(json_encode(['status' => 'error', 'message' => 'Database query failed']));
}
$user = $result[0];
$_SESSION['username'] = $user['username'];

$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : ($user['theme'] == 2 ? 'dark' : 'light');

if (isset($_GET['theme'])) {
    $new_theme = $_GET['theme'];
    $theme_value = ($new_theme == 'dark') ? 2 : 1;
    $updateQuery = "UPDATE users SET theme = ? WHERE id = ?";
    $params = [$theme_value, $user_id];
    rpt_executeQuery($updateQuery, $params);
    setcookie('theme', $new_theme, time() + (86400 * 30), "/");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>
<link rel="stylesheet" href="./assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<header class="heding">
    <div class="logo">
        <a href="#">Task<span class="primary">Manager</span></a>
    </div>
    <div class="nav-right">
        <span class="username">Welcome, <?php echo $_SESSION['username']; ?></span>
        <div class="theme-toggle" id="icon-container">
            <span class="theme-icon" id="themeIcon">
                <i class="fas fa-sun"></i>
            </span>
            <span class="tooltip" style="margin-left: -80px; margin-top: 30px;" id="themeTooltip"><?php echo $theme == 'dark' ? 'Light Theme' : 'Dark Theme'; ?></span>
        </div>
    </div>
</header>

<script> 
 let isChangingTheme = false;

    function applyThemeImmediately(newTheme) {
        document.body.classList.remove('dark', 'light');
        document.body.classList.add(newTheme);
        document.cookie = "theme=" + newTheme + "; path=/";
        document.getElementById('themeIcon').innerHTML = newTheme === 'dark' ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
        document.getElementById('themeTooltip').textContent = newTheme === 'dark' ? 'Light Theme' : 'Dark Theme';
    }

    function setInitialTheme() {
        let theme = '<?php echo $theme; ?>';
        applyThemeImmediately(theme);
    }

    window.onload = function () {
        setInitialTheme();
    };

    document.getElementById('themeIcon').addEventListener('click', function () {
        if (isChangingTheme) return;

        let newTheme = document.body.classList.contains('dark') ? 'light' : 'dark';

        applyThemeImmediately(newTheme);

        isChangingTheme = true;
        this.style.pointerEvents = 'none';  

        let xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.href + '?theme=' + newTheme, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    let response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        console.log("Theme updated successfully in the database.");
                    } else {
                        alert("Error updating theme in database: " + response.message);
                    }
                } else {
                    alert("Error in AJAX request: " + xhr.statusText);
                }
            }
            isChangingTheme = false;
            document.getElementById('themeIcon').style.pointerEvents = 'auto';  
        };
        xhr.send();
    });

    document.querySelectorAll('.theme-toggle').forEach(function(iconContainer) {
        iconContainer.addEventListener('mouseover', function() {
            iconContainer.querySelector('.tooltip').classList.add('show-tooltip');
        });

        iconContainer.addEventListener('mouseout', function() {
            iconContainer.querySelector('.tooltip').classList.remove('show-tooltip');
        });
    });
</script>
