<footer>
    <p>&copy; <?= date('Y'); ?> Task Manager. All rights reserved.</p>
</footer>