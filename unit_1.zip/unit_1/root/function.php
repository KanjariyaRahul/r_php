<?php 
function generate_nonce_token() {
    if (empty($_SESSION['nonce_token'])) {
        $_SESSION['nonce_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['nonce_token'];
}

function verify_nonce_token($token) {
    return isset($_SESSION['nonce_token']) && $_SESSION['nonce_token'] === $token;
}

?>