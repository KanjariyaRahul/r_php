<?php
include 'includes/session.php';
include_once 'config/connect.php';
include_once 'config/function_config.php';
include 'includes/header.php';
include 'includes/sidebar.php';

$user_id = $_SESSION['user_id'];

$AssignedByAdminCountQuery = "SELECT COUNT(*) AS total
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = ? AND admin.id > 0  ";
$createdByUserQuery = "SELECT COUNT(*) AS total FROM task WHERE created_by = ?";

$AssignedByAdminStmt = $conn->prepare($AssignedByAdminCountQuery);
$AssignedByAdminStmt->bindValue(1, $user_id, PDO::PARAM_INT);
$AssignedByAdminStmt->execute();
$AssignedByAdminCount = $AssignedByAdminStmt->fetch(PDO::FETCH_ASSOC)['total'];

$CreatedByUserStmt = $conn->prepare($createdByUserQuery);
$CreatedByUserStmt->bindValue(1, $user_id, PDO::PARAM_INT);
$CreatedByUserStmt->execute();
$totalCreatedByUserCount = $CreatedByUserStmt->fetch(PDO::FETCH_ASSOC)['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>

<body>
    <div class="main-content">

        <h3>User Dashboard</h3>
        <div class="insights">
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Tasks Assigned By Admin</h3>
                        <h1> <?= $AssignedByAdminCount ?></h1>
                    </div>

                </div>
            </div>
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Your Created Tasks</h3>
                        <h1><?= $totalCreatedByUserCount ?></h1>
                    </div>

                </div>
            </div>
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Total Tasks</h3>
                        <h1><?= $AssignedByAdminCount + $totalCreatedByUserCount ?></h1>
                    </div>

                </div>

            </div>
        </div>
    </div>
</body>
</html>
<?php
include "./includes/footer.php";
?>