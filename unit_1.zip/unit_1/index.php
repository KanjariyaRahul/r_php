<?php
session_start();
include_once 'config/connect.php';
include 'includes/header.php';
include 'includes/sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$AssignedByAdminCountQuery = "SELECT COUNT(*) AS total
    FROM task
    LEFT JOIN admin ON task.assigned_by = admin.id
    WHERE task.user_id = ? AND admin.id > 0  ";
$createdByUserQuery = "SELECT COUNT(*) AS total FROM task WHERE created_by = ?";

$AssignedByAdminStmt = getConnection()->prepare($AssignedByAdminCountQuery);
$AssignedByAdminStmt->bindValue(1, $user_id, PDO::PARAM_INT);
$AssignedByAdminStmt->execute();
$AssignedByAdminCount = $AssignedByAdminStmt->fetch(PDO::FETCH_ASSOC)['total'];

$CreatedByUserStmt = getConnection()->prepare($createdByUserQuery);
$CreatedByUserStmt->bindValue(1, $user_id, PDO::PARAM_INT);
$CreatedByUserStmt->execute();
$totalCreatedByUserCount = $CreatedByUserStmt->fetch(PDO::FETCH_ASSOC)['total'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        body.dark {
            background-color: rgb(43, 43, 43);
            color: rgb(250, 250, 250);
        }

        .main-content {
            margin-left: 235px;
            padding: 40px;
            margin-top: 40px;
            flex-grow: 1;
        }

        .card-container {
            --box-shadow: 0 2rem 3rem var(--color-light);
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            width: 30%;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        body.dark .card {
            background-color: rgb(65, 65, 65);
        }

        .card h3 {
            margin-bottom: 20px;
        }

        .card p {
            font-size: 18px;
        }

        .insights {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
        }

        .insights>div {

            padding: var(--card-padding);
            border-radius: var(--card-border-radius);
            margin-top: 1rem;
            box-shadow: var(--box-shadow);
            transition: all 300ms ease;
        }

        main .insights>div:hover {
            box-shadow: none;
        }

        main .insights>div span {
            background: var(--color-primary);
            padding: .5rem;
            border-radius: 50%;
            color: var(--color-white);
            font-size: 2rem;
        }

        main .insights>div.expenses span {
            background: var(--color-danger);
        }

        main .insights>div.income span {
            background: var(--color-success);
        }

        main .insights .middle {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        main .insights h3 {
            margin: 1rem 0 .6rem;
            font-size: 1rem;
        }

        main .insights .progress {
            position: relative;
            width: 92px;
            height: 92px;
            border-radius: 50%;
        }


        main .insights small {
            margin-top: 1.3rem;
            display: block;
        }



        main .date {
            display: inline-block;
            background: var(--color-light);
            border-radius: var(--border-radius-1);
            margin-top: 1rem;
            padding: .5rem 1.6rem;
        }

        main .date input[type='date'] {
            background: transparent;
            color: var(--color-dark);
        }
    </style>
</head>

<body>
    <div class="main-content">

        <h3>User Dashboard</h3>

        <div class="insights">
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Tasks Assigned By Admin</h3>
                        <h1> <?= $AssignedByAdminCount ?></h1>
                    </div>

                </div>
            </div>
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Your Created Tasks</h3>
                        <h1><?= $totalCreatedByUserCount ?></h1>
                    </div>

                </div>
            </div>
            <div class="">
                <div class="middle">
                    <div class="left">
                        <h3>Total Tasks</h3>
                        <h1><?= $AssignedByAdminCount + $totalCreatedByUserCount ?></h1>
                    </div>

                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php
ob_end_flush();
include "./includes/footer.php";
?>
this based are in curract the code in your way using sql injectiion and pdo full code without nay commant 