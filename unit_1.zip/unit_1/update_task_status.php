<?php
include 'config/connect.php';  
include 'config/function_config.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['task_id'], $_POST['action'])) {
    $task_id = (int)$_POST['task_id'];
    $action = $_POST['action'];

    if ($action == 'start') {
        $start_time = date('Y-m-d H:i:s');
        $sql = "UPDATE task SET status = 2, start_time = ?, stop_time = NULL WHERE id = ?";
        $params = [$start_time, $task_id];
        $result = rpt_executeQuery($sql, $params);
    } elseif ($action == 'stop') {
        $stop_time = date('Y-m-d H:i:s');
        $sql = "SELECT start_time FROM task WHERE id = ?";
        $task = rpt_fetchData($sql, [$task_id]);
        $start_time = strtotime($task[0]['start_time']);
        $stop_time_unix = strtotime($stop_time);
        $time_spent = $stop_time_unix - $start_time;

        $time_spent = ($time_spent < 60) ? 60 : $time_spent;
        $sql = "UPDATE task SET status = 3, stop_time = ?, total_time = total_time + ? WHERE id = ?";
        $params = [$stop_time, $time_spent, $task_id];
        $result = rpt_executeQuery($sql, $params);
    } elseif ($action == 'resume') {
        $current_time = date('Y-m-d H:i:s');
        
        $sql = "SELECT stop_time FROM task WHERE id = ?";
        $task = rpt_fetchData($sql, [$task_id]);
        $last_stop_time = strtotime($task[0]['stop_time']);
        $current_time_unix = strtotime($current_time);

        $sql_add_time = "UPDATE task SET status = 2, start_time = ?, stop_time = NULL WHERE id = ?";
        $params = [$current_time, $task_id];
        $result = rpt_executeQuery($sql_add_time, $params);
    } elseif ($action == 'complete') {
        $end_time = date('Y-m-d H:i:s');
        
        $sql = "SELECT start_time, stop_time FROM task WHERE id = ?";
        $task = rpt_fetchData($sql, [$task_id]);
        $start_time = strtotime($task[0]['start_time']);
        $stop_time_unix = $task[0]['stop_time'] ? strtotime($task[0]['stop_time']) : $start_time;
        $end_time_unix = strtotime($end_time);
        $time_spent = ($end_time_unix - $start_time) + ($stop_time_unix - $start_time);

        $time_spent = ($time_spent < 60) ? 60 : $time_spent;
        $sql = "UPDATE task SET status = 4, stop_time = ?, total_time = total_time + ? WHERE id = ?";
        $params = [$end_time, $time_spent, $task_id];
        $result = rpt_executeQuery($sql, $params);
    }
}
rpt_closeConnection();
?>
